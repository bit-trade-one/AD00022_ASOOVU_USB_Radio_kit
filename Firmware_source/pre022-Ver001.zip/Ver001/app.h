#ifndef APP_H
#define APP_H

#include <delays.h>

/** DECLARATIONS ***************************************************/

// EEPROM ADDRESS
#define EEPROM_BAND			0
#define EEPROM_FMFREQ_L		1
#define EEPROM_FMFREQ_H		2
#define EEPROM_AMFREQ_L		3
#define EEPROM_AMFREQ_H		4
#define EEPROM_VOLUME		5

// Request flag
#define REQ_AM_SET		0x01
#define REQ_FM_SET		0x02
#define REQ_AM_SEEK		0x04
#define REQ_FM_SEEK		0x08
#define REQ_VOL_SET		0x10
#define REQ_RESET		0x20


#define N_ON 1		// normal ON
#define N_OFF 0		// normal OFF
#define T_ON 0		// toggle ON
#define T_OFF 1		// toggle OFF

#define DELAY_100ms() Delay10KTCYx(120)

//--------------------------------------------------
//Timer
//--------------------------------------------------
// 48MHz
#if 0
/* Timer0 1000ms */
/* 1,000,000us / ( 0.021us x 4 ) = 12,000,000  48MHz = 1/48us = 0.021us */
/* 12,000,000 / 256 = 46,875    �v���X�P�[��=256*/
/* 0x10000 - 0xB71B = 0x48E5    16bit�J�E���^*/
#define WRITE_TIMER0_COUNT        0x48E5        //Timer0�̎���

/* Timer1 10ms */
/* 10,000us / ( 0.021us x 4 ) = 120,000  48MHz = 1/48us = 0.021us */
/* 120,000 / 8 = 15,000    �v���X�P�[��=256*/
/* 0x10000 - 0x3A98 = 0xC568    16bit�J�E���^*/
#define WRITE_TIMER1_COUNT        0xC568        //Timer1�̎���
#endif


//--------------------------------------------------
//PWM����
//--------------------------------------------------
// 48MHz
#if 0
#if 1
// PWM���� 10kHz = 100us *************************************************
// 10kHz = ( 74 + 1 ) * 4 * 0.0208us(48MHz) * 16(�v���X�P�[��) = 99.84us
#define PWM_PERIOD 0x4A /* Period 74 = 0x4A */
//#define PWM_OFF 0x12C	/* PWM Duty 0% = (Period + 1) * 4 * (1 - 0.00) */
//#define PWM_1 0x129		/* PWM Duty 1% = (Period + 1) * 4 * (1 - 0.01) */
//#define PWM_2 0x126		/* PWM Duty 2% = (Period + 1) * 4 * (1 - 0.02) */
//#define PWM_3 0x123		/* PWM Duty 3% = (Period + 1) * 4 * (1 - 0.03) */
//#define PWM_4 0x120		/* PWM Duty 4% = (Period + 1) * 4 * (1 - 0.04) */
//#define PWM_5 0x11D		/* PWM Duty 5% = (Period + 1) * 4 * (1 - 0.05) */
//#define PWM_7 0x117		/* PWM Duty 7% = (Period + 1) * 4 * (1 - 0.07) */
//#define PWM_10 0x10E	/* PWM Duty 10% = (Period + 1) * 4 * (1 - 0.10) */
//#define PWM_20 0xF0	/* PWM Duty 20% = (Period + 1) * 4 * (1 - 0.20) */
//#define PWM_25 0xE1	/* PWM Duty 25% = (Period + 1) * 4 * (1 - 0.25) */
//#define PWM_30 0xD2	/* PWM Duty 30% = (Period + 1) * 4 * (1 - 0.30) */
//#define PWM_50 0x96	/* PWM Duty 50% = (Period + 1) * 4 * (1 - 0.50) */
//#define PWM_100 0		/* PWM Duty 100% = (Period + 1) * 4 * (1 - 1.00) */
#define PWM_OFF 0		/* PWM Duty 0% = (Period + 1) * 4 * 0.00 */
#define PWM_1 0x3		/* PWM Duty 1% = (Period + 1) * 4 * 0.01 */
#define PWM_2 0x6		/* PWM Duty 2% = (Period + 1) * 4 * 0.02 */
#define PWM_3 0x9		/* PWM Duty 3% = (Period + 1) * 4 * 0.03 */
#define PWM_4 0xC		/* PWM Duty 4% = (Period + 1) * 4 * 0.04 */
#define PWM_5 0xF		/* PWM Duty 5% = (Period + 1) * 4 * 0.05 */
#define PWM_7 0x15		/* PWM Duty 7% = (Period + 1) * 4 * 0.07 */
#define PWM_10 0x1E		/* PWM Duty 10% = (Period + 1) * 4 * 0.10 */
#define PWM_20 0x3C		/* PWM Duty 20% = (Period + 1) * 4 * 0.20 */
#define PWM_25 0x4B		/* PWM Duty 25% = (Period + 1) * 4 * 0.25 */
#define PWM_30 0x5A		/* PWM Duty 30% = (Period + 1) * 4 * 0.30 */
#define PWM_50 0x96		/* PWM Duty 50% = (Period + 1) * 4 * 0.50 */
#define PWM_100 0x12C	/* PWM Duty 100% = (Period + 1) * 4 * 1.00 */
#endif
#if 0
// PWM���� 5kHz = 200us *************************************************
// 5kHz = ( 149 + 1 ) * 4 * 0.0208us(48MHz) * 16(�v���X�P�[��) = 199.68us
#define PWM_PERIOD 0x95 /* Period 149 = 0x95 */
#define PWM_OFF 0x258	/* PWM Duty 0% = (Period + 1) * 4 * (1 - 0.00) */
#define PWM_1 0x252		/* PWM Duty 1% = (Period + 1) * 4 * (1 - 0.01) */
#define PWM_2 0x24C		/* PWM Duty 2% = (Period + 1) * 4 * (1 - 0.02) */
#define PWM_3 0x246		/* PWM Duty 3% = (Period + 1) * 4 * (1 - 0.03) */
#define PWM_4 0x240		/* PWM Duty 4% = (Period + 1) * 4 * (1 - 0.04) */
#define PWM_5 0x23A		/* PWM Duty 5% = (Period + 1) * 4 * (1 - 0.05) */
#define PWM_7 0x22E		/* PWM Duty 7% = (Period + 1) * 4 * (1 - 0.07) */
#define PWM_10 0x21C	/* PWM Duty 10% = (Period + 1) * 4 * (1 - 0.10) */
#define PWM_20 0x1E0	/* PWM Duty 20% = (Period + 1) * 4 * (1 - 0.20) */
#define PWM_25 0x1C2	/* PWM Duty 25% = (Period + 1) * 4 * (1 - 0.25) */
#define PWM_30 0x1A4	/* PWM Duty 30% = (Period + 1) * 4 * (1 - 0.30) */
#define PWM_50 0x12C	/* PWM Duty 50% = (Period + 1) * 4 * (1 - 0.50) */
#define PWM_100 0		/* PWM Duty 100% = (Period + 1) * 4 * (1 - 1.00) */
//#define PWM_OFF 0		/* PWM Duty 0% = (Period + 1) * 4 * 0.00 */
//#define PWM_1 0x6		/* PWM Duty 1% = (Period + 1) * 4 * 0.01 */
//#define PWM_2 0xC		/* PWM Duty 2% = (Period + 1) * 4 * 0.02 */
//#define PWM_3 0x12		/* PWM Duty 3% = (Period + 1) * 4 * 0.03 */
//#define PWM_4 0x18		/* PWM Duty 4% = (Period + 1) * 4 * 0.04 */
//#define PWM_5 0x1E		/* PWM Duty 5% = (Period + 1) * 4 * 0.05 */
//#define PWM_7 0x2A		/* PWM Duty 7% = (Period + 1) * 4 * 0.07 */
//#define PWM_10 0x3B		/* PWM Duty 10% = (Period + 1) * 4 * 0.10 */
//#define PWM_20 0x78		/* PWM Duty 20% = (Period + 1) * 4 * 0.20 */
//#define PWM_25 0x96		/* PWM Duty 25% = (Period + 1) * 4 * 0.25 */
//#define PWM_30 0xB4		/* PWM Duty 30% = (Period + 1) * 4 * 0.30 */
//#define PWM_50 0x12C	/* PWM Duty 50% = (Period + 1) * 4 * 0.50 */
//#define PWM_100 0x258	/* PWM Duty 100% = (Period + 1) * 4 * 1.00 */
#endif
#endif

// 1MHz
#if 0
// PWM���� 10kHz = 100us *************************************************
// 10kHz = ( 24 + 1 ) * 4 * 1us(1MHz) * 1(�v���X�P�[��) = 100.00us
#define PWM_PERIOD 0x18 /* Period 24 = 0x18 */
#define PWM_OFF 0x64	/* PWM Duty 0% = (Period + 1) * 4 * (1 - 0.00) */
#define PWM_1 0x63		/* PWM Duty 1% = (Period + 1) * 4 * (1 - 0.01) */
#define PWM_2 0x62		/* PWM Duty 2% = (Period + 1) * 4 * (1 - 0.02) */
#define PWM_3 0x61		/* PWM Duty 3% = (Period + 1) * 4 * (1 - 0.03) */
#define PWM_4 0x60		/* PWM Duty 4% = (Period + 1) * 4 * (1 - 0.04) */
#define PWM_5 0x5F		/* PWM Duty 5% = (Period + 1) * 4 * (1 - 0.05) */
#define PWM_7 0x5D		/* PWM Duty 7% = (Period + 1) * 4 * (1 - 0.07) */
#define PWM_10 0x5A	/* PWM Duty 10% = (Period + 1) * 4 * (1 - 0.10) */
#define PWM_20 0x50	/* PWM Duty 20% = (Period + 1) * 4 * (1 - 0.20) */
#define PWM_25 0x4B	/* PWM Duty 25% = (Period + 1) * 4 * (1 - 0.25) */
#define PWM_30 0x46	/* PWM Duty 30% = (Period + 1) * 4 * (1 - 0.30) */
#define PWM_50 0x32	/* PWM Duty 50% = (Period + 1) * 4 * (1 - 0.50) */
#define PWM_100 0		/* PWM Duty 100% = (Period + 1) * 4 * (1 - 1.00) */
//#define PWM_OFF 0		/* PWM Duty 0% = (Period + 1) * 4 * 0.00 */
//#define PWM_1 0x3		/* PWM Duty 1% = (Period + 1) * 4 * 0.01 */
//#define PWM_2 0x6		/* PWM Duty 2% = (Period + 1) * 4 * 0.02 */
//#define PWM_3 0x9		/* PWM Duty 3% = (Period + 1) * 4 * 0.03 */
//#define PWM_4 0xC		/* PWM Duty 4% = (Period + 1) * 4 * 0.04 */
//#define PWM_5 0xF		/* PWM Duty 5% = (Period + 1) * 4 * 0.05 */
//#define PWM_7 0x15		/* PWM Duty 7% = (Period + 1) * 4 * 0.07 */
//#define PWM_10 0x1E		/* PWM Duty 10% = (Period + 1) * 4 * 0.10 */
//#define PWM_20 0x3C		/* PWM Duty 20% = (Period + 1) * 4 * 0.20 */
//#define PWM_25 0x4B		/* PWM Duty 25% = (Period + 1) * 4 * 0.25 */
//#define PWM_30 0x5A		/* PWM Duty 30% = (Period + 1) * 4 * 0.30 */
//#define PWM_50 0x96	/* PWM Duty 50% = (Period + 1) * 4 * 0.50 */
//#define PWM_100 0x12C	/* PWM Duty 100% = (Period + 1) * 4 * 1.00 */
#endif

// �f�o�b�O
extern unsigned char debug_array[15];
//extern unsigned char debug_arr1[4];

#endif //APP_H
