//	RADIO���C�u���� BTO_Radio_Kit.h
//		2012/06/11	����
#ifndef BTO_RADIO_KIT_H
#define BTO_RADIO_KIT_H

#include <i2c.h>
#include <delays.h>

/** STRUCT *********************************************/
typedef struct{
	unsigned int frequency;
	unsigned char rssi;
	unsigned char snr;
} BTO_AM_RADIO_INFO;
typedef struct{
	unsigned int frequency;
	unsigned char rssi;
	unsigned char snr;
	unsigned char stereo;
	unsigned char stereo_blend;
} BTO_FM_RADIO_INFO;


/** EXTERN *********************************************/
extern void OpenRadio(void);
extern void CloseRadio(void);
extern void ResetRadio(void);

extern unsigned char InitAMRadio(unsigned char vol, unsigned int seek_bottom, unsigned int seek_top, unsigned int seek_spacing);
extern unsigned char InitFMRadio(unsigned char vol, unsigned int seek_bottom, unsigned int seek_top, unsigned int seek_spacing);
extern void SetAMRadio(unsigned int freq, unsigned char wait_f);
extern void SetFMRadio(unsigned int freq, unsigned char wait_f);
extern void SeekAMRadio(unsigned char seek_up, unsigned char wait_f);
extern void SeekFMRadio(unsigned char seek_up, unsigned char wait_f);
extern void SetVolume(unsigned char vol);

extern BTO_AM_RADIO_INFO *Get_AM_Radio_Info(void);
extern BTO_FM_RADIO_INFO *Get_FM_Radio_Info(void);

/** DEFINE ******************************************************/
#define ACK		0
#define NACK	1

#define BAND_AM			0
#define BAND_FM			1

#define SEEK_DOWN		0
#define SEEK_UP			1

// Wait Flag
#define WFLAG_NO_WAIT	0
#define WFLAG_WAIT		1

#define FM_FRQ_MIN			6400	// 64.00MHz
#define FM_FRQ_MAX			10800	// 108.00MHz
#define FM_FRQ_SEEK_SPAN	10		// 100kHz
#define FM_FRQ_MIN_JP		7600	// 76.00MHz japan
#define FM_FRQ_MAX_JP		9000	// 90.00MHz japan
#define FM_FRQ_SEEK_SPAN_JP	10		// 100kHz japan
#define AM_FRQ_MIN			520		// 520kHz
#define AM_FRQ_MAX			1710	// 1710kHz
#define AM_FRQ_SEEK_SPAN	10		// 10kHz
#define AM_FRQ_MIN_JP		522		// 522kHz japan
#define AM_FRQ_MAX_JP		1710	// 1710kHz japan
#define AM_FRQ_SEEK_SPAN_JP	9		// 9kHz japan
#define VOL_MIN				0
#define VOL_MAX				0x3F


/** EOF BTO_Radio_Kit.h *************************************************/
#endif

