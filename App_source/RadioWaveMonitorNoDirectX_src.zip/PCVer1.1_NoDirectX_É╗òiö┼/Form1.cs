//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
/********************************************************************
 FileName:		Form1.cs
 Dependencies:	When compiled, needs .NET framework 2.0 redistributable to run.
 Hardware:		Need a free USB port to connect USB peripheral device
				programmed with appropriate Generic HID firmware.  VID and
				PID in firmware must match the VID and PID in this
				program.
 Compiler:  	Microsoft Visual C# 2005 Express Edition (or better)
 Company:		Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the �Company�E for its PIC� Microcontroller is intended and
 supplied to you, the Company�s customer, for use solely and
 exclusively with Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN �AS IS�ECONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

********************************************************************
 File Description:

 Change History:
  Rev   Date         Description
  2.5a	07/17/2009	 Initial Release.  Ported from HID PnP Demo
                     application source, which was originally 
                     written in MSVC++ 2005 Express Edition.
********************************************************************
NOTE:	All user made code contained in this project is in the Form1.cs file.
		All other code and files were generated automatically by either the
		new project wizard, or by the development environment (ex: code is
		automatically generated if you create a new button on the form, and
		then double click on it, which creates a click event handler
		function).  User developed code (code not developed by the IDE) has
        been marked in "cut and paste blocks" to make it easier to identify.
********************************************************************/

//NOTE: In order for this program to "find" a USB device with a given VID and PID, 
//both the VID and PID in the USB device descriptor (in the USB firmware on the 
//microcontroller), as well as in this PC application source code, must match.
//To change the VID/PID in this PC application source code, scroll down to the 
//CheckIfPresentAndGetUSBDevicePath() function, and change the line that currently
//reads:

//   String DeviceIDToFind = "Vid_04d8&Pid_003f";


//NOTE 2: This C# program makes use of several functions in setupapi.dll and
//other Win32 DLLs.  However, one cannot call the functions directly in a 
//32-bit DLL if the project is built in "Any CPU" mode, when run on a 64-bit OS.
//When configured to build an "Any CPU" executable, the executable will "become"
//a 64-bit executable when run on a 64-bit OS.  On a 32-bit OS, it will run as 
//a 32-bit executable, and the pointer sizes and other aspects of this 
//application will be compatible with calling 32-bit DLLs.

//Therefore, on a 64-bit OS, this application will not work unless it is built in
//"x86" mode.  When built in this mode, the exectuable always runs in 32-bit mode
//even on a 64-bit OS.  This allows this application to make 32-bit DLL function 
//calls, when run on either a 32-bit or 64-bit OS.

//By default, on a new project, C# normally wants to build in "Any CPU" mode.  
//To switch to "x86" mode, open the "Configuration Manager" window.  In the 
//"Active solution platform:" drop down box, select "x86".  If this option does
//not appear, select: "<New...>" and then select the x86 option in the 
//"Type or select the new platform:" drop down box.  

//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------



using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Threading;


namespace RadioWaveMonitor
{
    public partial class Form1 : Form
    {

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        internal const string DEF_VID_PID = "Vid_22EA&Pid_0022";
        //Constant definitions from setupapi.h, which we aren't allowed to include directly since this is C#
        internal const uint DIGCF_PRESENT = 0x02;
        internal const uint DIGCF_DEVICEINTERFACE = 0x10;
        //Constants for CreateFile() and other file I/O functions
        internal const short FILE_ATTRIBUTE_NORMAL = 0x80;
        internal const short INVALID_HANDLE_VALUE = -1;
        internal const uint GENERIC_READ = 0x80000000;
        internal const uint GENERIC_WRITE = 0x40000000;
        internal const uint CREATE_NEW = 1;
        internal const uint CREATE_ALWAYS = 2;
        internal const uint OPEN_EXISTING = 3;
        internal const uint FILE_SHARE_READ = 0x00000001;
        internal const uint FILE_SHARE_WRITE = 0x00000002;
        //Constant definitions for certain WM_DEVICECHANGE messages
        internal const uint WM_DEVICECHANGE = 0x0219;
        internal const uint DBT_DEVICEARRIVAL = 0x8000;
        internal const uint DBT_DEVICEREMOVEPENDING = 0x8003;
        internal const uint DBT_DEVICEREMOVECOMPLETE = 0x8004;
        internal const uint DBT_CONFIGCHANGED = 0x0018;
        //Other constant definitions
        internal const uint DBT_DEVTYP_DEVICEINTERFACE = 0x05;
        internal const uint DEVICE_NOTIFY_WINDOW_HANDLE = 0x00;
        internal const uint ERROR_SUCCESS = 0x00;
        internal const uint ERROR_NO_MORE_ITEMS = 0x00000103;
        internal const uint SPDRP_HARDWAREID = 0x00000001;

        //Various structure definitions for structures that this code will be using
        internal struct SP_DEVICE_INTERFACE_DATA
        {
            internal uint cbSize;               //DWORD
            internal Guid InterfaceClassGuid;   //GUID
            internal uint Flags;                //DWORD
            internal uint Reserved;             //ULONG_PTR MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct SP_DEVICE_INTERFACE_DETAIL_DATA
        {
            internal uint cbSize;               //DWORD
#pragma warning disable 0649
            internal char[] DevicePath;         //TCHAR array of any size
#pragma warning restore 0649
        }
        
        internal struct SP_DEVINFO_DATA
        {
            internal uint cbSize;       //DWORD
            internal Guid ClassGuid;    //GUID
            internal uint DevInst;      //DWORD
            internal uint Reserved;     //ULONG_PTR  MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct DEV_BROADCAST_DEVICEINTERFACE
        {
            internal uint dbcc_size;            //DWORD
            internal uint dbcc_devicetype;      //DWORD
            internal uint dbcc_reserved;        //DWORD
            internal Guid dbcc_classguid;       //GUID
#pragma warning disable 0649
            internal char[] dbcc_name;          //TCHAR array
#pragma warning restore 0649
        }

        //DLL Imports.  Need these to access various C style unmanaged functions contained in their respective DLL files.
        //--------------------------------------------------------------------------------------------------------------
        //Returns a HDEVINFO type for a device information set.  We will need the 
        //HDEVINFO as in input parameter for calling many of the other SetupDixxx() functions.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr SetupDiGetClassDevs(
            ref Guid ClassGuid,     //LPGUID    Input: Need to supply the class GUID. 
            IntPtr Enumerator,      //PCTSTR    Input: Use NULL here, not important for our purposes
            IntPtr hwndParent,      //HWND      Input: Use NULL here, not important for our purposes
            uint Flags);            //DWORD     Input: Flags describing what kind of filtering to use.

	    //Gives us "PSP_DEVICE_INTERFACE_DATA" which contains the Interface specific GUID (different
	    //from class GUID).  We need the interface GUID to get the device path.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInterfaces(
            IntPtr DeviceInfoSet,           //Input: Give it the HDEVINFO we got from SetupDiGetClassDevs()
            IntPtr DeviceInfoData,          //Input (optional)
            ref Guid InterfaceClassGuid,    //Input 
            uint MemberIndex,               //Input: "Index" of the device you are interested in getting the path for.
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData);    //Output: This function fills in an "SP_DEVICE_INTERFACE_DATA" structure.

        //SetupDiDestroyDeviceInfoList() frees up memory by destroying a DeviceInfoList
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiDestroyDeviceInfoList(
            IntPtr DeviceInfoSet);          //Input: Give it a handle to a device info list to deallocate from RAM.

        //SetupDiEnumDeviceInfo() fills in an "SP_DEVINFO_DATA" structure, which we need for SetupDiGetDeviceRegistryProperty()
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInfo(
            IntPtr DeviceInfoSet,
            uint MemberIndex,
            ref SP_DEVINFO_DATA DeviceInterfaceData);

        //SetupDiGetDeviceRegistryProperty() gives us the hardware ID, which we use to check to see if it has matching VID/PID
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceRegistryProperty(
            IntPtr DeviceInfoSet,
            ref SP_DEVINFO_DATA DeviceInfoData,
            uint Property,
            ref uint PropertyRegDataType,
            IntPtr PropertyBuffer,
            uint PropertyBufferSize,
            ref uint RequiredSize);

        //SetupDiGetDeviceInterfaceDetail() gives us a device path, which is needed before CreateFile() can be used.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,                    //Input: Pointer to an structure which defines the device interface.  
            IntPtr  DeviceInterfaceDetailData,      //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will receive the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            ref uint RequiredSize,                  //Output (optional): The number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Overload for SetupDiGetDeviceInterfaceDetail().  Need this one since we can't pass NULL pointers directly in C#.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,               //Input: Pointer to an structure which defines the device interface.  
            IntPtr DeviceInterfaceDetailData,       //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will contain the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            IntPtr RequiredSize,                    //Output (optional): Pointer to a DWORD to tell you the number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Need this function for receiving all of the WM_DEVICECHANGE messages.  See MSDN documentation for
        //description of what this function does/how to use it. Note: name is remapped "RegisterDeviceNotificationUM" to
        //avoid possible build error conflicts.
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr RegisterDeviceNotification(
            IntPtr hRecipient,
            IntPtr NotificationFilter,
            uint Flags);

        //Takes in a device path and opens a handle to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern SafeFileHandle CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode, 
            IntPtr lpSecurityAttributes, 
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes, 
            IntPtr hTemplateFile);

        //Uses a handle (created with CreateFile()), and lets us write USB data to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool WriteFile(
            SafeFileHandle hFile,
            byte[] lpBuffer,
            uint nNumberOfBytesToWrite,
            ref uint lpNumberOfBytesWritten,
            IntPtr lpOverlapped);

        //Uses a handle (created with CreateFile()), and lets us read USB data from the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool ReadFile(
            SafeFileHandle hFile,
            IntPtr lpBuffer,
            uint nNumberOfBytesToRead,
            ref uint lpNumberOfBytesRead,
            IntPtr lpOverlapped);


	    //--------------- Global Varibles Section ------------------
	    //USB related variables that need to have wide scope.
	    bool AttachedState = false;						//Need to keep track of the USB device attachment status for proper plug and play operation.
	    bool AttachedButBroken = false;
        bool AttachedFirstTime = true;
        SafeFileHandle WriteHandleToUSBDevice = null;
        SafeFileHandle ReadHandleToUSBDevice = null;
        String DevicePath = null;   //Need the find the proper device path before you can open file handles.

        int[] Debug_Array = new int[15];    //DEBUG
        byte[] Debug_Arr = new byte[64]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        int[] Debug_Arr2 = new int[4] { 0, 0, 0, 0 };

        bool b_AMSet_flag = false;
        int AM_Set_Freq = 0;
        bool b_FMSet_flag = false;
        int FM_Set_Freq = 0;
        bool b_VolSet_flag = false;
        int Set_Volume = 0;
        int Mute_Volume_backup = 0;
        bool b_SeekUp_flag = false;
        bool b_SeekDown_flag = false;
        int i_FreqChange_flag = 0;
        int FreqChangeButton_Time = 0;
        int BandWidth = BANDWIDTH_WORLD_WIDE;
        bool b_ReSet_flag = false;
        bool b_AMChange_Req_flag = false;
        bool b_FMChange_Req_flag = false;
        int Freq_Change_Count = 0;

        byte rcv_band = 0;
        int rcv_freq_am = 0;
        int rcv_freq_fm = 0;
        byte rcv_vol = 0;
        byte rcv_rssi = 0;
        byte rcv_snr = 0;
        byte rcv_stereo = 0;
        byte rcv_stereo_blend = 0;

        //����������
        //////////private Capture dsCapture = null;
        //////////private CaptureBuffer dsCaptureBuffer = null;
        //////////private CaptureBufferDescription dsCaptureBufferDescription;
        //////////private WaveFormat dsWaveFormat;
        //////////private const int BUFFER_SECOND = 10;       //�o�b�t�@�̕b��
        //////////private const int CAPTURE_PER_SECOND = 10;  //�P�b�Ԃɒʒm�����
        //////////private BinaryWriter binaryWriter = null;
        //////////private bool CaptureFlag = false;
        //////////private bool bgw_CaptureBufferWrite_Busy = false;
        //////////private uint Capture_Wave_Size = 0;
        //////////private const uint WAV_FILE_SIZE_OFFSET = 0x0004;    // WAV�t�@�C���̃t�@�C���T�C�Y�i�[�ʒu
        //////////private const uint WAV_WAVE_SIZE_OFFSET = 0x0028;    // WAV�t�@�C���̔g�`�T�C�Y�i�[�ʒu
        ////////////private const uint WAV_FILE_MAX_SIZE = 0x50BFE0;   // ������debug WAV�t�@�C���̍ő�T�C�Y[byte] 22050kHz 60s = 22050 * 4 * 60
        //////////private const uint WAV_FILE_MAX_SIZE = 0xFFFFFFFF;   // WAV�t�@�C���̍ő�T�C�Y[byte]

        //////////private AutoResetEvent autoResetEvent;
        //////////private Notify notify;
        //////////private BufferPositionNotify[] PositionNotify = new BufferPositionNotify[BUFFER_SECOND * CAPTURE_PER_SECOND];


        PictureBox[] pic_AM_Freq;
        PictureBox[] pic_FM_Freq;
        PictureBox[] pic_Vol;
        PictureBox[] pic_Volume_Level;
        //����������
        //////////PictureBox[] pic_Timer_On;
        //////////PictureBox[] pic_Timer_Date;
        //////////PictureBox[] pic_Timer_ONTime;
        //////////PictureBox[] pic_Timer_OFFTime;
        //////////PictureBox[] pic_Timer_Freq;
        //////////PictureBox[] pic_Timer_SRate;
        
        //����������
        //////////TimerInfo timer_info = new TimerInfo();

        internal const byte BAND_AM = 0;              // BAND AM
        internal const byte BAND_FM = 1;              // BAND FM
        internal const byte SEEK_DOWN = 0;            // SEEK DOWNM
        internal const byte SEEK_UP = 1;              // SEEK UP

        internal const int BANDWIDTH_WORLD_WIDE = 0;    // BANDWIDTH WORLD WIDE
        internal const int BANDWIDTH_JAPAN = 1;         // BANDWIDTH JAPAN

        internal const int REPEAT_TYPE_ONCE = 0;            // TIMER REPEAT TYPE : ONCE
        internal const int REPEAT_TYPE_EVERY_DAY = 1;       // TIMER REPEAT TYPE : EVERY DAY
        internal const int REPEAT_TYPE_DAY_OF_WEEK = 2;     // TIMER REPEAT TYPE : DAY OF WEEK

        internal const int SAMPLING_FREQ_8kHz = 8000;       // SAMPLING FREQ : 8kHz
        internal const int SAMPLING_FREQ_11kHz = 11025;     // SAMPLING FREQ : 11.025kHz
        internal const int SAMPLING_FREQ_16kHz = 16000;     // SAMPLING FREQ : 16kHz
        internal const int SAMPLING_FREQ_22kHz = 22050;     // SAMPLING FREQ : 22.05kHz
        internal const int SAMPLING_FREQ_32kHz = 32000;     // SAMPLING FREQ : 32kHz
        internal const int SAMPLING_FREQ_44kHz = 44100;     // SAMPLING FREQ : 44.1kHz

        internal const int FREQ_AUTO_CHANGE_TIME_L1 = 10;       // ���g���̎����A�b�v���J�n���鎞��1 1000ms 1000/100=10
        internal const int FREQ_AUTO_CHANGE_SPAN_AM_L1 = 2;     // ���g���̎����A�b�v����l1 AM +-2kHz
        internal const int FREQ_AUTO_CHANGE_SPAN_FM_L1 = 20;    // ���g���̎����A�b�v����l1 FM +-0.2MHz
        internal const int FREQ_AUTO_CHANGE_TIME_L2 = 30;       // ���g���̎����A�b�v���J�n���鎞��2 3000ms 3000/100=30
        internal const int FREQ_AUTO_CHANGE_SPAN_AM_L2 = 9;     // ���g���̎����A�b�v����l1 AM +-9kHz
        internal const int FREQ_AUTO_CHANGE_SPAN_FM_L2 = 90;    // ���g���̎����A�b�v����l1 FM +-0.9MHz
        internal const int FREQ_AUTO_CHANGE_TIME_L3 = 50;       // ���g���̎����A�b�v���J�n���鎞��3 5000ms 5000/100=50
        internal const int FREQ_AUTO_CHANGE_SPAN_AM_L3 = 19;    // ���g���̎����A�b�v����l1 AM +-19kHz
        internal const int FREQ_AUTO_CHANGE_SPAN_FM_L3 = 190;   // ���g���̎����A�b�v����l1 FM +-1.9MHz

        internal const int FM_FRQ_MIN           = 6400;	    // 64.00MHz
        internal const int FM_FRQ_MAX           = 10800;	// 108.00MHz
        internal const int FM_FRQ_SEEK_SPAN     = 10;		// 100kHz
        internal const int FM_FRQ_MIN_JP        = 7600;	    // 76.00MHz japan
        internal const int FM_FRQ_MAX_JP        = 9000;	    // 90.00MHz japan
        internal const int FM_FRQ_SEEK_SPAN_JP  = 10;		// 100kHz japan
        internal const int AM_FRQ_MIN           = 520;		// 520kHz
        internal const int AM_FRQ_MAX           = 1710;	    // 1710kHz
        internal const int AM_FRQ_SEEK_SPAN     = 10;		// 10kHz
        internal const int AM_FRQ_MIN_JP        = 522;		// 520kHz japan
        internal const int AM_FRQ_MAX_JP        = 1710;	    // 1710kHz japan
        internal const int AM_FRQ_SEEK_SPAN_JP  = 9;		// 9kHz japan
        internal const int VOL_MIN              = 0;
        internal const int VOL_MAX              = 0x3F;

        internal const int GRID_NUM_FM_ROW = 44;         // ��M���x���\���G���A ��(108MHz-64MHz=44) FM
        internal const int GRID_NUM_FM_COL = 13;         // ��M���x���\���G���A �s�� FM
        internal const int GRID_NUM_AM_ROW = 119;        // ��M���x���\���G���A ��(1710kHz-520kHz/20=119) AM
        internal const int GRID_NUM_AM_COL = 13;         // ��M���x���\���G���A �s�� AM

        //����������
        //////////internal const int REC_STATUS_NONE = 0;         // REC STATUS NONE
        //////////internal const int REC_STATUS_WAIT = 1;         // REC STATUS WAIT
        //////////internal const int REC_STATUS_INIT = 2;         // REC STATUS INIT
        //////////internal const int REC_STATUS_REC_WAIT = 3;     // REC STATUS REC WAIT
        //////////internal const int REC_STATUS_RECORDING = 4;    // REC STATUS RECORDING
        //////////internal const int REC_STATUS_STOP_WAIT = 5;    // REC STATUS STOP WAIT
        //////////internal const int REC_STATUS_NEXT = 6;         // REC STATUS NEXT
        //////////internal const int REC_STATUS_CANCEL = 97;      // REC STATUS CANCEL
        //////////internal const int REC_STATUS_CANCEL_WAIT = 98; // REC STATUS CANCEL WAIT
        //////////internal const int REC_STATUS_END = 99;         // REC STATUS END
        //////////internal const int TIMER_FREQ_SET_TIME = 30;    // Timer�Z�b�g���Ԃ̉��b�O�Ɏ��g����ݒ肷�邩�̐ݒ�l[s]
        //////////internal const int TIMER_REC_START_TIME = 10;   // Timer�Z�b�g���Ԃ̉��b�O�ɘ^�����J�n���邩�̐ݒ�l[s]
        //////////int recording_status = REC_STATUS_NONE;
        //////////bool recording_cancel = false;
        //////////internal const string TIMER_INFO_FILE_NAME = "TIMER_SETTING.xml";         // Timer���i�[�t�@�C����

        internal const int SCAN_STATUS_NONE = 0;        // SCAN STATUS NONE
        internal const int SCAN_STATUS_INIT = 1;        // SCAN STATUS ������
        internal const int SCAN_STATUS_FREQ_SET = 2;    // SCAN STATUS ��M���g���Z�b�g
        internal const int SCAN_STATUS_RQS = 3;         // SCAN STATUS ��M��Ԏ擾
        internal const int SCAN_STATUS_END = 4;         // SCAN STATUS �I��
        int scan_status = SCAN_STATUS_NONE;
        internal const int SCAN_RSSI_SCALE_MAX = 26;    // SCAN RSSI SCALE��ImageList�摜�̍ő�index
        internal const int SCAN_SNR_SCALE_MAX = 26;     // SCAN SNR SCALE��ImageList�摜�̍ő�index
        int scan_process_redraw_count = 0;
        internal const int SCAN_PROCESS_REDRAW = 10;     // SCAN Process ... �̍X�V�Ԋu 1000ms / 100 = 10
        struct st_SACN_INFO
        {
            internal int num;
            internal byte band;
            internal int freq_backup;
            internal int freq_min ;
            internal int freq_max;
            internal int scan_idx;
            internal int max_rssi_range;
            internal int max_snr_range;
            internal int[] rssi_scale;
            internal int[] snr_scale;
            internal int scan_comp_num;
            internal bool[] scan_comp;
            internal int[] freq;
            internal byte[] rssi;
            internal byte[] snr;

            public void init(byte p_band, int p_freq_bk, int p_freq_scan_buttom, int p_freq_scan_top, int p_span, int p_freq_min, int p_freq_max)
            {
                band = p_band;
                freq_backup = p_freq_bk;
                freq_min = p_freq_min;
                freq_max = p_freq_max;
                scan_idx = 0;
                max_rssi_range = 10;
                max_snr_range = 10;
                Array.Resize(ref rssi_scale, 3);
                Array.Resize(ref snr_scale, 3);
                for (int fi = 0; fi < rssi_scale.Length; fi++)
                {
                    rssi_scale[fi] = fi;
                    snr_scale[fi] = fi;
                }
                scan_comp_num = 0;
                int num_temp = ((p_freq_scan_top - p_freq_scan_buttom) / p_span) + 1;
                if( num_temp > 0)
                {
                    num = num_temp;
                    Array.Resize(ref scan_comp, num_temp);
                    Array.Resize(ref freq, num_temp);
                    Array.Resize(ref rssi, num_temp);
                    Array.Resize(ref snr, num_temp);
                    for (int fi = 0; fi < num; fi++)
                    {
                        scan_comp[fi] = false;
                        freq[fi] = p_freq_scan_buttom + (p_span * fi);
                        rssi[fi] = 0;
                        snr[fi] = 0;
                    }
                }
                else
                {
                    num = 0;
                    scan_comp = null;
                    freq = null;
                    rssi= null;
                    snr = null;
                }
        
            }
        }
        st_SACN_INFO scan_info = new st_SACN_INFO();


        //Globally Unique Identifier (GUID) for HID class devices.  Windows uses GUIDs to identify things.
        Guid InterfaceClassGuid = new Guid(0x4d1e55b2, 0xf16f, 0x11cf, 0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30); 
	    //--------------- End of Global Varibles ------------------

        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Need to check "Allow unsafe code" checkbox in build properties to use unsafe keyword.  Unsafe is needed to
        //properly interact with the unmanged C++ style APIs used to find and connect with the USB device.
        public unsafe Form1()
        {
            InitializeComponent();

            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
			//Additional constructor code

            //Initialize tool tips, to provide pop up help when the mouse cursor is moved over objects on the form.
            //Register for WM_DEVICECHANGE notifications.  This code uses these messages to detect plug and play connection/disconnection events for USB devices
            DEV_BROADCAST_DEVICEINTERFACE DeviceBroadcastHeader = new DEV_BROADCAST_DEVICEINTERFACE();
            DeviceBroadcastHeader.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
            DeviceBroadcastHeader.dbcc_size = (uint)Marshal.SizeOf(DeviceBroadcastHeader);
            DeviceBroadcastHeader.dbcc_reserved = 0;	//Reserved says not to use...
            DeviceBroadcastHeader.dbcc_classguid = InterfaceClassGuid;

            //Need to get the address of the DeviceBroadcastHeader to call RegisterDeviceNotification(), but
            //can't use "&DeviceBroadcastHeader".  Instead, using a roundabout means to get the address by 
            //making a duplicate copy using Marshal.StructureToPtr().
            IntPtr pDeviceBroadcastHeader = IntPtr.Zero;  //Make a pointer.
            pDeviceBroadcastHeader = Marshal.AllocHGlobal(Marshal.SizeOf(DeviceBroadcastHeader)); //allocate memory for a new DEV_BROADCAST_DEVICEINTERFACE structure, and return the address 
            Marshal.StructureToPtr(DeviceBroadcastHeader, pDeviceBroadcastHeader, false);  //Copies the DeviceBroadcastHeader structure into the memory already allocated at DeviceBroadcastHeaderWithPointer
            RegisterDeviceNotification(this.Handle, pDeviceBroadcastHeader, DEVICE_NOTIFY_WINDOW_HANDLE);

			//Now make an initial attempt to find the USB device, if it was already connected to the PC and enumerated prior to launching the application.
			//If it is connected and present, we should open read and write handles to the device so we can communicate with it later.
			//If it was not connected, we will have to wait until the user plugs the device in, and the WM_DEVICECHANGE callback function can process
			//the message and again search for the device.
			if(CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
			{
				uint ErrorStatusWrite;
				uint ErrorStatusRead;


				//We now have the proper device path, and we can finally open read and write handles to the device.
                WriteHandleToUSBDevice = CreateFile(DevicePath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                ReadHandleToUSBDevice = CreateFile(DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

				if((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
				{
					AttachedState = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
					AttachedButBroken = false;
                    connect_status_lbl.Text = "�ڑ�����܂���";
				}
				else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
				{
					AttachedState = false;		//Let the rest of this application known not to read/write to the device.
					AttachedButBroken = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
					if(ErrorStatusWrite == ERROR_SUCCESS)
						WriteHandleToUSBDevice.Close();
					if(ErrorStatusRead == ERROR_SUCCESS)
						ReadHandleToUSBDevice.Close();
				}
			}
			else	//Device must not be connected (or not programmed with correct firmware)
			{
				AttachedState = false;
				AttachedButBroken = false;
			}

            //����������
            //������
            //////////string read_path = System.AppDomain.CurrentDomain.BaseDirectory + TIMER_INFO_FILE_NAME;
            //////////my_TIMER_INFO_File_Read(read_path);
            //////////timer_info.NextTimerSet(true);

            //���߂̂��߂̐e�ݒ�
            picbx_rssi_scale_1.Parent = pnl_RadioMain;
            picbx_rssi_scale_2.Parent = pnl_RadioMain;
            picbx_snr_scale_1.Parent = pnl_RadioMain;
            picbx_snr_scale_2.Parent = pnl_RadioMain;

            //�摜������
            picbx_Bandwidth.Image = imglist_Band_Wide.Images[0];
            picbx_rssi_scale_1.Image = imglist_RSSI_scale.Images[1];
            picbx_rssi_scale_2.Image = imglist_RSSI_scale.Images[2];
            picbx_snr_scale_1.Image = imglist_SNR_scale.Images[1];
            picbx_snr_scale_2.Image = imglist_SNR_scale.Images[2];

            btn_Close.BackgroundImage = imglist_Controlbox.Images[0];
            btn_Close.Tag = 0;
            btn_Maximize.BackgroundImage = imglist_Controlbox.Images[2];
            btn_Maximize.Tag = 2;
            btn_Minimize.BackgroundImage = imglist_Controlbox.Images[4];
            btn_Minimize.Tag = 4;

            btn_Scan.BackgroundImage = imglist_ScanBtn.Images[0];
            btn_Scan.Tag = 0;
            btn_ScanCancel.BackgroundImage = imglist_ScanBtn.Images[2];
            btn_ScanCancel.Tag = 2;

            btn_Band.BackgroundImage = imglist_BandBtn.Images[0];
            btn_Band.Tag = 0;
            SeekDown_btn.BackgroundImage = imglist_FreqChangeBtn.Images[0];
            SeekDown_btn.Tag = 0;
            SeekUp_btn.BackgroundImage = imglist_FreqChangeBtn.Images[2];
            SeekUp_btn.Tag = 2;
            btn_FreqDown.BackgroundImage = imglist_FreqChangeBtn.Images[4];
            btn_FreqDown.Tag = 4;
            btn_FreqUp.BackgroundImage = imglist_FreqChangeBtn.Images[6];
            btn_FreqUp.Tag = 6;

            chkbx_Mute.BackgroundImage = imglist_MuteBtn.Images[0];
            chkbx_Mute.Tag = 0;
            trkbar_Volume.BackColor = Color.FromArgb(49, 52, 55);

            //����������
            //////////picbx_Timer_Band.BackgroundImage = imglist_TimerBand.Images[0];
            //////////btn_TimerSet.BackgroundImage = imglist_TimerSet_btn.Images[0];
            //////////btn_TimerSet.Tag = 0;

            pic_AM_Freq = new PictureBox[] { picbx_AMFreq_1000, picbx_AMFreq_100, picbx_AMFreq_10, picbx_AMFreq_1 };
            pic_FM_Freq = new PictureBox[] { picbx_FMFreq_100, picbx_FMFreq_10, picbx_FMFreq_1, picbx_FMFreq_P1 };
            pic_Vol = new PictureBox[] { picbx_Vol_10, picbx_Vol_1 };
            pic_Volume_Level = new PictureBox[] { picbx_VolumeLevel1, picbx_VolumeLevel2, picbx_VolumeLevel3, picbx_VolumeLevel4, picbx_VolumeLevel5, picbx_VolumeLevel6 };
            //����������
            //////////pic_Timer_On = new PictureBox[] { picbx_TimerOn_Once, picbx_TimerOn_Daily, picbx_TimerOn_Weekly };
            //////////pic_Timer_Date = new PictureBox[] { picbx_Timer_Date_Y1000, picbx_Timer_Date_Y100, picbx_Timer_Date_Y10, picbx_Timer_Date_Y1, picbx_Timer_Date_M10, picbx_Timer_Date_M1, picbx_Timer_Date_D10, picbx_Timer_Date_D1 };
            //////////pic_Timer_ONTime = new PictureBox[] { picbx_Timer_ONTime_H10, picbx_Timer_ONTime_H1, picbx_Timer_ONTime_M10, picbx_Timer_ONTime_M1 };
            //////////pic_Timer_OFFTime = new PictureBox[] { picbx_Timer_OFFTime_H10, picbx_Timer_OFFTime_H1, picbx_Timer_OFFTime_M10, picbx_Timer_OFFTime_M1 };
            //////////pic_Timer_Freq = new PictureBox[] { picbx_Timer_Freq_1000, picbx_Timer_Freq_100, picbx_Timer_Freq_10, picbx_Timer_Freq_1 };
            //////////pic_Timer_SRate = new PictureBox[] { picbx_SRate_10000, picbx_SRate_1000, picbx_SRate_100, picbx_SRate_10, picbx_SRate_1 };


            my_Disp_Band(AttachedState, false, rcv_band, rcv_freq_am, rcv_freq_fm);
            my_Disp_Volume(AttachedState, false, rcv_vol, Mute_Volume_backup, chkbx_Mute.Checked);
            //����������
            //////////// Timer�\���X�V
            //////////my_Disp_Timer(AttachedState, timer_info.exe_timer_set_flag, timer_info.exe_timer_on_date, timer_info.exe_timer_off_date, (byte)timer_info.band, timer_info.frequency_am, timer_info.frequency_fm, timer_info.sampling_freq, timer_info.repeat_type);


            if (AttachedState == true)
            {
                connect_status_lbl.Text = "�ڑ�����܂����B";
            }
            else
            {
                connect_status_lbl.Text = "�ڑ�����Ă��܂���B";
            }

			ReadWriteThread.RunWorkerAsync();	//Recommend performing USB read/write operations in a separate thread.  Otherwise,
												//the Read/Write operations are effectively blocking functions and can lock up the
												//user interface if the I/O operations take a long time to complete.

            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //DialogResult dr;
            try
            {
                //����������
                //////////if (timer_info.exe_timer_set_flag == true)
                //////////{
                //////////    dr = MessageBox.Show("�\����s���ł��B\n�\����������܂����H", "WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                //////////    if (dr == DialogResult.No)
                //////////    {
                //////////        e.Cancel = true;
                //////////        return;
                //////////    }
                //////////    //�^�����̎��̓L�����Z������
                //////////    recording_cancel = true;
                //////////    timer_info.exe_timer_set_flag = false;

                //////////    while (bgw_CaptureBufferWrite_Busy == true)
                //////////    {
                //////////        System.Windows.Forms.Application.DoEvents();
                //////////    }
                //////////}


                //////////// Timer Setting data�ۑ�
                //////////string save_path = System.AppDomain.CurrentDomain.BaseDirectory + TIMER_INFO_FILE_NAME;
                //////////my_TIMER_INFO_File_Save(save_path, true);

                //////////if (dsCapture != null)
                //////////{
                //////////    dsCapture.Dispose();
                //////////}
                //////////if (dsCaptureBuffer != null)
                //////////{
                //////////    dsCaptureBuffer.Dispose();
                //////////    dsCaptureBuffer = null;
                //////////}
                //////////if (binaryWriter != null)
                //////////{
                //////////    binaryWriter.Close();
                //////////}
            }
            catch
            {
            }
        }
        /// <summary>
        /// �X�L�����g�`�\���G���A�̃O���b�h�`��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void my_DrawGrid(object sender, PaintEventArgs e)
        {
            Pen opaquePen = null;
            Pen opaquePenW = null;
            int Grid_Row = 0;
            int Grid_Col = 0;

            try
            {
                //�N���A
                e.Graphics.Clear(Color.Black);
                //e.Graphics.Clear(Color.Transparent);
                e.Graphics.DrawImage(picbx_ScanWave.Image, 0, 0);

                if (rcv_band == BAND_AM)
                {
                    // Grid���ݒ�
                    Grid_Row = GRID_NUM_AM_ROW;
                    Grid_Col = GRID_NUM_AM_COL;

                    picbx_AM_scale.Visible = true;
                    picbx_FM_scale.Visible = false;
                }
                else
                {
                    // Grid���ݒ�
                    Grid_Row = GRID_NUM_FM_ROW;
                    Grid_Col = GRID_NUM_FM_COL;

                    picbx_AM_scale.Visible = false;
                    picbx_FM_scale.Visible = true;
                }

                // Pen�I�u�W�F�N�g��ݒ�
                int alp = (int)30 * 255 / 100;
                opaquePen = new Pen(Color.FromArgb(alp, 0x4F, 0x4D, 0x4D), (float)1);
                alp = (int)70 * 255 / 100;
                opaquePenW = new Pen(Color.FromArgb(alp, 0x4F, 0x4D, 0x4D), (float)1);
                //�A���`�G�C���A�X�w��
                //e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                //�c���`��
                //����
                float f_interval = (float)(picbx_ScanWave.Width - 1) / (float)Grid_Row;
                float xx, yy;
                for (int fi = 0; fi <= Grid_Row; fi++)
                {
                    xx = (float)(f_interval * fi);
                    //if ( xx == 0 )
                    //{
                    //    xx = 1;
                    //}
                    yy = (float)picbx_ScanWave.Height;
                    e.Graphics.DrawLine(opaquePenW, xx, (float)0, xx, yy);
                }
                //�א�
                float start_pos = f_interval / 2;
                for (int fi = 0; fi < Grid_Row; fi++)
                {
                    xx = start_pos + (float)(f_interval * fi);
                    yy = (float)picbx_ScanWave.Height;
                    e.Graphics.DrawLine(opaquePen, xx, (float)0, xx, yy);
                }
                //�����`��
                //����
                f_interval = (float)(picbx_ScanWave.Height - 1) / (float)Grid_Col;
                for (int fi = 0; fi <= Grid_Col; fi++)
                {
                    xx = (float)picbx_ScanWave.Width;
                    yy = (float)(f_interval * fi);
                    //if (yy == 0)
                    //{
                    //    yy = 1;
                    //}
                    e.Graphics.DrawLine(opaquePenW, (float)0, yy, xx, yy);
                }
                //�א�
                start_pos = f_interval / 2;
                for (int fi = 0; fi < Grid_Col; fi++)
                {
                    xx = (float)picbx_ScanWave.Width;
                    yy = start_pos + (float)(f_interval * fi);
                    e.Graphics.DrawLine(opaquePen, (float)0, yy, xx, yy);
                }

                //��M���x�`��
                if (scan_info.scan_comp_num >= 2)
                {
                    my_DrawWave(sender, e);
                }
            }
            catch
            {
            }
            finally
            {
                // ���\�[�X���������
                if (opaquePen != null)
                {
                    opaquePen.Dispose();
                }
                if (opaquePenW != null)
                {
                    opaquePenW.Dispose();
                }
            }

        }
        /// <summary>
        /// �X�L�����g�`�\��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void my_DrawWave(object sender, PaintEventArgs e)
        {
            Pen rssiPen = null;
            Pen snrPen = null;
            Pen barPen = null;
            int alp = 0;

            try
            {
                //��M���x�`��

                //�ڐ���X�V
                picbx_rssi_scale_1.Image = imglist_RSSI_scale.Images[scan_info.rssi_scale[1]];
                picbx_rssi_scale_2.Image = imglist_RSSI_scale.Images[scan_info.rssi_scale[2]];
                picbx_snr_scale_1.Image = imglist_SNR_scale.Images[scan_info.snr_scale[1]];
                picbx_snr_scale_2.Image = imglist_SNR_scale.Images[scan_info.snr_scale[2]];

                PointF[] rssi_point = new PointF[scan_info.scan_comp_num];
                PointF[] snr_point = new PointF[scan_info.scan_comp_num];
                // ���g��������̃s�N�Z����
                float pix_freq = (float)(picbx_ScanWave.Width - 1) / (float)(scan_info.freq_max - scan_info.freq_min);
                // ��M���x������̃s�N�Z����
                float pix_rssi = (float)picbx_ScanWave.Height / (float)scan_info.max_rssi_range;
                // SNR������̃s�N�Z����
                float pix_snr = (float)picbx_ScanWave.Height / (float)scan_info.max_snr_range;
                float last_xx = 0;
                for (int fi = 0; fi < scan_info.scan_comp_num; fi++)
                {
                    if (scan_info.scan_comp[fi] == true)
                    {   //��M�ς�
                        rssi_point[fi].X = pix_freq * (float)(scan_info.freq[fi] - scan_info.freq_min);
                        rssi_point[fi].Y = (float)(picbx_ScanWave.Height - 1) - (pix_rssi * (float)scan_info.rssi[fi]);
                        snr_point[fi].X = pix_freq * (float)(scan_info.freq[fi] - scan_info.freq_min);
                        snr_point[fi].Y = (float)(picbx_ScanWave.Height - 1) - (pix_snr * (float)scan_info.snr[fi]);
                        last_xx = rssi_point[fi].X;
                    }
                    else
                    {
                        //����M
                        rssi_point[fi].X = 0;
                        rssi_point[fi].Y = 0;
                        snr_point[fi].X = 0;
                        snr_point[fi].Y = 0;
                    }
                }
                alp = (int)50 * 255 / 100;
                rssiPen = new Pen(Color.FromArgb(alp, 109, 130, 160), (float)2);
                e.Graphics.DrawLines(rssiPen, rssi_point);

                alp = (int)50 * 255 / 100;
                snrPen = new Pen(Color.FromArgb(alp, 174, 98, 83), (float)2);
                e.Graphics.DrawLines(snrPen, snr_point);

                if (scan_info.num > scan_info.scan_comp_num)
                {
                    alp = (int)50 * 255 / 100;
                    Rectangle ra = new Rectangle((int)(last_xx + 5), 0, 20, picbx_ScanWave.Height);
                    LinearGradientBrush lgb = new LinearGradientBrush(ra, Color.FromArgb(0, 0xFF, 0xFF, 0xFF), Color.FromArgb(255, 0xFF, 0xFF, 0xFF), (double)0);
                    barPen = new Pen(lgb, (float)20);
                    e.Graphics.DrawLine(barPen, (float)(last_xx - 5), (float)0, (float)(last_xx - 5), (float)picbx_ScanWave.Height);
                }
            }
            catch
            {
            }
            finally
            {
                // ���\�[�X���������
                if (rssiPen != null)
                {
                    rssiPen.Dispose();
                }
                if (snrPen != null)
                {
                    snrPen.Dispose();
                }
                if (barPen != null)
                {
                    barPen.Dispose();
                }
            }

        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //FUNCTION:	CheckIfPresentAndGetUSBDevicePath()
        //PURPOSE:	Check if a USB device is currently plugged in with a matching VID and PID
        //INPUT:	Uses globally declared String DevicePath, globally declared GUID, and the MY_DEVICE_ID constant.
        //OUTPUT:	Returns BOOL.  TRUE when device with matching VID/PID found.  FALSE if device with VID/PID could not be found.
        //			When returns TRUE, the globally accessable "DetailedInterfaceDataStructure" will contain the device path
        //			to the USB device with the matching VID/PID.

        bool CheckIfPresentAndGetUSBDevicePath()
        {
		    /* 
		    Before we can "connect" our application to our USB embedded device, we must first find the device.
		    A USB bus can have many devices simultaneously connected, so somehow we have to find our device only.
		    This is done with the Vendor ID (VID) and Product ID (PID).  Each USB product line should have
		    a unique combination of VID and PID.  

		    Microsoft has created a number of functions which are useful for finding plug and play devices.  Documentation
		    for each function used can be found in the MSDN library.  We will be using the following functions (unmanaged C functions):

		    SetupDiGetClassDevs()					//provided by setupapi.dll, which comes with Windows
		    SetupDiEnumDeviceInterfaces()			//provided by setupapi.dll, which comes with Windows
		    GetLastError()							//provided by kernel32.dll, which comes with Windows
		    SetupDiDestroyDeviceInfoList()			//provided by setupapi.dll, which comes with Windows
		    SetupDiGetDeviceInterfaceDetail()		//provided by setupapi.dll, which comes with Windows
		    SetupDiGetDeviceRegistryProperty()		//provided by setupapi.dll, which comes with Windows
		    CreateFile()							//provided by kernel32.dll, which comes with Windows

            In order to call these unmanaged functions, the Marshal class is very useful.
             
		    We will also be using the following unusual data types and structures.  Documentation can also be found in
		    the MSDN library:

		    PSP_DEVICE_INTERFACE_DATA
		    PSP_DEVICE_INTERFACE_DETAIL_DATA
		    SP_DEVINFO_DATA
		    HDEVINFO
		    HANDLE
		    GUID

		    The ultimate objective of the following code is to get the device path, which will be used elsewhere for getting
		    read and write handles to the USB device.  Once the read/write handles are opened, only then can this
		    PC application begin reading/writing to the USB device using the WriteFile() and ReadFile() functions.

		    Getting the device path is a multi-step round about process, which requires calling several of the
		    SetupDixxx() functions provided by setupapi.dll.
		    */

            try
            {
		        IntPtr DeviceInfoTable = IntPtr.Zero;
		        SP_DEVICE_INTERFACE_DATA InterfaceDataStructure = new SP_DEVICE_INTERFACE_DATA();
                SP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA();
                SP_DEVINFO_DATA DevInfoData = new SP_DEVINFO_DATA();

		        uint InterfaceIndex = 0;
		        uint dwRegType = 0;
		        uint dwRegSize = 0;
                uint dwRegSize2 = 0;
		        uint StructureSize = 0;
		        IntPtr PropertyValueBuffer = IntPtr.Zero;
		        bool MatchFound = false;
		        uint ErrorStatus;
		        uint LoopCounter = 0;

                //Use the formatting: "Vid_xxxx&Pid_xxxx" where xxxx is a 16-bit hexadecimal number.
                //Make sure the value appearing in the parathesis matches the USB device descriptor
                //of the device that this aplication is intending to find.
                String DeviceIDToFind = DEF_VID_PID;

		        //First populate a list of plugged in devices (by specifying "DIGCF_PRESENT"), which are of the specified class GUID. 
		        DeviceInfoTable = SetupDiGetClassDevs(ref InterfaceClassGuid, IntPtr.Zero, IntPtr.Zero, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

                if(DeviceInfoTable != IntPtr.Zero)
                {
		            //Now look through the list we just populated.  We are trying to see if any of them match our device. 
		            while(true)
		            {
                        InterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(InterfaceDataStructure);
			            if(SetupDiEnumDeviceInterfaces(DeviceInfoTable, IntPtr.Zero, ref InterfaceClassGuid, InterfaceIndex, ref InterfaceDataStructure))
			            {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
                            if (ErrorStatus == ERROR_NO_MORE_ITEMS)	//Did we reach the end of the list of matching devices in the DeviceInfoTable?
				            {	//Cound not find the device.  Must not have been attached.
					            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
					            return false;		
				            }
			            }
			            else	//Else some other kind of unknown error ocurred...
			            {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
				            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
				            return false;	
			            }

			            //Now retrieve the hardware ID from the registry.  The hardware ID contains the VID and PID, which we will then 
			            //check to see if it is the correct device or not.

			            //Initialize an appropriate SP_DEVINFO_DATA structure.  We need this structure for SetupDiGetDeviceRegistryProperty().
                        DevInfoData.cbSize = (uint)Marshal.SizeOf(DevInfoData);
			            SetupDiEnumDeviceInfo(DeviceInfoTable, InterfaceIndex, ref DevInfoData);

			            //First query for the size of the hardware ID, so we can know how big a buffer to allocate for the data.
			            SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, IntPtr.Zero, 0, ref dwRegSize);

			            //Allocate a buffer for the hardware ID.
                        //Should normally work, but could throw exception "OutOfMemoryException" if not enough resources available.
                        PropertyValueBuffer = Marshal.AllocHGlobal((int)dwRegSize);

			            //Retrieve the hardware IDs for the current device we are looking at.  PropertyValueBuffer gets filled with a 
			            //REG_MULTI_SZ (array of null terminated strings).  To find a device, we only care about the very first string in the
			            //buffer, which will be the "device ID".  The device ID is a string which contains the VID and PID, in the example 
			            //format "Vid_04d8&Pid_003f".
                        SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, PropertyValueBuffer, dwRegSize, ref dwRegSize2);

			            //Now check if the first string in the hardware ID matches the device ID of the USB device we are trying to find.
			            String DeviceIDFromRegistry = Marshal.PtrToStringUni(PropertyValueBuffer); //Make a new string, fill it with the contents from the PropertyValueBuffer

			            Marshal.FreeHGlobal(PropertyValueBuffer);		//No longer need the PropertyValueBuffer, free the memory to prevent potential memory leaks

			            //Convert both strings to lower case.  This makes the code more robust/portable accross OS Versions
			            DeviceIDFromRegistry = DeviceIDFromRegistry.ToLowerInvariant();	
			            DeviceIDToFind = DeviceIDToFind.ToLowerInvariant();				
			            //Now check if the hardware ID we are looking at contains the correct VID/PID
			            MatchFound = DeviceIDFromRegistry.Contains(DeviceIDToFind);		
			            if(MatchFound == true)
			            {
                            //Device must have been found.  In order to open I/O file handle(s), we will need the actual device path first.
				            //We can get the path by calling SetupDiGetDeviceInterfaceDetail(), however, we have to call this function twice:  The first
				            //time to get the size of the required structure/buffer to hold the detailed interface data, then a second time to actually 
				            //get the structure (after we have allocated enough memory for the structure.)
                            DetailedInterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(DetailedInterfaceDataStructure);
				            //First call populates "StructureSize" with the correct value
				            SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, IntPtr.Zero, 0, ref StructureSize, IntPtr.Zero);
                            //Need to call SetupDiGetDeviceInterfaceDetail() again, this time specifying a pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA buffer with the correct size of RAM allocated.
                            //First need to allocate the unmanaged buffer and get a pointer to it.
                            IntPtr pUnmanagedDetailedInterfaceDataStructure = IntPtr.Zero;  //Declare a pointer.
                            pUnmanagedDetailedInterfaceDataStructure = Marshal.AllocHGlobal((int)StructureSize);    //Reserve some unmanaged memory for the structure.
                            DetailedInterfaceDataStructure.cbSize = 6; //Initialize the cbSize parameter (4 bytes for DWORD + 2 bytes for unicode null terminator)
                            Marshal.StructureToPtr(DetailedInterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, false); //Copy managed structure contents into the unmanaged memory buffer.

                            //Now call SetupDiGetDeviceInterfaceDetail() a second time to receive the device path in the structure at pUnmanagedDetailedInterfaceDataStructure.
                            if (SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, StructureSize, IntPtr.Zero, IntPtr.Zero))
                            {
                                //Need to extract the path information from the unmanaged "structure".  The path starts at (pUnmanagedDetailedInterfaceDataStructure + sizeof(DWORD)).
                                IntPtr pToDevicePath = new IntPtr((uint)pUnmanagedDetailedInterfaceDataStructure.ToInt32() + 4);  //Add 4 to the pointer (to get the pointer to point to the path, instead of the DWORD cbSize parameter)
                                DevicePath = Marshal.PtrToStringUni(pToDevicePath); //Now copy the path information into the globally defined DevicePath String.
                                
                                //We now have the proper device path, and we can finally use the path to open I/O handle(s) to the device.
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return true;    //Returning the device path in the global DevicePath String
                            }
                            else //Some unknown failure occurred
                            {
                                uint ErrorCode = (uint)Marshal.GetLastWin32Error();
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return false;    
                            }
                        }

			            InterfaceIndex++;	
			            //Keep looping until we either find a device with matching VID and PID, or until we run out of devices to check.
			            //However, just in case some unexpected error occurs, keep track of the number of loops executed.
			            //If the number of loops exceeds a very large number, exit anyway, to prevent inadvertent infinite looping.
			            LoopCounter++;
			            if(LoopCounter == 10000000)	//Surely there aren't more than 10 million devices attached to any forseeable PC...
			            {
				            return false;
			            }
		            }//end of while(true)
                }
                return false;
            }//end of try
            catch
            {
                //Something went wrong if PC gets here.  Maybe a Marshal.AllocHGlobal() failed due to insufficient resources or something.
			    return false;	
            }
        }
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        //This is a callback function that gets called when a Windows message is received by the form.
        //We will receive various different types of messages, but the ones we really want to use are the WM_DEVICECHANGE messages.
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_DEVICECHANGE)
            {
                if (((int)m.WParam == DBT_DEVICEARRIVAL) || ((int)m.WParam == DBT_DEVICEREMOVEPENDING) || ((int)m.WParam == DBT_DEVICEREMOVECOMPLETE) || ((int)m.WParam == DBT_CONFIGCHANGED))
                {
                    //WM_DEVICECHANGE messages by themselves are quite generic, and can be caused by a number of different
                    //sources, not just your USB hardware device.  Therefore, must check to find out if any changes relavant
                    //to your device (with known VID/PID) took place before doing any kind of opening or closing of handles/endpoints.
                    //(the message could have been totally unrelated to your application/USB device)

                    if (CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
                    {
                        //If executes to here, this means the device is currently attached and was found.
                        //This code needs to decide however what to do, based on whether or not the device was previously known to be
                        //attached or not.
                        if ((AttachedState == false) || (AttachedButBroken == true))	//Check the previous attachment state
                        {
                            uint ErrorStatusWrite;
                            uint ErrorStatusRead;

                            //We obtained the proper device path (from CheckIfPresentAndGetUSBDevicePath() function call), and it
                            //is now possible to open read and write handles to the device.
                            WriteHandleToUSBDevice = CreateFile(DevicePath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                            ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                            ReadHandleToUSBDevice = CreateFile(DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                            ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

                            if ((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
                            {
                                AttachedState = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
                                AttachedButBroken = false;
                                connect_status_lbl.Text = "�ڑ�����܂����B";

                            }
                            else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
                            {
                                AttachedState = false;		//Let the rest of this application known not to read/write to the device.
                                AttachedButBroken = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
                                if (ErrorStatusWrite == ERROR_SUCCESS)
                                    WriteHandleToUSBDevice.Close();
                                if (ErrorStatusRead == ERROR_SUCCESS)
                                    ReadHandleToUSBDevice.Close();
                            }
                        }
                        //else we did find the device, but AttachedState was already true.  In this case, don't do anything to the read/write handles,
                        //since the WM_DEVICECHANGE message presumably wasn't caused by our USB device.  
                    }
                    else	//Device must not be connected (or not programmed with correct firmware)
                    {
                        if (AttachedState == true)		//If it is currently set to true, that means the device was just now disconnected
                        {
                            AttachedState = false;
                            WriteHandleToUSBDevice.Close();
                            ReadHandleToUSBDevice.Close();
                        }
                        AttachedState = false;
                        AttachedButBroken = false;
                    }
                }
            } //end of: if(m.Msg == WM_DEVICECHANGE)

            base.WndProc(ref m);
        } //end of: WndProc() function
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        private void ReadWriteThread_DoWork(object sender, DoWorkEventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

            /*This thread does the actual USB read/write operations (but only when AttachedState == true) to the USB device.
            It is generally preferrable to write applications so that read and write operations are handled in a separate
            thread from the main form.  This makes it so that the main form can remain responsive, even if the I/O operations
            take a very long time to complete.

            Since this is a separate thread, this code below executes independently from the rest of the
            code in this application.  All this thread does is read and write to the USB device.  It does not update
            the form directly with the new information it obtains (such as the ANxx/POT Voltage or pushbutton state).
            The information that this thread obtains is stored in atomic global variables.
            Form updates are handled by the FormUpdateTimer Tick event handler function.

            This application sends packets to the endpoint buffer on the USB device by using the "WriteFile()" function.
            This application receives packets from the endpoint buffer on the USB device by using the "ReadFile()" function.
            Both of these functions are documented in the MSDN library.  Calling ReadFile() is a not perfectly straight
            foward in C# environment, since one of the input parameters is a pointer to a buffer that gets filled by ReadFile().
            The ReadFile() function is therefore called through a wrapper function ReadFileManagedBuffer().

            All ReadFile() and WriteFile() operations in this example project are synchronous.  They are blocking function
            calls and only return when they are complete, or if they fail because of some event, such as the user unplugging
            the device.  It is possible to call these functions with "overlapped" structures, and use them as non-blocking
            asynchronous I/O function calls.  

            Note:  This code may perform differently on some machines when the USB device is plugged into the host through a
            USB 2.0 hub, as opposed to a direct connection to a root port on the PC.  In some cases the data rate may be slower
            when the device is connected through a USB 2.0 hub.  This performance difference is believed to be caused by
            the issue described in Microsoft knowledge base article 940021:
            http://support.microsoft.com/kb/940021/en-us 

            Higher effective bandwidth (up to the maximum offered by interrupt endpoints), both when connected
            directly and through a USB 2.0 hub, can generally be achieved by queuing up multiple pending read and/or
            write requests simultaneously.  This can be done when using	asynchronous I/O operations (calling ReadFile() and
            WriteFile()	with overlapped structures).  The Microchip	HID USB Bootloader application uses asynchronous I/O
            for some USB operations and the source code can be used	as an example.*/


            Byte[] OUTBuffer = new byte[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
		    Byte[] INBuffer = new byte[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
		    uint BytesWritten = 0;
		    uint BytesRead = 0;

		    while(true)
		    {
                try
                {
                    if (AttachedState == true)	//Do not try to use the read/write handles unless the USB device is attached and ready
                    {

                        //Get the pushbutton state from the microcontroller firmware.
                        OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                        OUTBuffer[1] = 0x40;		//0x81 is the "Get Pushbutton State" command in the firmware
                        for (uint i = 2; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                        //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                        if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                        {
                            //Now get the response packet from the firmware.
                            INBuffer[0] = 0;
                            {
                                if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                {
                                    //INBuffer[0] is the report ID, which we don't care about.
                                    //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                    //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                    if (INBuffer[1] == 0x40)
                                    {
                                        Debug_Array[0] = (int)(INBuffer[2]);
                                        Debug_Array[1] = (int)(INBuffer[3]);
                                        Debug_Array[2] = (int)(INBuffer[4]);
                                        Debug_Array[3] = (int)(INBuffer[5]);
                                        Debug_Array[4] = (int)(INBuffer[6]);
                                        Debug_Array[5] = (int)(INBuffer[7]);
                                        Debug_Array[6] = (int)(INBuffer[8]);
                                        Debug_Array[7] = (int)(INBuffer[9]);
                                        Debug_Array[8] = (int)(INBuffer[10]);
                                        Debug_Array[9] = (int)(INBuffer[11]);
                                        Debug_Array[10] = (int)(INBuffer[12]);
                                        Debug_Array[11] = (int)(INBuffer[13]);
                                        Debug_Array[12] = (int)(INBuffer[14]);
                                        Debug_Array[13] = (int)(INBuffer[15]);
                                        Debug_Array[14] = (int)(INBuffer[16]);
                                        //Debug_3++;
                                    }
                                }
                            }
                        }
                        // Scan�����s���@�܂��́@Scan���s���̎�M��Ԏ擾��
                        if (scan_status == SCAN_STATUS_NONE || scan_status == SCAN_STATUS_RQS)
                        {
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x26;		//0x81 is the "Get Pushbutton State" command in the firmware
                            for (uint i = 2; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x26)
                                        {
                                            if ((int)(INBuffer[2]) == 0)
                                            {

                                                //int tmp_rcv_freq_am = (int)(INBuffer[4]);
                                                //tmp_rcv_freq_am = (tmp_rcv_freq_am << 8) + (int)(INBuffer[5]);
                                                if (INBuffer[3] == BAND_AM)
                                                {
                                                    rcv_band = INBuffer[3];
                                                    rcv_freq_am = (int)(INBuffer[4]);
                                                    rcv_freq_am = (rcv_freq_am << 8) + (int)(INBuffer[5]);
                                                    rcv_vol = INBuffer[6];
                                                    rcv_rssi = INBuffer[7];
                                                    rcv_snr = INBuffer[8];
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x27;		//0x81 is the "Get Pushbutton State" command in the firmware
                            for (uint i = 2; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x27)
                                        {
                                            if ((int)(INBuffer[2]) == 0)
                                            {
                                                //int tmp_rcv_freq_fm = (int)(INBuffer[4]);
                                                //tmp_rcv_freq_fm = (tmp_rcv_freq_fm << 8) + (int)(INBuffer[5]);
                                                if (INBuffer[3] == BAND_FM)
                                                {
                                                    rcv_band = INBuffer[3];
                                                    rcv_freq_fm = (int)(INBuffer[4]);
                                                    rcv_freq_fm = (rcv_freq_fm << 8) + (int)(INBuffer[5]);
                                                    rcv_vol = INBuffer[6];
                                                    rcv_rssi = INBuffer[7];
                                                    rcv_snr = INBuffer[8];
                                                    rcv_stereo = INBuffer[9];
                                                    rcv_stereo_blend = INBuffer[10];
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // Scan���s���̎�M���g���Z�b�g��
                        if (scan_status == SCAN_STATUS_FREQ_SET)
                        {
                            if (scan_info.band == BAND_AM)
                            {
                                AM_Set_Freq = scan_info.freq[scan_info.scan_idx];
                                b_AMSet_flag = true;
                            }
                            else if (scan_info.band == BAND_FM)
                            {
                                FM_Set_Freq = scan_info.freq[scan_info.scan_idx];
                                b_FMSet_flag = true;
                            }
                            scan_status = SCAN_STATUS_RQS;
                        }
                        // Reset
                        if (b_ReSet_flag == true)
                        {
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x28;		//0x21 is the "Get Pushbutton State" command in the firmware

                            b_ReSet_flag = false;

                            for (uint i = 2; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x28)
                                        {

                                        }
                                    }
                                }
                            }
                        }
                        // AM Set Click
                        if (b_AMSet_flag == true)
                        {
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x21;		//0x21 is the "Get Pushbutton State" command in the firmware

                            int freq = AM_Set_Freq;
                            OUTBuffer[2] = (byte)((freq >> 8) & 0xFF);  //FREQ HI
                            OUTBuffer[3] = (byte)(freq & 0xFF);         //FREQ LO

                            b_AMSet_flag = false;

                            for (uint i = 5; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x21)
                                        {

                                        }
                                    }
                                }
                            }
                        }
                        // FM Set Click
                        if (b_FMSet_flag == true)
                        {
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x22;		//0x21 is the "Get Pushbutton State" command in the firmware

                            int freq = FM_Set_Freq;
                            OUTBuffer[2] = (byte)((freq >> 8) & 0xFF);  //FREQ HI
                            OUTBuffer[3] = (byte)(freq & 0xFF);         //FREQ LO

                            b_FMSet_flag = false;

                            for (uint i = 5; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x22)
                                        {

                                        }
                                    }
                                }
                            }
                        }
                        // Seek Down Click
                        if (b_SeekDown_flag == true)
                        {
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.

                            if (rcv_band == BAND_FM)
                            {
                                OUTBuffer[1] = 0x24;		//0x21 is the "Get Pushbutton State" command in the firmware
                            }
                            else
                            {
                                OUTBuffer[1] = 0x23;		//0x21 is the "Get Pushbutton State" command in the firmware
                            }

                            OUTBuffer[2] = SEEK_DOWN;  //SEEK

                            b_SeekDown_flag = false;

                            for (uint i = 5; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x23)
                                        {

                                        }
                                        else if (INBuffer[1] == 0x24)
                                        {
                                        }
                                    }
                                }
                            }
                        }
                        // Seek Up Click
                        if (b_SeekUp_flag == true)
                        {
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.

                            if (rcv_band == BAND_FM)
                            {
                                OUTBuffer[1] = 0x24;		//0x21 is the "Get Pushbutton State" command in the firmware
                            }
                            else
                            {
                                OUTBuffer[1] = 0x23;		//0x21 is the "Get Pushbutton State" command in the firmware
                            }

                            OUTBuffer[2] = SEEK_UP;  //SEEK

                            b_SeekUp_flag = false;

                            for (uint i = 5; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x23)
                                        {

                                        }
                                        else if (INBuffer[1] == 0x24)
                                        {
                                        }
                                    }
                                }
                            }
                        }
                        // Volume Set Click
                        if (b_VolSet_flag == true)
                        {
                            b_VolSet_flag = false;

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x25;		//0x21 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)(Set_Volume & 0xFF);
                            for (uint i = 3; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x25)
                                        {

                                        }
                                    }
                                }
                            }
                        }
                    } //end of: if(AttachedState == true)
                    else
                    {
                        Thread.Sleep(5);	//Add a small delay.  Otherwise, this while(true) loop can execute very fast and cause 
                                            //high CPU utilization, with no particular benefit to the application.
                    }
                }
                catch
                {
                    //Exceptions can occur during the read or write operations.  For example,
                    //exceptions may occur if for instance the USB device is physically unplugged
                    //from the host while the above read/write functions are executing.

                    //Don't need to do anything special in this case.  The application will automatically
                    //re-establish communications based on the global AttachedState boolean variable used
                    //in conjunction with the WM_DEVICECHANGE messages to dyanmically respond to Plug and Play
                    //USB connection events.
                }

		    } //end of while(true) loop
            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }

        private void FormUpdateTimer_Tick(object sender, EventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
            //This timer tick event handler function is used to update the user interface on the form, based on data
            //obtained asynchronously by the ReadWriteThread and the WM_DEVICECHANGE event handler functions.

            //Check if user interface on the form should be enabled or not, based on the attachment state of the USB device.
            if (AttachedState == true)
            {
                //Device is connected and ready to communicate, enable user interface on the form 
                connect_status_lbl.Text = "�ڑ�����܂����B";

                if (scan_status == SCAN_STATUS_NONE)
                {
                    btn_Scan.Enabled = true;
                }
            }
            if ((AttachedState == false) || (AttachedButBroken == true))
            {
                //Device not available to communicate. Disable user interface on the form.
                connect_status_lbl.Text = "�ڑ�����Ă��܂���B";

                if (scan_status == SCAN_STATUS_NONE)
                {
                    btn_Scan.Enabled = false;
                }
            }

            // ���g���\���X�V
            my_Disp_Band(AttachedState, btn_Scan.Enabled, rcv_band, rcv_freq_am, rcv_freq_fm);
            // �{�����[���\���X�V
            my_Disp_Volume(AttachedState, true, rcv_vol, Mute_Volume_backup, chkbx_Mute.Checked);


            //����������
            //debug
            //////////lbl_TimerOn.Text = timer_info.exe_timer_on_date.ToString();
            //////////lbl_TimerOff.Text = timer_info.exe_timer_off_date.ToString();

            //Update the various status indicators on the form with the latest info obtained from the ReadWriteThread()
            if (AttachedState == true)
            {

                if (AttachedFirstTime == true)
                {
                    AttachedFirstTime = false;
                }

                // ���g���ύX�����܂����������m�F
                // �ς���Ă��Ȃ��悤�Ȃ烊�Z�b�g�������čēx�ύX�v��
                if (b_AMChange_Req_flag == true )
                {
                    if (rcv_band == BAND_AM && rcv_freq_am == AM_Set_Freq)
                    {
                        b_AMChange_Req_flag = false;
                    }
                    else
                    {
                        Freq_Change_Count++;
                    }

                    if (Freq_Change_Count > 20)
                    {
                        b_ReSet_flag = true;
                        b_AMSet_flag = true;
                        Freq_Change_Count = 0;
                    }
                }
                if (b_FMChange_Req_flag == true)
                {
                    if (rcv_band == BAND_FM && rcv_freq_fm == FM_Set_Freq)
                    {
                        b_FMChange_Req_flag = false;
                    }
                    else
                    {
                        Freq_Change_Count++;
                    }

                    if (Freq_Change_Count > 20)
                    {
                        b_ReSet_flag = true;
                        b_FMSet_flag = true;
                        Freq_Change_Count = 0;
                    }
                }


                //DEBUG
                //DEBUG
                //DEBUG
                //���W�I��ԕ\��
                string str_temp = "";
                if (rcv_band == BAND_FM)
                {
                    float f_freq = rcv_freq_fm;
                    f_freq = f_freq / 100;
                    Freq_lbl.Text = string.Format("{0:F2}", f_freq) + "MHz";
                    //picbx_Band.BackgroundImage = imglist_Band.Images[BAND_FM];
                }
                else
                {
                    Freq_lbl.Text = rcv_freq_am.ToString() + "kHz";
                    //picbx_Band.BackgroundImage = imglist_Band.Images[BAND_AM];
                }
                if (rcv_band == BAND_FM && rcv_stereo == 1)
                {
                    str_temp = "*";
                }
                str_temp += rcv_rssi.ToString() + " dBuV";
                Level_lbl.Text = str_temp;
                SNR_lbl.Text = "SNR " + rcv_snr.ToString() + " dB";
                Vol_lbl.Text = "Vol " + rcv_vol.ToString();

                //DEBUG
                //DEBUG
                //DEBUG
                string debug_str = "";
                colum_lbl.Text = string.Format("{0:000} : {1:000} : {2:000} : {3:000} : {4:000} : {5:000} : {6:000} : {7:000} : {8:000} : {9:000} : {10:000} : {11:000} : {12:000} : {13:000} : {14:000}",
                                        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14);
                debug01_lbl.Text = string.Format("{0:X3} : {1:X3} : {2:X3} : {3:X3} : {4:X3} : {5:X3} : {6:X3} : {7:X3} : {8:X3} : {9:X3} : {10:X3} : {11:X3} : {12:X3} : {13:X3} : {14:X3}",
                                       Debug_Array[0], Debug_Array[1], Debug_Array[2], Debug_Array[3], Debug_Array[4], Debug_Array[5], Debug_Array[6], Debug_Array[7], Debug_Array[8], Debug_Array[9], Debug_Array[10], Debug_Array[11], Debug_Array[12], Debug_Array[13], Debug_Array[14]);
                debug_str = "";
                for (int fi = 0; fi < 10; fi++)
                {
                    debug_str += string.Format("0x{0:X2}:", Debug_Arr[fi]);
                }
                debug02_lbl.Text = debug_str;
                debug_str = "";
                for (int fi = 0; fi < 4; fi++)
                {
                    debug_str += string.Format("0x{0:X2}:", Debug_Arr2[fi]);
                }
                debug03_lbl.Text = debug_str;

                //if (rcv_band == BAND_AM)
                //{
                //    lbl_debug.Text = string.Format("AM {0}", AM_Set_Freq);
                //}
                //else
                //{
                //    lbl_debug.Text = string.Format("FM {0:F2}", (float)(FM_Set_Freq)/100);
                //}
                lbl_debug.Text = Mute_Volume_backup.ToString();
            }
            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //--------------------------------------------------------------------------------------------------------------------------
        //FUNCTION:	ReadFileManagedBuffer()
        //PURPOSE:	Wrapper function to call ReadFile()
        //
        //INPUT:	Uses managed versions of the same input parameters as ReadFile() uses.
        //
        //OUTPUT:	Returns boolean indicating if the function call was successful or not.
        //          Also returns data in the byte[] INBuffer, and the number of bytes read. 
        //
        //Notes:    Wrapper function used to call the ReadFile() function.  ReadFile() takes a pointer to an unmanaged buffer and deposits
        //          the bytes read into the buffer.  However, can't pass a pointer to a managed buffer directly to ReadFile().
        //          This ReadFileManagedBuffer() is a wrapper function to make it so application code can call ReadFile() easier
        //          by specifying a managed buffer.
        //--------------------------------------------------------------------------------------------------------------------------
        public unsafe bool ReadFileManagedBuffer(SafeFileHandle hFile, byte[] INBuffer, uint nNumberOfBytesToRead, ref uint lpNumberOfBytesRead, IntPtr lpOverlapped)
        {
            IntPtr pINBuffer = IntPtr.Zero;

            try
            {
                pINBuffer = Marshal.AllocHGlobal((int)nNumberOfBytesToRead);    //Allocate some unmanged RAM for the receive data buffer.

                if (ReadFile(hFile, pINBuffer, nNumberOfBytesToRead, ref lpNumberOfBytesRead, lpOverlapped))
                {
                    Marshal.Copy(pINBuffer, INBuffer, 0, (int)lpNumberOfBytesRead);    //Copy over the data from unmanged memory into the managed byte[] INBuffer
                    Marshal.FreeHGlobal(pINBuffer);
                    return true;
                }
                else
                {
                    Marshal.FreeHGlobal(pINBuffer);
                    return false;
                }

            }
            catch
            {
                if (pINBuffer != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(pINBuffer);
                }
                return false;
            }
        }

        private void AMSet_btn_Click(object sender, EventArgs e)
        {
            AM_Set_Freq = (int)numericUpDown1.Value;
            b_AMSet_flag = true;
        }

        private void FMSet_btn_Click(object sender, EventArgs e)
        {
            FM_Set_Freq = (int)(numericUpDown2.Value * 100);
            b_FMSet_flag = true;
        }

        private void VolumeSet_btn_Click(object sender, EventArgs e)
        {
            Set_Volume = (int)numericUpDown3.Value;
            b_VolSet_flag = true;
        }

        private void SeekDown_btn_Click(object sender, EventArgs e)
        {
            b_SeekDown_flag = true;
        }

        private void SeekUp_btn_Click(object sender, EventArgs e)
        {
            b_SeekUp_flag = true;
        }

        private void btn_Minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        Point TitleBarMouseClickPos;
        bool b_TitleBarMouseClickFlag = false;
        private void picbx_TitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                TitleBarMouseClickPos.X = e.X;
                TitleBarMouseClickPos.Y = e.Y;
                b_TitleBarMouseClickFlag = true;
            }
            catch
            {
            }
        }

        private void picbx_TitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                b_TitleBarMouseClickFlag = false;
            }
            catch
            {
            }
        }

        private void picbx_TitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if (b_TitleBarMouseClickFlag == true)
                {
                    this.Left += e.X - TitleBarMouseClickPos.X;
                    this.Top += e.Y - TitleBarMouseClickPos.Y;
                }
            }
            catch
            {
            }
        }

        private void btn_Band_Click(object sender, EventArgs e)
        {
            try
            {
                if(rcv_band == BAND_AM)
                {
                    FM_Set_Freq = rcv_freq_fm;
                    if (FM_Set_Freq < FM_FRQ_MIN)
                    {
                        FM_Set_Freq = FM_FRQ_MIN;
                    }
                    else if (FM_FRQ_MAX < FM_Set_Freq)
                    {
                        FM_Set_Freq = FM_FRQ_MAX;
                    }
                    b_FMSet_flag = true;

                    if (b_FMChange_Req_flag == false)
                    {
                        b_AMChange_Req_flag = false;
                        b_FMChange_Req_flag = true;
                        Freq_Change_Count = 0;
                    }
                }
                else if (rcv_band == BAND_FM)
                {
                    AM_Set_Freq = rcv_freq_am;
                    if (AM_Set_Freq < AM_FRQ_MIN)
                    {
                        AM_Set_Freq = AM_FRQ_MIN;
                    }
                    else if (AM_FRQ_MAX < AM_Set_Freq)
                    {
                        AM_Set_Freq = AM_FRQ_MAX;
                    }
                    b_AMSet_flag = true;

                    if (b_AMChange_Req_flag == false)
                    {
                        b_AMChange_Req_flag = true;
                        b_FMChange_Req_flag = false;
                        Freq_Change_Count = 0;
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_Scan_Click(object sender, EventArgs e)
        {
            try
            {
                btn_Scan.Enabled = false;

                //Scan��Ԃ���������
                scan_status = SCAN_STATUS_INIT;

                if(rcv_band == BAND_FM)
                {
                    if (BandWidth == BANDWIDTH_JAPAN)
                    {
                        scan_info.init(rcv_band, rcv_freq_fm, FM_FRQ_MIN_JP, FM_FRQ_MAX_JP, FM_FRQ_SEEK_SPAN_JP, FM_FRQ_MIN, FM_FRQ_MAX);
                    }
                    else
                    {
                        scan_info.init(rcv_band, rcv_freq_fm, FM_FRQ_MIN, FM_FRQ_MAX, FM_FRQ_SEEK_SPAN, FM_FRQ_MIN, FM_FRQ_MAX);
                    }
                }
                else if(rcv_band == BAND_AM)
                {
                    if (BandWidth == BANDWIDTH_JAPAN)
                    {
                        scan_info.init(rcv_band, rcv_freq_am, AM_FRQ_MIN_JP, AM_FRQ_MAX_JP, 1, AM_FRQ_MIN, AM_FRQ_MAX);
                    }
                    else
                    {
                        scan_info.init(rcv_band, rcv_freq_am, AM_FRQ_MIN, AM_FRQ_MAX, 1, AM_FRQ_MIN, AM_FRQ_MAX);
                    }
                }

                // Timer�Z�b�g
                WaveScanTimer.Enabled = true;

            }
            catch
            {
            }
        }

        private void chkbx_Mute_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if( chkbx_Mute.Checked == true )
                {
                    Mute_Volume_backup = rcv_vol;
                    Set_Volume = 0;
                    b_VolSet_flag = true;
                }
                else
                {
                    Set_Volume = Mute_Volume_backup;
                    b_VolSet_flag = true;
                }
            }
            catch
            {
            }
        }
        //����������
        /// <summary>
        /// �^�C�}�[�Z�b�g
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //////////private void my_TimerSetClick(object sender, EventArgs e)
        //////////{
        //////////    DialogResult dr;
        //////////    try
        //////////    {
        //////////        if(timer_info.exe_timer_set_flag == true)
        //////////        {
        //////////            dr =  MessageBox.Show("�\����s���ł��B\n�\����������܂����H", "WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        //////////            if(dr == DialogResult.No)
        //////////            {
        //////////                return;
        //////////            }
        //////////            //�^�����̎��̓L�����Z������
        //////////            recording_cancel = true;
        //////////        }

        //////////        FormTimerSet fts = new FormTimerSet(timer_info);
        //////////        dr = fts.ShowDialog();
        //////////        if( dr == DialogResult.OK )
        //////////        {
        //////////            timer_info.NextTimerSet(true);
                    
        //////////            if (timer_info.exe_timer_set_flag == true)
        //////////            {   // Timer���s
        //////////                recording_status = REC_STATUS_WAIT;
        //////////                RecordingTimer.Enabled = true;
        //////////                recording_cancel = false;
        //////////            }

        //////////            my_Disp_Timer(AttachedState, timer_info.exe_timer_set_flag, timer_info.exe_timer_on_date, timer_info.exe_timer_off_date, (byte)timer_info.band, timer_info.frequency_am, timer_info.frequency_fm, timer_info.sampling_freq, timer_info.repeat_type);
        //////////        }
        //////////    }
        //////////    catch
        //////////    {
        //////////    }
        //////////}
        /// <summary>
        /// ��M�d�g�X�L�����^�C�}�[
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WaveScanTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                if(scan_status == SCAN_STATUS_INIT)
                {   //��������ԂȂ���g���Z�b�g��Ԃ�
                    scan_status = SCAN_STATUS_FREQ_SET;

                    btn_ScanCancel.Visible = true;
                    btn_Scan.Visible = false;
                    picbx_ScanProcess.BackgroundImage = imglist_ScanProcess.Images[0];
                    picbx_ScanProcess.Tag = 0;
                    picbx_ScanProcess.Visible = true;
                }
                else if (scan_status == SCAN_STATUS_FREQ_SET)
                {
                }
                else if (scan_status == SCAN_STATUS_RQS)
                {
                    scan_process_redraw_count++;
                    if (scan_process_redraw_count >= SCAN_PROCESS_REDRAW)
                    {
                        int idx = int.Parse(picbx_ScanProcess.Tag.ToString());
                        idx++;
                        if (idx >= imglist_ScanProcess.Images.Count)
                        {
                            idx = 0;
                        }
                        picbx_ScanProcess.BackgroundImage = imglist_ScanProcess.Images[idx];
                        picbx_ScanProcess.Tag = idx;
                        scan_process_redraw_count = 0;
                    }

                    if (0 <= scan_info.scan_idx && scan_info.scan_idx < scan_info.num)
                    {
                        // ��M�f�[�^�̎��g�����`�F�b�N
                        if ((scan_info.band == BAND_AM && scan_info.freq[scan_info.scan_idx] == rcv_freq_am) || (scan_info.band == BAND_FM && scan_info.freq[scan_info.scan_idx] == rcv_freq_fm))
                        {
                            scan_info.scan_comp[scan_info.scan_idx] = true;
                            //scan_info.freq[scan_info.scan_idx] = 0;
                            scan_info.rssi[scan_info.scan_idx] = rcv_rssi;
                            scan_info.snr[scan_info.scan_idx] = rcv_snr;
                            scan_info.scan_comp_num++;

                            if (scan_info.rssi[scan_info.scan_idx] > scan_info.max_rssi_range)
                            {
                                scan_info.max_rssi_range = (scan_info.rssi[scan_info.scan_idx] / 10 + 1) * 10;

                                scan_info.rssi_scale[2] = scan_info.max_rssi_range / 5;
                                if (scan_info.rssi_scale[2] > SCAN_RSSI_SCALE_MAX)
                                {
                                    scan_info.rssi_scale[2] = SCAN_RSSI_SCALE_MAX;
                                }
                                scan_info.rssi_scale[1] = scan_info.rssi_scale[2] / 2;
                            }
                            if (scan_info.snr[scan_info.scan_idx] > scan_info.max_snr_range)
                            {
                                scan_info.max_snr_range = (scan_info.snr[scan_info.scan_idx] / 10 + 1) * 10;

                                scan_info.snr_scale[2] = scan_info.max_snr_range / 5;
                                if (scan_info.snr_scale[2] > SCAN_SNR_SCALE_MAX)
                                {
                                    scan_info.snr_scale[2] = SCAN_SNR_SCALE_MAX;
                                }
                                scan_info.snr_scale[1] = scan_info.snr_scale[2] / 2;
                            }

                            scan_info.scan_idx++;
                            if (scan_info.scan_idx < scan_info.num)
                            {
                                //������A���g���Z�b�g��Ԃ�
                                scan_status = SCAN_STATUS_FREQ_SET;
                            }
                            else
                            {
                                //���Ȃ��A�I����Ԃ�
                                scan_status = SCAN_STATUS_END;
                            }

                            picbx_ScanWave.Refresh();
                        }
                    }
                    else
                    {
                        //�I��
                        scan_status = SCAN_STATUS_END;
                    }
                }
                else if (scan_status == SCAN_STATUS_END)
                {
                    picbx_ScanProcess.Visible = false;
                    btn_Scan.Visible = true;
                    btn_ScanCancel.Visible = false;

                    // �I���̂Ƃ��̓^�C�}�[���Z�b�g
                    WaveScanTimer.Enabled = false;
                    scan_status = SCAN_STATUS_NONE;

                    //Scan�J�n�O�̎��g���ɖ߂�
                    if (scan_info.band == BAND_AM)
                    {
                        AM_Set_Freq = scan_info.freq_backup;
                        b_AMSet_flag = true;
                    }
                    else if (scan_info.band == BAND_FM)
                    {
                        FM_Set_Freq = scan_info.freq_backup;
                        b_FMSet_flag = true;
                    }
                    btn_Scan.Enabled = true;
                }
            }
            catch
            {
            }
        }

        private void btn_FreqChange_MouseDown(object sender, MouseEventArgs e)
        {
            int span_am = 0;
            int span_fm = 0;
            try
            {
                FreqChangeButton_Time = 0;
                i_FreqChange_flag = int.Parse(((Button)sender).Tag.ToString());
                FreqChangeTimer.Enabled = true;

                span_am = 1;
                span_fm = FM_FRQ_SEEK_SPAN;
                if (i_FreqChange_flag == 4 || i_FreqChange_flag == 5)
                {//Down
                    span_am *= -1;
                    span_fm *= -1;
                }
                if (rcv_band == BAND_FM)
                {
                    FM_Set_Freq = rcv_freq_fm + span_fm;
                    b_FMSet_flag = true;
                    b_FMChange_Req_flag = true;
                    Freq_Change_Count = 0;
                }
                else
                {
                    AM_Set_Freq = rcv_freq_am + span_am;
                    b_AMSet_flag = true;
                    b_AMChange_Req_flag = true;
                    Freq_Change_Count = 0;
                }
            }
            catch
            {
            }
        }

        private void btn_FreqChange_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                FreqChangeTimer.Enabled = false;
                i_FreqChange_flag = 0;
            }
            catch
            {
            }
        }
        /// <summary>
        /// ���g���ύX�̏㉺�{�^�����������������̑����ʂ�ύX
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FreqChangeTimer_Tick(object sender, EventArgs e)
        {
            int span_am = 0;
            int span_fm = 0;
            try
            {
                FreqChangeButton_Time++;

                if(FREQ_AUTO_CHANGE_TIME_L3 <= FreqChangeButton_Time)
                {
                    FreqChangeButton_Time = FREQ_AUTO_CHANGE_TIME_L3;
                    span_am = FREQ_AUTO_CHANGE_SPAN_AM_L3;
                    span_fm = FREQ_AUTO_CHANGE_SPAN_FM_L3;
                }
                else if (FREQ_AUTO_CHANGE_TIME_L2 <= FreqChangeButton_Time)
                {
                    span_am = FREQ_AUTO_CHANGE_SPAN_AM_L2;
                    span_fm = FREQ_AUTO_CHANGE_SPAN_FM_L2;
                }
                else if(FREQ_AUTO_CHANGE_TIME_L1 <= FreqChangeButton_Time){
                    span_am = FREQ_AUTO_CHANGE_SPAN_AM_L1;
                    span_fm = FREQ_AUTO_CHANGE_SPAN_FM_L1;
                }
                if (span_am != 0 || span_fm != 0)
                {
                    if (i_FreqChange_flag == 4 || i_FreqChange_flag == 5)
                    {//Down
                        span_am *= -1;
                        span_fm *= -1;
                    }

                    if (rcv_band == BAND_FM)
                    {
                        if (FM_FRQ_MIN <= (rcv_freq_fm + span_fm) && (rcv_freq_fm + span_fm) <= FM_FRQ_MAX)
                        {   //���̎��g�����ݒ�͈͓�
                            FM_Set_Freq = rcv_freq_fm + span_fm;
                            b_FMSet_flag = true;
                        }
                        else if(rcv_freq_fm != FM_FRQ_MIN && FM_FRQ_MIN > (rcv_freq_fm + span_fm))
                        {   //���̎��g���������𒴂��Ă���
                            FM_Set_Freq = FM_FRQ_MIN;
                            b_FMSet_flag = true;
                        }
                        else if (rcv_freq_fm != FM_FRQ_MAX && FM_FRQ_MAX < (rcv_freq_fm + span_fm))
                        {   //���̎��g��������𒴂��Ă���
                            FM_Set_Freq = FM_FRQ_MAX;
                            b_FMSet_flag = true;
                        }
                    }
                    else
                    {
                        if (AM_FRQ_MIN <= (rcv_freq_am + span_am) && (rcv_freq_am + span_am) <= AM_FRQ_MAX)
                        {   //���̎��g�����ݒ�͈͓�
                            AM_Set_Freq = rcv_freq_am + span_am;
                            b_AMSet_flag = true;
                        }
                        else if (rcv_freq_am != AM_FRQ_MIN && AM_FRQ_MIN > (rcv_freq_am + span_am))
                        {   //���̎��g���������𒴂��Ă���
                            AM_Set_Freq = AM_FRQ_MIN;
                            b_AMSet_flag = true;
                        }
                        else if (rcv_freq_am != AM_FRQ_MAX && AM_FRQ_MAX < (rcv_freq_am + span_am))
                        {   //���̎��g��������𒴂��Ă���
                            AM_Set_Freq = AM_FRQ_MAX;
                            b_AMSet_flag = true;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void trkbar_Volume_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkbx_Mute.Checked == true)
                {
                    Mute_Volume_backup = trkbar_Volume.Value;
                }
                else
                {
                    if(rcv_vol != (byte)trkbar_Volume.Value)
                    {
                        Set_Volume = trkbar_Volume.Value;
                        b_VolSet_flag = true;
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_Bandwidth_Down_Click(object sender, EventArgs e)
        {
            try
            {
                BandWidth--;
                if(BandWidth < 0)
                {
                    BandWidth = imglist_Band_Wide.Images.Count - 1;
                }
                picbx_Bandwidth.Image = imglist_Band_Wide.Images[BandWidth];
            }
            catch
            {
            }
        }

        private void btn_Bandwidth_Up_Click(object sender, EventArgs e)
        {
            try
            {
                BandWidth++;
                if (BandWidth >= imglist_Band_Wide.Images.Count)
                {
                    BandWidth = 0;
                }
                picbx_Bandwidth.Image = imglist_Band_Wide.Images[BandWidth];
            }
            catch
            {
            }
        }
        /// <summary>
        /// �o���h�\�����̕\�����X�V����
        /// </summary>
        /// <param name="USBEnabled">USB�ʐM�t���O</param>
        /// <param name="ControlEnabled">�R���g���[��Enabled�t���O</param>
        /// <param name="pBand">Band</param>
        /// <param name="pFreqAM">AM ���g��</param>
        /// <param name="pFreqFM">FM ���g��</param>
        private void my_Disp_Band(bool USBEnabled, bool ControlEnabled, byte pBand, int pFreqAM, int pFreqFM)
        {
            int number_idx;
            int div;
            try
            {
                if (USBEnabled == true)
                {
                    // TUNED�\��
                    if(rcv_rssi >= 10 && rcv_snr >= 2)
                    {
                        picbx_Tuned.Visible = true;
                    }
                    else
                    {
                        picbx_Tuned.Visible = false;
                    }

                    if (pBand == BAND_FM)
                    {
                        picbx_Freq_dot.Visible = true;
                        picbx_FMFreqUnit.Visible = true;
                        picbx_AMFreqUnit.Visible = false;
                        picbx_Band_AM.Visible = false;
                        picbx_Band_FM.Visible = true;


                        if (rcv_stereo == 1)
                        {
                            picbx_Stereo.Visible = true;
                        }
                        else
                        {
                            picbx_Stereo.Visible = false;
                        }

                        div = 10000;
                        for (int fi = 0; fi < pic_FM_Freq.Length; fi++)
                        {
                            number_idx = pFreqFM / div;
                            number_idx %= 10;
                            pic_FM_Freq[fi].BackgroundImage = imglist_Number_L.Images[number_idx];
                            div /= 10;

                            pic_FM_Freq[fi].Visible = true;
                        }
                        for (int fi = 0; fi < pic_AM_Freq.Length; fi++)
                        {
                            pic_AM_Freq[fi].Visible = false;
                        }
                    }
                    else
                    {
                        picbx_Freq_dot.Visible = false;
                        picbx_AMFreqUnit.Visible = true;
                        picbx_FMFreqUnit.Visible = false;
                        picbx_Band_AM.Visible = true;
                        picbx_Band_FM.Visible = false;


                        picbx_Stereo.Visible = false;

                        div = 1000;
                        for (int fi = 0; fi < pic_AM_Freq.Length; fi++)
                        {
                            number_idx = pFreqAM / div;
                            number_idx %= 10;
                            pic_AM_Freq[fi].BackgroundImage = imglist_Number_L.Images[number_idx];
                            div /= 10;

                            pic_AM_Freq[fi].Visible = true;
                        }
                        for (int fi = 0; fi < pic_FM_Freq.Length; fi++)
                        {
                            pic_FM_Freq[fi].Visible = false;
                        }
                    }

                    if (ControlEnabled == true)
                    {
                        btn_Band.Enabled = true;
                        btn_FreqUp.Enabled = true;
                        btn_FreqDown.Enabled = true;
                        SeekUp_btn.Enabled = true;
                        SeekDown_btn.Enabled = true;
                    }
                    else{
                        btn_Band.Enabled = false;
                        btn_FreqUp.Enabled = false;
                        btn_FreqDown.Enabled = false;
                        SeekUp_btn.Enabled = false;
                        SeekDown_btn.Enabled = false;
                    }
                }
                else
                {
                    for( int fi = 0; fi < pic_FM_Freq.Length; fi++)
                    {
                        pic_FM_Freq[fi].BackgroundImage = imglist_Number_L.Images[10];
                        
                        if(pBand == BAND_FM)
                        {
                            pic_FM_Freq[fi].Visible = true;
                        }
                        else{
                            pic_FM_Freq[fi].Visible = false;
                        }
                    }
                    for( int fi = 0; fi < pic_AM_Freq.Length; fi++)
                    {
                        pic_AM_Freq[fi].BackgroundImage = imglist_Number_L.Images[10];
                        
                        if(pBand == BAND_AM)
                        {
                            pic_AM_Freq[fi].Visible = true;
                        }
                        else{
                            pic_AM_Freq[fi].Visible = false;
                        }
                    }

                    picbx_Tuned.Visible = false;
                    picbx_Stereo.Visible = false;

                    btn_Band.Enabled = false;
                    btn_FreqUp.Enabled = false;
                    btn_FreqDown.Enabled = false;
                    SeekUp_btn.Enabled = false;
                    SeekDown_btn.Enabled = false;
                }
            }
            catch
            {
            }
        }
        /// <summary>
        /// �{�����[���\�����̕\�����X�V����
        /// </summary>
        /// <param name="USBEnabled">USB�ʐM�t���O</param>
        /// <param name="ControlEnabled">�R���g���[��Enabled�t���O</param>
        /// <param name="pRcvVol">��M�{�����[���l</param>
        /// <param name="psliderVol">TrackBar�{�����[���l</param>
        /// <param name="pMuteFlag">�~���[�g�t���O</param>
        ///
        private void my_Disp_Volume(bool USBEnabled, bool ControlEnabled, int pRcvVol, int pBackUpVol, bool pMuteFlag)
        {
            int number_idx;
            int div;
            int dispVal = 0;
            int ValLevel = 0;
            try
            {
                if (USBEnabled == true)
                {
                    if (pMuteFlag == false)
                    {
                        dispVal = pRcvVol;
                        trkbar_Volume.Value = pRcvVol;
                        picbx_Mute.Visible = false;
                    }
                    else
                    {
                        dispVal = pBackUpVol;
                        picbx_Mute.Visible = true;
                    }
                    div = 10;
                    for (int fi = 0; fi < pic_Vol.Length; fi++)
                    {
                        number_idx = dispVal / div;
                        number_idx %= 10;
                        pic_Vol[fi].Image = imglist_Number_M.Images[number_idx];
                        div /= 10;
                    }
                    if (dispVal == 0)
                    {
                        ValLevel = -1;
                    }
                    else if (dispVal < 10)
                    {
                        ValLevel = 0;
                    }
                    else if (dispVal < 21)
                    {
                        ValLevel = 1;
                    }
                    else if (dispVal < 32)
                    {
                        ValLevel = 2;
                    }
                    else if (dispVal < 43)
                    {
                        ValLevel = 3;
                    }
                    else if (dispVal < 54)
                    {
                        ValLevel = 4;
                    }
                    else
                    {
                        ValLevel = 5;
                    }
                    for (int fi = 0; fi < pic_Volume_Level.Length; fi++)
                    {
                        if (fi <= ValLevel)
                        {
                            pic_Volume_Level[fi].Visible = true;
                        }
                        else
                        {
                            pic_Volume_Level[fi].Visible = false;
                        }
                    }

                    if (ControlEnabled == true)
                    {
                        chkbx_Mute.Enabled = true;
                        trkbar_Volume.Enabled = true;
                    }
                    else
                    {
                        chkbx_Mute.Enabled = false;
                        trkbar_Volume.Enabled = false;
                    }
                }
                else
                {
                    for (int fi = 0; fi < pic_Vol.Length; fi++)
                    {
                        pic_Vol[fi].Image = imglist_Number_M.Images[10];
                    }
                    chkbx_Mute.Enabled = false;
                    trkbar_Volume.Enabled = false;
                    picbx_Mute.Visible = false;
                }
            }
            catch
            {
            }
        }
        //����������
        /// <summary>
        /// �^�C�}�[�ݒ�\�����̕\�����X�V���邽�߂̃^�C�}�[
        /// </summary>
        /// <param name="USBEnabled">USB�ʐM�t���O</param>
        /// <param name="ControlEnabled">�R���g���[��Enabled�t���O</param>
        /// <param name="pOnTime">OnTime</param>
        /// <param name="pOffTime">OffTime</param>
        /// <param name="pBand">Band</param>
        /// <param name="pFreqAM">AM ���g��</param>
        /// <param name="pFreqFM">FM ���g��</param>
        /// <param name="pSampRate">�T���v�����O���[�g</param>
        /// <param name="pRepeatType">���s�[�g�^�C�v</param>
        //////////private void my_Disp_Timer(bool USBEnabled, bool ControlEnabled, DateTime pOnTime, DateTime pOffTime, byte pBand, int pFreqAM, int pFreqFM, int pSampRate, int pRepeatType)
        //////////{
        //////////    int number_idx;
        //////////    int div;
        //////////    bool no_zero_flag = false;
        //////////    try
        //////////    {
        //////////        if (ControlEnabled == true)
        //////////        {
        //////////            div = 1000;
        //////////            for (int fi = 0; fi < pic_Timer_Date.Length; fi++)
        //////////            {
        //////////                if(fi <= 3)
        //////////                {
        //////////                    number_idx = pOnTime.Year / div;
        //////////                    number_idx %= 10;
        //////////                    if(fi == 3)
        //////////                    {
        //////////                        div = 10;
        //////////                    }
        //////////                    else{
        //////////                        div /= 10;
        //////////                    }
        //////////                }
        //////////                else if(fi <= 5)
        //////////                {
        //////////                    number_idx = pOnTime.Month / div;
        //////////                    number_idx %= 10;
        //////////                    if (fi == 5)
        //////////                    {
        //////////                        div = 10;
        //////////                    }
        //////////                    else
        //////////                    {
        //////////                        div /= 10;
        //////////                    }
        //////////                }
        //////////                else if(fi <= 7)
        //////////                {
        //////////                    number_idx = pOnTime.Day / div;
        //////////                    number_idx %= 10;

        //////////                    div /= 10;
        //////////                }
        //////////                else
        //////////                {
        //////////                    number_idx = 10;
        //////////                }
        //////////                pic_Timer_Date[fi].Image = imglist_Number_S.Images[number_idx];
        //////////            }
        //////////            div = 10;
        //////////            for (int fi = 0; fi < pic_Timer_ONTime.Length; fi++)
        //////////            {
        //////////                if (fi <= 1)
        //////////                {
        //////////                    number_idx = pOnTime.Hour / div;
        //////////                    number_idx %= 10;
        //////////                    if (fi == 1)
        //////////                    {
        //////////                        div = 10;
        //////////                    }
        //////////                    else
        //////////                    {
        //////////                        div /= 10;
        //////////                    }
        //////////                }
        //////////                else if (fi <= 3)
        //////////                {
        //////////                    number_idx = pOnTime.Minute / div;
        //////////                    number_idx %= 10;

        //////////                    div /= 10;
        //////////                }
        //////////                else
        //////////                {
        //////////                    number_idx = 10;
        //////////                }
        //////////                pic_Timer_ONTime[fi].Image = imglist_Number_S.Images[number_idx];
        //////////            }
        //////////            div = 10;
        //////////            for (int fi = 0; fi < pic_Timer_OFFTime.Length; fi++)
        //////////            {
        //////////                if (fi <= 1)
        //////////                {
        //////////                    number_idx = pOffTime.Hour / div;
        //////////                    number_idx %= 10;
        //////////                    if (fi == 1)
        //////////                    {
        //////////                        div = 10;
        //////////                    }
        //////////                    else
        //////////                    {
        //////////                        div /= 10;
        //////////                    }
        //////////                }
        //////////                else if (fi <= 3)
        //////////                {
        //////////                    number_idx = pOffTime.Minute / div;
        //////////                    number_idx %= 10;

        //////////                    div /= 10;
        //////////                }
        //////////                else
        //////////                {
        //////////                    number_idx = 10;
        //////////                }
        //////////                pic_Timer_OFFTime[fi].Image = imglist_Number_S.Images[number_idx];
        //////////            }
        //////////            if (pBand == BAND_FM)
        //////////            {
        //////////                div = 10000;
        //////////                picbx_Timer_Band.Visible = true;
        //////////                picbx_Timer_Band.BackgroundImage = imglist_TimerBand.Images[BAND_FM];
        //////////                picbx_TimerFreq_dot.Visible = true;
        //////////                picbx_Timer_FMFreqUnit.Visible = true;
        //////////                picbx_Timer_AMFreqUnit.Visible = false;

        //////////                //�\���ʒu����
        //////////                pic_Timer_Freq[0].Location = new System.Drawing.Point(593, 16);
        //////////                pic_Timer_Freq[1].Location = new System.Drawing.Point(607, 16);
        //////////                pic_Timer_Freq[2].Location = new System.Drawing.Point(621, 16);
        //////////                pic_Timer_Freq[3].Location = new System.Drawing.Point(641, 16);
        //////////            }
        //////////            else
        //////////            {
        //////////                div = 1000;
        //////////                picbx_Timer_Band.Visible = true;
        //////////                picbx_Timer_Band.BackgroundImage = imglist_TimerBand.Images[BAND_AM];
        //////////                picbx_TimerFreq_dot.Visible = false;
        //////////                picbx_Timer_AMFreqUnit.Visible = true;
        //////////                picbx_Timer_FMFreqUnit.Visible = false;

        //////////                //�\���ʒu����
        //////////                pic_Timer_Freq[0].Location = new System.Drawing.Point(599, 16);
        //////////                pic_Timer_Freq[1].Location = new System.Drawing.Point(613, 16);
        //////////                pic_Timer_Freq[2].Location = new System.Drawing.Point(627, 16);
        //////////                pic_Timer_Freq[3].Location = new System.Drawing.Point(641, 16);
        //////////            }
        //////////            no_zero_flag = false;
        //////////            for (int fi = 0; fi < pic_Timer_Freq.Length; fi++)
        //////////            {

        //////////                if (pBand == BAND_FM)
        //////////                {
        //////////                    number_idx = pFreqFM / div;
        //////////                }
        //////////                else
        //////////                {
        //////////                    number_idx = pFreqAM / div;
        //////////                }
        //////////                number_idx %= 10;
        //////////                //���̃[���͕\�����Ȃ�
        //////////                if(number_idx != 0)
        //////////                {
        //////////                    no_zero_flag = true;
        //////////                }
        //////////                if (no_zero_flag == true)
        //////////                {
        //////////                    pic_Timer_Freq[fi].Image = imglist_Number_S.Images[number_idx];
        //////////                    pic_Timer_Freq[fi].Visible = true;
        //////////                }
        //////////                else
        //////////                {
        //////////                    pic_Timer_Freq[fi].Visible = false;
        //////////                    pic_Timer_Freq[fi].Image = imglist_Number_S.Images[number_idx];
        //////////                }
        //////////                div /= 10;
        //////////            }
        //////////            no_zero_flag = false;
        //////////            div = 10000;
        //////////            for (int fi = 0; fi < pic_Timer_SRate.Length; fi++)
        //////////            {

        //////////                number_idx = pSampRate / div;
        //////////                number_idx %= 10;
        //////////                //���̃[���͕\�����Ȃ�
        //////////                if (number_idx != 0)
        //////////                {
        //////////                    no_zero_flag = true;
        //////////                }
        //////////                if (no_zero_flag == true)
        //////////                {
        //////////                    pic_Timer_SRate[fi].Image = imglist_Number_S.Images[number_idx];
        //////////                    pic_Timer_SRate[fi].Visible = true;
        //////////                }
        //////////                else
        //////////                {
        //////////                    pic_Timer_SRate[fi].Visible = false;
        //////////                    pic_Timer_SRate[fi].Image = imglist_Number_S.Images[number_idx];
        //////////                }
        //////////                div /= 10;
        //////////            }

        //////////            for (int fi = 0; fi < pic_Timer_On.Length; fi++ )
        //////////            {
        //////////                if (fi == pRepeatType)
        //////////                {
        //////////                    pic_Timer_On[fi].Visible = true;
        //////////                }
        //////////                else{
        //////////                    pic_Timer_On[fi].Visible = false;
        //////////                }
        //////////            }
        //////////        }
        //////////        else
        //////////        {
        //////////            number_idx = 10;
        //////////            for (int fi = 0; fi < pic_Timer_Date.Length; fi++)
        //////////            {
        //////////                pic_Timer_Date[fi].Image = imglist_Number_S.Images[number_idx];
        //////////            }
        //////////            for (int fi = 0; fi < pic_Timer_ONTime.Length; fi++)
        //////////            {
        //////////                pic_Timer_ONTime[fi].Image = imglist_Number_S.Images[number_idx];
        //////////            }
        //////////            for (int fi = 0; fi < pic_Timer_OFFTime.Length; fi++)
        //////////            {
        //////////                pic_Timer_OFFTime[fi].Image = imglist_Number_S.Images[number_idx];
        //////////            }
        //////////            for (int fi = 0; fi < pic_Timer_Freq.Length; fi++)
        //////////            {
        //////////                pic_Timer_Freq[fi].Image = imglist_Number_S.Images[number_idx];
        //////////            }
        //////////            for (int fi = 0; fi < pic_Timer_SRate.Length; fi++)
        //////////            {
        //////////                pic_Timer_SRate[fi].Image = imglist_Number_S.Images[number_idx];
        //////////            }

        //////////            for (int fi = 0; fi < pic_Timer_On.Length; fi++)
        //////////            {
        //////////                pic_Timer_On[fi].Visible = false;
        //////////            }
        //////////            picbx_Timer_AMFreqUnit.Visible = false;
        //////////            picbx_Timer_FMFreqUnit.Visible = false;
        //////////            picbx_Timer_Band.Visible = false;
        //////////        }
        //////////    }
        //////////    catch
        //////////    {
        //////////    }
        //////////}

        //////////private void RecordingTimer_Tick(object sender, EventArgs e)
        //////////{
        //////////    bool timer_set_falg = true;
        //////////    try
        //////////    {
        //////////        //�^�C�}�[��U��~
        //////////        RecordingTimer.Enabled = false;

        //////////        //�L�����Z��
        //////////        if (recording_cancel == true)
        //////////        {
        //////////            recording_cancel = false;
        //////////            recording_status = REC_STATUS_CANCEL;
        //////////        }

        //////////        switch (recording_status)
        //////////        {
        //////////            case REC_STATUS_WAIT:
        //////////                if (System.DateTime.Now.AddSeconds(TIMER_FREQ_SET_TIME) > timer_info.exe_timer_on_date)
        //////////                {
        //////////                    recording_status = REC_STATUS_INIT;
        //////////                }
        //////////                break;
        //////////            case REC_STATUS_INIT:
        //////////                // ���g���Z�b�g
        //////////                if(timer_info.band == BAND_AM)
        //////////                {
        //////////                    AM_Set_Freq = timer_info.frequency_am;
        //////////                    b_AMSet_flag = true;
        //////////                    b_AMChange_Req_flag = true;
        //////////                    Freq_Change_Count = 0;
        //////////                }
        //////////                else
        //////////                {
        //////////                    FM_Set_Freq = timer_info.frequency_fm;
        //////////                    b_FMSet_flag = true;
        //////////                    b_FMChange_Req_flag = true;
        //////////                    Freq_Change_Count = 0;
        //////////                }
        //////////                recording_status = REC_STATUS_REC_WAIT;
        //////////                break;
        //////////            case REC_STATUS_REC_WAIT:
        //////////                if (System.DateTime.Now.AddSeconds(TIMER_REC_START_TIME) > timer_info.exe_timer_on_date)
        //////////                {

        //////////                    string save_file_path = my_GetSaveFilePath("wav");
        //////////                    if (save_file_path != "")
        //////////                    {
        //////////                        CaptureFlag = true;
        //////////                        my_CaptureStart(save_file_path, timer_info.sampling_freq);
        //////////                        dsCaptureBuffer.Start(true);

        //////////                        recording_status = REC_STATUS_RECORDING;
        //////////                    }
        //////////                    else
        //////////                    {
        //////////                        recording_status = REC_STATUS_NEXT;
        //////////                        //MessageBox.Show("WAV�t�@�C�����쐬�ł��܂���", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //////////                    }

        //////////                }
        //////////                break;
        //////////            case REC_STATUS_RECORDING:
        //////////                if (System.DateTime.Now > timer_info.exe_timer_off_date)
        //////////                {
        //////////                    my_ThreadStop();

        //////////                    recording_status = REC_STATUS_STOP_WAIT;
        //////////                }
        //////////                else
        //////////                {
        //////////                }
        //////////                break;
        //////////            case REC_STATUS_STOP_WAIT:
        //////////                if (bgw_CaptureBufferWrite_Busy == false)
        //////////                {
        //////////                    //my_ThreadStop();
        //////////                    if (dsCaptureBuffer != null)
        //////////                    {
        //////////                        dsCaptureBuffer.Stop();
        //////////                    }
        //////////                    my_CaptureStop();

        //////////                    recording_status = REC_STATUS_NEXT;
        //////////                }
        //////////                break;
        //////////            case REC_STATUS_NEXT:
        //////////                //���̃^�C�}�[�\�񎞊ԃZ�b�g
        //////////                timer_info.NextTimerSet(false);
        //////////                if (timer_info.exe_timer_set_flag == true)
        //////////                {   //���̗\��L��
        //////////                    recording_status = REC_STATUS_WAIT;
        //////////                }
        //////////                else
        //////////                {   //���̗\��Ȃ�
        //////////                    recording_status = REC_STATUS_END;
        //////////                }
        //////////                my_Disp_Timer(AttachedState, timer_info.exe_timer_set_flag, timer_info.exe_timer_on_date, timer_info.exe_timer_off_date, (byte)timer_info.band, timer_info.frequency_am, timer_info.frequency_fm, timer_info.sampling_freq, timer_info.repeat_type);

        //////////                break;
        //////////            case REC_STATUS_CANCEL:

        //////////                my_ThreadStop();

        //////////                recording_status = REC_STATUS_CANCEL_WAIT;

        //////////                break;
        //////////            case REC_STATUS_CANCEL_WAIT:

        //////////                if (bgw_CaptureBufferWrite_Busy == false)
        //////////                {
        //////////                    //my_ThreadStop();
        //////////                    if (dsCaptureBuffer != null)
        //////////                    {
        //////////                        dsCaptureBuffer.Stop();
        //////////                    }
        //////////                    my_CaptureStop();

        //////////                    timer_info.exe_timer_set_flag = false;

        //////////                    my_Disp_Timer(AttachedState, timer_info.exe_timer_set_flag, timer_info.exe_timer_on_date, timer_info.exe_timer_off_date, (byte)timer_info.band, timer_info.frequency_am, timer_info.frequency_fm, timer_info.sampling_freq, timer_info.repeat_type);

        //////////                    recording_status = REC_STATUS_END;
        //////////                }
        //////////                break;
        //////////            case REC_STATUS_END:

        //////////                //�I��
        //////////                recording_status = REC_STATUS_NONE;
        //////////                timer_set_falg = false;
        //////////                break;
        //////////            default:
        //////////                break;
        //////////        }
        //////////        //�^�C�}�[�Z�b�g
        //////////        RecordingTimer.Enabled = timer_set_falg;
        //////////    }
        //////////    catch
        //////////    {
        //////////    }
        //////////}

        private void btn_Scan_EnabledChanged(object sender, EventArgs e)
        {
            try
            {
                btn_Bandwidth_Down.Enabled = btn_Scan.Enabled;
                btn_Bandwidth_Up.Enabled = btn_Scan.Enabled;
            }
            catch
            {
            }
        }

        //����������
//////////        /// <summary>
//////////        /// �L���v�`���o�b�t�@���I�[�v������
//////////        /// </summary>
//////////        /// <param name="save_file_name"></param>
//////////        /// <param name="samp_rate"></param>
//////////        /// <returns></returns>
//////////        private int my_CaptureStart(string save_file_name, int samp_rate)
//////////        {
//////////            int i_ret = -1;
//////////            try
//////////            {

//////////                dsCapture = new Capture(DSoundHelper.DefaultCaptureDevice);

//////////                dsWaveFormat.Channels = 2;
//////////                dsWaveFormat.BitsPerSample = 16;
//////////                dsWaveFormat.FormatTag = WaveFormatTag.Pcm;
//////////                dsWaveFormat.SamplesPerSecond = samp_rate;
//////////                dsWaveFormat.BlockAlign = (short)(dsWaveFormat.Channels * (dsWaveFormat.BitsPerSample / (short)8));
//////////                dsWaveFormat.AverageBytesPerSecond = (int)(dsWaveFormat.BlockAlign * dsWaveFormat.SamplesPerSecond);

//////////                dsCaptureBufferDescription.BufferBytes = dsWaveFormat.AverageBytesPerSecond * BUFFER_SECOND;
//////////                //dsCaptureBufferDescription.WaveMapped = ;
//////////                dsCaptureBufferDescription.Format = dsWaveFormat;

//////////                try
//////////                {
//////////                    dsCaptureBuffer = new CaptureBuffer(dsCaptureBufferDescription, dsCapture);
//////////                }
//////////                catch
//////////                {
//////////                    MessageBox.Show("�L���v�`���o�b�t�@���쐬�ł��܂���B", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
//////////                    return -2;
//////////                }

//////////                i_ret = my_WaveFileOpen(save_file_name);
//////////                if (i_ret == 0)
//////////                {
//////////                    bgw_CaptureBufferWrite.RunWorkerAsync();

//////////                    int notifications = BUFFER_SECOND * CAPTURE_PER_SECOND;

//////////                    autoResetEvent = new AutoResetEvent(false);
//////////                    notify = new Notify(dsCaptureBuffer);

//////////                    for (int i = 0; i < notifications; i++)
//////////                    {
//////////                        PositionNotify[i].Offset = dsCaptureBufferDescription.Format.AverageBytesPerSecond * (i + 1) / CAPTURE_PER_SECOND - 1;
//////////#pragma warning disable 0618
//////////                        PositionNotify[i].EventNotifyHandle = autoResetEvent.Handle;
//////////#pragma warning restore 0618
//////////                        //PositionNotify[i].EventNotifyHandle = autoResetEvent.SafeWaitHandle;
//////////                    }
//////////                    notify.SetNotificationPositions(PositionNotify, notifications);

//////////                    i_ret = 0;
//////////                }
//////////                else
//////////                {
//////////                    MessageBox.Show("WAV�t�@�C�����쐬�ł��܂���", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
//////////                }
//////////            }
//////////            catch
//////////            {
//////////            }
//////////            return i_ret;

//////////        }
//////////        /// <summary>
//////////        /// �L���v�`���o�b�t�@���N���[�Y����
//////////        /// </summary>
//////////        /// <returns></returns>
//////////        private int my_CaptureStop()
//////////        {
//////////            int i_ret = -1;
//////////            try
//////////            {
//////////                i_ret = my_WaveFileClose(Capture_Wave_Size);
//////////                if (dsCaptureBuffer != null)
//////////                {
//////////                    dsCaptureBuffer.Dispose();
//////////                    dsCaptureBuffer = null;
//////////                }
//////////            }
//////////            catch
//////////            {
//////////            }
//////////            return i_ret;
//////////        }
//////////        /// <summary>
//////////        /// �^���t�@�C���T�C�Y���I�[�v������
//////////        /// </summary>
//////////        /// <param name="save_file_name">�^���t�@�C����</param>
//////////        /// <returns></returns>
//////////        private int my_WaveFileOpen(string save_file_name)
//////////        {
//////////            int i_ret = -1;
//////////            try
//////////            {

//////////                // �g�`�T�C�Y�N���A
//////////                Capture_Wave_Size = 0;
//////////                try
//////////                {
//////////                    binaryWriter = new BinaryWriter(new FileStream(save_file_name, FileMode.Create));
//////////                }
//////////                catch
//////////                {
//////////                    MessageBox.Show("�ۑ��t�@�C��[" + save_file_name + "]���쐬�ł��܂���B", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
//////////                    return -3;
//////////                }

//////////                char[] Riff = { 'R', 'I', 'F', 'F' };
//////////                char[] Wave = { 'W', 'A', 'V', 'E' };
//////////                char[] Fmt = { 'f', 'm', 't', ' ' };
//////////                char[] Data = { 'd', 'a', 't', 'a' };
//////////                short padding = 1;
//////////                int formatLength = 0x10;
//////////                int length = 0;
//////////                short shBytePerSample = 4;

//////////                binaryWriter.Write(Riff);
//////////                binaryWriter.Write(length);
//////////                binaryWriter.Write(Wave);
//////////                binaryWriter.Write(Fmt);
//////////                binaryWriter.Write(formatLength);
//////////                binaryWriter.Write(padding);
//////////                binaryWriter.Write(dsCaptureBufferDescription.Format.Channels);
//////////                binaryWriter.Write(dsCaptureBufferDescription.Format.SamplesPerSecond);
//////////                binaryWriter.Write(dsCaptureBufferDescription.Format.AverageBytesPerSecond);
//////////                binaryWriter.Write(shBytePerSample);
//////////                binaryWriter.Write(dsCaptureBufferDescription.Format.BitsPerSample);
//////////                binaryWriter.Write(Data);
//////////                binaryWriter.Write((int)0);

//////////                //binaryWriter.Close();
//////////                //binaryWriter = null;
//////////                i_ret = 0;
//////////            }
//////////            catch
//////////            {
//////////            }
//////////            return i_ret;

//////////        }
//////////        /// <summary>
//////////        /// �^���t�@�C�����N���[�Y����
//////////        /// </summary>
//////////        /// <param name="wave_data_size">�^���f�[�^�T�C�Y�i�g�`�T�C�Y�j</param>
//////////        /// <returns></returns>
//////////        private int my_WaveFileClose(uint wave_data_size)
//////////        {
//////////            int i_ret = -1;
//////////            try
//////////            {
//////////                if (binaryWriter != null)
//////////                {
//////////                    //�t�@�C���T�C�Y�Ɣg�`�T�C�Y����������
//////////                    binaryWriter.Seek((int)WAV_FILE_SIZE_OFFSET, SeekOrigin.Begin);
//////////                    binaryWriter.Write(wave_data_size + WAV_WAVE_SIZE_OFFSET - WAV_FILE_SIZE_OFFSET);
//////////                    binaryWriter.Seek((int)WAV_WAVE_SIZE_OFFSET, SeekOrigin.Begin);
//////////                    binaryWriter.Write(wave_data_size);

//////////                    binaryWriter.Close();
//////////                    binaryWriter = null;
//////////                }
//////////                i_ret = 0;
//////////            }
//////////            catch
//////////            {
//////////            }
//////////            return i_ret;
//////////        }
//////////        /// <summary>
//////////        /// �^���X���b�h���~����
//////////        /// </summary>
//////////        private void my_ThreadStop()
//////////        {
//////////            try
//////////            {
//////////                CaptureFlag = false;
//////////            }
//////////            catch
//////////            {
//////////            }
//////////        }
//////////        /// <summary>
//////////        /// �^���t�@�C�����i�p�X�j���擾����
//////////        /// �t�@�C�����́Ayyyymmdd_hhmmss�̔N���������b
//////////        /// </summary>
//////////        /// <param name="extension">�擾����t�@�C�����̊g���q</param>
//////////        /// <returns></returns>
//////////        private string my_GetSaveFilePath(string extension)
//////////        {
//////////            string s_ret = "";
//////////            try
//////////            {
//////////                //�ۑ��t�H���_�`�F�b�N
//////////                string folder_path = System.AppDomain.CurrentDomain.BaseDirectory + "REC_WAVE\\";
//////////                if (Directory.Exists(folder_path) == false)
//////////                {   //�t�H���_�쐬
//////////                    try
//////////                    {
//////////                        Directory.CreateDirectory(folder_path);
//////////                    }
//////////                    catch
//////////                    {
//////////                    }
//////////                }
//////////                if (Directory.Exists(folder_path) == true)
//////////                {   //�t�H���_����
//////////                    string now_date = System.DateTime.Now.ToString("yyyyMMdd_HHmmss.");
//////////                    s_ret = folder_path + now_date + extension;
//////////                }
//////////            }
//////////            catch
//////////            {
//////////            }
//////////            return s_ret;
//////////        }

//////////        private void bgw_CaptureBufferWrite_DoWork(object sender, DoWorkEventArgs e)
//////////        {
//////////            try
//////////            {
//////////                bgw_CaptureBufferWrite_Busy = true;

//////////                int bufSize = dsCaptureBufferDescription.BufferBytes;
//////////                int lastReadPos, capturePos;
//////////                dsCaptureBuffer.GetCurrentPosition(out capturePos, out lastReadPos);


//////////                do
//////////                {
//////////                    autoResetEvent.WaitOne();
//////////                    //autoResetEvent.WaitOne(Timeout.Infinite, true);
//////////                    int readPos;
//////////                    dsCaptureBuffer.GetCurrentPosition(out capturePos, out readPos);
//////////                    int size = readPos - lastReadPos;
//////////                    if (size == 0)
//////////                    {
//////////                        continue;
//////////                    }
//////////                    if (size < 0)
//////////                    {
//////////                        size += bufSize;
//////////                    }

//////////                    try
//////////                    {
//////////                        byte[] captureData = (byte[])dsCaptureBuffer.Read(lastReadPos, typeof(byte), LockFlag.None, size);

//////////                        // WAV�t�@�C���̏���𒴂��邩�`�F�b�N
//////////                        // �����Ă�����t�@�C������ĐV�K�t�@�C����
//////////                        if (WAV_FILE_MAX_SIZE < (Capture_Wave_Size + (uint)captureData.Length))
//////////                        {
//////////                            my_WaveFileClose(Capture_Wave_Size);
//////////                            my_WaveFileOpen(my_GetSaveFilePath("wav"));
//////////                        }

//////////                        binaryWriter.Write(captureData, 0, captureData.Length);

//////////                        Capture_Wave_Size += (uint)captureData.Length;

//////////                        lastReadPos = readPos;
//////////                    }
//////////                    catch
//////////                    {
//////////                    }

//////////                } while (CaptureFlag == true);

//////////                bgw_CaptureBufferWrite_Busy = false;
//////////            }
//////////            catch
//////////            {
//////////            }
//////////        }
//////////        /// <summary>
//////////        /// �^�C�}�[�ݒ�t�@�C���̓ǂݍ���
//////////        /// </summary>
//////////        /// <param name="file_name">�ǂݍ��݃t�@�C����</param>
//////////        /// <returns></returns>
//////////        private int my_TIMER_INFO_File_Read(string file_name)
//////////        {
//////////            int ret = -1;
//////////            try
//////////            {
//////////                // �t�@�C���L���`�F�b�N
//////////                if (File.Exists(file_name) == true)
//////////                {
//////////                    System.Xml.Serialization.XmlSerializer serializer = null;
//////////                    System.IO.FileStream fs = null;

//////////                    try
//////////                    {
//////////                        serializer = new System.Xml.Serialization.XmlSerializer(typeof(RadioWaveMonitor.TimerInfo));
//////////                        fs = new System.IO.FileStream(file_name, System.IO.FileMode.Open);
//////////                        RadioWaveMonitor.TimerInfo timer_info_tmp = (RadioWaveMonitor.TimerInfo)serializer.Deserialize(fs);

//////////                        // �ǂݍ��񂾃f�[�^���R�s�[
//////////                        timer_info.Copy(timer_info_tmp);
//////////                    }
//////////                    catch
//////////                    {
//////////                    }
//////////                    finally
//////////                    {
//////////                        if (fs != null)
//////////                        {
//////////                            fs.Close();
//////////                            fs.Dispose();
//////////                        }
//////////                    }
//////////                }

//////////                ret = 0;
//////////            }
//////////            catch
//////////            {
//////////            }
//////////            return ret;
//////////        }
//////////        /// <summary>
//////////        /// �^�C�}�[�ݒ�t�@�C���̕ۑ�
//////////        /// </summary>
//////////        /// <param name="file_name">�ۑ��t�@�C����</param>
//////////        /// <param name="save_flag">�㏑���t���O</param>
//////////        /// <returns></returns>
//////////        private int my_TIMER_INFO_File_Save(string file_name, bool save_flag)
//////////        {
//////////            int ret = -1;
//////////            try
//////////            {
//////////                System.Xml.Serialization.XmlSerializer serializer = null;
//////////                System.IO.FileStream fs = null;
//////////                try
//////////                {
//////////                    serializer = new System.Xml.Serialization.XmlSerializer(typeof(RadioWaveMonitor.TimerInfo));
//////////                    fs = new System.IO.FileStream(file_name, System.IO.FileMode.Create);
//////////                    serializer.Serialize(fs, timer_info);

//////////                    ret = 0;
//////////                }
//////////                catch
//////////                {
//////////                }
//////////                finally
//////////                {
//////////                    if (fs != null)
//////////                    {
//////////                        fs.Close();
//////////                        fs.Dispose();
//////////                    }
//////////                }
//////////            }
//////////            catch
//////////            {
//////////            }
//////////            return ret;
//////////        }

        private void btn_ScanCancel_Click(object sender, EventArgs e)
        {
            //�I��
            scan_status = SCAN_STATUS_END;
        }

        private void btn_Controlbox_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                idx++;
                ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_Controlbox.Images[idx];
                ((System.Windows.Forms.Button)sender).Tag = idx;
            }
            catch
            {
            }
        }

        private void btn_Controlbox_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                idx--;
                ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_Controlbox.Images[idx];
                ((System.Windows.Forms.Button)sender).Tag = idx;
            }
            catch
            {
            }
        }

        private void btn_Scan_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                idx++;
                ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_ScanBtn.Images[idx];
                ((System.Windows.Forms.Button)sender).Tag = idx;
            }
            catch
            {
            }
        }

        private void btn_Scan_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                idx--;
                ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_ScanBtn.Images[idx];
                ((System.Windows.Forms.Button)sender).Tag = idx;
            }
            catch
            {
            }
        }

        private void btn_Band_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                idx++;
                ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_BandBtn.Images[idx];
                ((System.Windows.Forms.Button)sender).Tag = idx;
            }
            catch
            {
            }
        }

        private void btn_Band_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                idx--;
                ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_BandBtn.Images[idx];
                ((System.Windows.Forms.Button)sender).Tag = idx;
            }
            catch
            {
            }
        }

        private void btn_FreqChange_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                idx++;
                ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_FreqChangeBtn.Images[idx];
                ((System.Windows.Forms.Button)sender).Tag = idx;
            }
            catch
            {
            }
        }

        private void btn_FreqChange_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                idx--;
                ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_FreqChangeBtn.Images[idx];
                ((System.Windows.Forms.Button)sender).Tag = idx;
            }
            catch
            {
            }
        }

        private void chkbx_Mute_MouseEnter(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.CheckBox)sender).Tag.ToString());
                idx++;
                ((System.Windows.Forms.CheckBox)sender).BackgroundImage = imglist_MuteBtn.Images[idx];
                ((System.Windows.Forms.CheckBox)sender).Tag = idx;
            }
            catch
            {
            }
        }
        private void chkbx_Mute_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.CheckBox)sender).Tag.ToString());
                idx--;
                ((System.Windows.Forms.CheckBox)sender).BackgroundImage = imglist_MuteBtn.Images[idx];
                ((System.Windows.Forms.CheckBox)sender).Tag = idx;
            }
            catch
            {
            }
        }

        //����������
        ////////private void btn_TimerSet_MouseEnter(object sender, EventArgs e)
        ////////{
        ////////    try
        ////////    {
        ////////        int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
        ////////        idx++;
        ////////        ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_TimerSet_btn.Images[idx];
        ////////        ((System.Windows.Forms.Button)sender).Tag = idx;
        ////////    }
        ////////    catch
        ////////    {
        ////////    }
        ////////}
        ////////private void btn_TimerSet_MouseLeave(object sender, EventArgs e)
        ////////{
        ////////    try
        ////////    {
        ////////        int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
        ////////        idx--;
        ////////        ((System.Windows.Forms.Button)sender).BackgroundImage = imglist_TimerSet_btn.Images[idx];
        ////////        ((System.Windows.Forms.Button)sender).Tag = idx;
        ////////    }
        ////////    catch
        ////////    {
        ////////    }
        ////////}

        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


    } //public partial class Form1 : Form

    //����������
    //////////public class TimerInfo
    //////////{
    //////////    [System.Xml.Serialization.XmlElement("TIMER_SET_DATE")]
    //////////    public DateTime set_date;
    //////////    [System.Xml.Serialization.XmlElement("SET_TIMER_ON_DATE")]
    //////////    public DateTime set_timer_on_date;
    //////////    [System.Xml.Serialization.XmlElement("SET_TIMER_OFF_DATE")]
    //////////    public DateTime set_timer_off_date;
    //////////    [System.Xml.Serialization.XmlElement("EXE_TIMER_ON_DATE")]
    //////////    public DateTime exe_timer_on_date;
    //////////    [System.Xml.Serialization.XmlElement("EXE_TIMER_OFF_DATE")]
    //////////    public DateTime exe_timer_off_date;
    //////////    [System.Xml.Serialization.XmlElement("BAND")]
    //////////    public int band;
    //////////    [System.Xml.Serialization.XmlElement("FREQ_AM")]
    //////////    public int frequency_am;
    //////////    [System.Xml.Serialization.XmlElement("FREQ_FM")]
    //////////    public int frequency_fm;
    //////////    [System.Xml.Serialization.XmlElement("TIMER_SET")]
    //////////    public bool timer_set_flag;
    //////////    [System.Xml.Serialization.XmlElement("EXE_TIMER_SET")]
    //////////    public bool exe_timer_set_flag;
    //////////    [System.Xml.Serialization.XmlElement("REPEAT_TYPE")]
    //////////    public int repeat_type;
    //////////    [System.Xml.Serialization.XmlElement("DAY_OF_WEEK")]
    //////////    public bool[] day_of_week;
    //////////    [System.Xml.Serialization.XmlElement("SAMPLE_FREQ")]
    //////////    public int sampling_freq;

    //////////    public TimerInfo()
    //////////    {
    //////////        set_date = System.DateTime.Now;
    //////////        set_date = set_date.AddSeconds((-1) * set_date.Second);
    //////////        set_date = set_date.AddMilliseconds((-1) * set_date.Millisecond);
    //////////        set_timer_on_date = set_date.AddMinutes(1);
    //////////        set_timer_off_date = set_date.AddMinutes(2);
    //////////        band = Form1.BAND_FM;
    //////////        frequency_am = Form1.AM_FRQ_MIN;
    //////////        frequency_fm = Form1.FM_FRQ_MIN;
    //////////        timer_set_flag = false;
    //////////        exe_timer_set_flag = false;
    //////////        repeat_type = Form1.REPEAT_TYPE_ONCE;
    //////////        day_of_week = new Boolean[7] { true, true, true, true, true, true, true };
    //////////        sampling_freq = 0;
    //////////    }

    //////////    public void Copy(TimerInfo source)
    //////////    {
    //////////        this.set_date = source.set_date;
    //////////        this.set_timer_on_date = source.set_timer_on_date;
    //////////        this.set_timer_off_date = source.set_timer_off_date;
    //////////        this.exe_timer_on_date = source.exe_timer_on_date;
    //////////        this.exe_timer_off_date = source.exe_timer_off_date;
    //////////        this.band = source.band;
    //////////        this.frequency_am = source.frequency_am;
    //////////        this.frequency_fm = source.frequency_fm;
    //////////        this.timer_set_flag = source.timer_set_flag;
    //////////        this.exe_timer_set_flag = source.exe_timer_set_flag;
    //////////        this.repeat_type = source.repeat_type;
    //////////        for (int fi = 0; fi < this.day_of_week.Length; fi++)
    //////////        {
    //////////            this.day_of_week[fi] = source.day_of_week[fi];
    //////////        }
    //////////        this.sampling_freq = source.sampling_freq;
    //////////    }
    //////////    /// <summary>
    //////////    /// ����̃^�C�}�[�Z�b�g
    //////////    /// </summary>
    //////////    /// <param name="FirarSetFlag">����ݒ�t���O</param>
    //////////    public void NextTimerSet(bool FirarSetFlag)
    //////////    {
    //////////        try
    //////////        {
    //////////            exe_timer_set_flag = false;

    //////////            if (FirarSetFlag == true)
    //////////            {   // ����̃^�C�}�[�Z�b�g�̂Ƃ��͌��ݓ������Z�b�g
    //////////                set_date = System.DateTime.Now;
    //////////            }

    //////////            if (timer_set_flag == true)
    //////////            {
    //////////                if (repeat_type == Form1.REPEAT_TYPE_ONCE && FirarSetFlag == true)
    //////////                {   //�@���^�C�}�[�̂Ƃ�
    //////////                    if (set_date < set_timer_on_date && set_timer_on_date < set_timer_off_date)
    //////////                    {
    //////////                        exe_timer_on_date = set_timer_on_date;
    //////////                        exe_timer_off_date = set_timer_off_date;

    //////////                        //�^�C�}�[���s�t���O�Z�b�g
    //////////                        exe_timer_set_flag = true;
    //////////                    }
    //////////                }
    //////////                else if (repeat_type == Form1.REPEAT_TYPE_EVERY_DAY || repeat_type == Form1.REPEAT_TYPE_DAY_OF_WEEK)
    //////////                {
    //////////                    DateTime dt_now = System.DateTime.Now;

    //////////                    System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo("ja-JP");
    //////////                    DateTime temp_Timer_On = DateTime.Parse(dt_now.ToString("yyyy/MM/dd ") + set_timer_on_date.ToString("HH:mm:ss"), ci, System.Globalization.DateTimeStyles.AssumeLocal);
    //////////                    DateTime temp_Timer_Off = DateTime.Parse(dt_now.ToString("yyyy/MM/dd ") + set_timer_off_date.ToString("HH:mm:ss"), ci, System.Globalization.DateTimeStyles.AssumeLocal);

    //////////                    TimeSpan ts = dt_now.Subtract(temp_Timer_On);
    //////////                    int add_day = ts.Days;
    //////////                    if (temp_Timer_On.Hour >= 0 && temp_Timer_On.Hour < dt_now.Hour)
    //////////                    {   //�ݒ肵������茻�݂̎����������ꍇ�͗���
    //////////                        add_day += 1;
    //////////                    }
    //////////                    else if (temp_Timer_On.Hour == dt_now.Hour && temp_Timer_On.Minute < dt_now.Minute)
    //////////                    {   //�ݒ肵������茻�݂̎��������ŕ����ݒ肵���l��菬�����ꍇ�͗���
    //////////                        add_day += 1; 
    //////////                    }
    //////////                    exe_timer_on_date = temp_Timer_On.AddDays(add_day);
    //////////                    exe_timer_off_date = temp_Timer_Off.AddDays(add_day);
    //////////                    if (exe_timer_on_date > exe_timer_off_date)
    //////////                    {
    //////////                        exe_timer_off_date = exe_timer_off_date.AddDays(1);
    //////////                    }
    //////////                    //���������ォ�`�F�b�N
    //////////                    if (repeat_type == Form1.REPEAT_TYPE_EVERY_DAY)
    //////////                    {   //����
    //////////                    }
    //////////                    else if (repeat_type == Form1.REPEAT_TYPE_DAY_OF_WEEK)
    //////////                    {   // �j���w�� ���̃`�F�b�N�������Ă���j���܂ł̓������J�E���g
    //////////                        add_day = 0;
    //////////                        int now_week = (int)exe_timer_on_date.DayOfWeek;
    //////////                        for (int fi = 0; fi < 7; fi++)
    //////////                        {
    //////////                            if (day_of_week[now_week] == true)
    //////////                            {
    //////////                                break;
    //////////                            }
    //////////                            add_day++;
    //////////                            now_week++;
    //////////                            if(now_week > (int)DayOfWeek.Saturday)
    //////////                            {
    //////////                                now_week = (int)DayOfWeek.Sunday;
    //////////                            }
    //////////                        }
    //////////                        exe_timer_on_date = exe_timer_on_date.AddDays(add_day);
    //////////                        exe_timer_off_date = exe_timer_off_date.AddDays(add_day);
    //////////                    }
    //////////                    set_timer_on_date = exe_timer_on_date;
    //////////                    set_timer_off_date = exe_timer_off_date;
    //////////                    //�^�C�}�[���s�t���O�Z�b�g
    //////////                    exe_timer_set_flag = true;
    //////////                }
    //////////            }
    //////////        }
    //////////        catch
    //////////        {
    //////////        }
    //////////    }
    //////////}
} //namespace HID_PnP_Demo