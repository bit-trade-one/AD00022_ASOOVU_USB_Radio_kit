namespace RadioWaveMonitor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.connect_status_lbl = new System.Windows.Forms.Label();
            this.debug01_lbl = new System.Windows.Forms.Label();
            this.debug02_lbl = new System.Windows.Forms.Label();
            this.debug03_lbl = new System.Windows.Forms.Label();
            this.colum_lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.AMSet_btn = new System.Windows.Forms.Button();
            this.FMSet_btn = new System.Windows.Forms.Button();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.Freq_lbl = new System.Windows.Forms.Label();
            this.Level_lbl = new System.Windows.Forms.Label();
            this.Vol_lbl = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.trkbar_Freq = new System.Windows.Forms.TrackBar();
            this.VolumeSet_btn = new System.Windows.Forms.Button();
            this.SNR_lbl = new System.Windows.Forms.Label();
            this.WaveScanTimer = new System.Windows.Forms.Timer(this.components);
            this.lbl_debug = new System.Windows.Forms.Label();
            this.FreqChangeTimer = new System.Windows.Forms.Timer(this.components);
            this.imglist_Number_M = new System.Windows.Forms.ImageList(this.components);
            this.lbl_TimerOn = new System.Windows.Forms.Label();
            this.lbl_TimerOff = new System.Windows.Forms.Label();
            this.RecordingTimer = new System.Windows.Forms.Timer(this.components);
            this.bgw_CaptureBufferWrite = new System.ComponentModel.BackgroundWorker();
            this.imglist_Number_S = new System.Windows.Forms.ImageList(this.components);
            this.imglist_RSSI_scale = new System.Windows.Forms.ImageList(this.components);
            this.imglist_Band_Wide = new System.Windows.Forms.ImageList(this.components);
            this.btn_Maximize = new System.Windows.Forms.Button();
            this.imglist_Controlbox = new System.Windows.Forms.ImageList(this.components);
            this.btn_Close = new System.Windows.Forms.Button();
            this.btn_Minimize = new System.Windows.Forms.Button();
            this.imglist_ScanProcess = new System.Windows.Forms.ImageList(this.components);
            this.imglist_ScanBtn = new System.Windows.Forms.ImageList(this.components);
            this.imglist_Number_L = new System.Windows.Forms.ImageList(this.components);
            this.imglist_BandBtn = new System.Windows.Forms.ImageList(this.components);
            this.imglist_FreqChangeBtn = new System.Windows.Forms.ImageList(this.components);
            this.imglist_MuteBtn = new System.Windows.Forms.ImageList(this.components);
            this.btn_TimerDaily = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.imglist_TimerBand = new System.Windows.Forms.ImageList(this.components);
            this.imglist_TimerSet_btn = new System.Windows.Forms.ImageList(this.components);
            this.imglist_SNR_scale = new System.Windows.Forms.ImageList(this.components);
            this.pnl_Timer = new System.Windows.Forms.Panel();
            this.picbx_TimerOn_Weekly = new System.Windows.Forms.PictureBox();
            this.picbx_TimerOn_Daily = new System.Windows.Forms.PictureBox();
            this.picbx_TimerSRate_dot = new System.Windows.Forms.PictureBox();
            this.picbx_TimerFreq_dot = new System.Windows.Forms.PictureBox();
            this.picbx_TimerOn_Once = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Band = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_FMFreqUnit = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Freq_1 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_AMFreqUnit = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Freq_10 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_OFFTime_M1 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Freq_100 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_OFFTime_M10 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Freq_1000 = new System.Windows.Forms.PictureBox();
            this.btn_TimerSet = new System.Windows.Forms.Button();
            this.picbx_Timer_OFFTime_H1 = new System.Windows.Forms.PictureBox();
            this.picbx_SRate_1 = new System.Windows.Forms.PictureBox();
            this.picbx_SRate_10 = new System.Windows.Forms.PictureBox();
            this.picbx_SRate_100 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_OFFTime_H10 = new System.Windows.Forms.PictureBox();
            this.picbx_SRate_1000 = new System.Windows.Forms.PictureBox();
            this.picbx_SRate_10000 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Date_Y1000 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_ONTime_M1 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_ONTime_M10 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Date_Y100 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_ONTime_H1 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Date_Y10 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_ONTime_H10 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Date_Y1 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Date_D1 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Date_M10 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Date_D10 = new System.Windows.Forms.PictureBox();
            this.picbx_Timer_Date_M1 = new System.Windows.Forms.PictureBox();
            this.pnl_RadioMain = new System.Windows.Forms.Panel();
            this.picbx_Band_FM = new System.Windows.Forms.PictureBox();
            this.picbx_FM_scale = new System.Windows.Forms.PictureBox();
            this.picbx_VolumeLevel6 = new System.Windows.Forms.PictureBox();
            this.picbx_AM_scale = new System.Windows.Forms.PictureBox();
            this.picbx_VolumeLevel5 = new System.Windows.Forms.PictureBox();
            this.picbx_Stereo = new System.Windows.Forms.PictureBox();
            this.picbx_VolumeLevel4 = new System.Windows.Forms.PictureBox();
            this.picbx_Tuned = new System.Windows.Forms.PictureBox();
            this.picbx_VolumeLevel3 = new System.Windows.Forms.PictureBox();
            this.picbx_Freq_dot = new System.Windows.Forms.PictureBox();
            this.picbx_VolumeLevel2 = new System.Windows.Forms.PictureBox();
            this.picbx_Bandwidth = new System.Windows.Forms.PictureBox();
            this.picbx_ScanProcess = new System.Windows.Forms.PictureBox();
            this.picbx_Band_AM = new System.Windows.Forms.PictureBox();
            this.picbx_VolumeLevel1 = new System.Windows.Forms.PictureBox();
            this.picbx_FMFreqUnit = new System.Windows.Forms.PictureBox();
            this.btn_ScanCancel = new System.Windows.Forms.Button();
            this.picbx_AMFreqUnit = new System.Windows.Forms.PictureBox();
            this.picbx_Mute = new System.Windows.Forms.PictureBox();
            this.picbx_rssi_scale_1 = new System.Windows.Forms.PictureBox();
            this.picbx_snr_scale_2 = new System.Windows.Forms.PictureBox();
            this.picbx_rssi_scale_2 = new System.Windows.Forms.PictureBox();
            this.picbx_snr_scale_1 = new System.Windows.Forms.PictureBox();
            this.picbx_Vol_1 = new System.Windows.Forms.PictureBox();
            this.picbx_Vol_10 = new System.Windows.Forms.PictureBox();
            this.picbx_FMFreq_P1 = new System.Windows.Forms.PictureBox();
            this.picbx_FMFreq_1 = new System.Windows.Forms.PictureBox();
            this.picbx_AMFreq_1 = new System.Windows.Forms.PictureBox();
            this.picbx_FMFreq_10 = new System.Windows.Forms.PictureBox();
            this.chkbx_Mute = new System.Windows.Forms.CheckBox();
            this.picbx_FMFreq_100 = new System.Windows.Forms.PictureBox();
            this.picbx_AMFreq_10 = new System.Windows.Forms.PictureBox();
            this.btn_FreqUp = new System.Windows.Forms.Button();
            this.picbx_AMFreq_100 = new System.Windows.Forms.PictureBox();
            this.picbx_AMFreq_1000 = new System.Windows.Forms.PictureBox();
            this.btn_FreqDown = new System.Windows.Forms.Button();
            this.btn_Bandwidth_Up = new System.Windows.Forms.Button();
            this.picbx_ScanWave = new System.Windows.Forms.PictureBox();
            this.btn_Bandwidth_Down = new System.Windows.Forms.Button();
            this.trkbar_Volume = new System.Windows.Forms.TrackBar();
            this.btn_Band = new System.Windows.Forms.Button();
            this.btn_Scan = new System.Windows.Forms.Button();
            this.SeekDown_btn = new System.Windows.Forms.Button();
            this.SeekUp_btn = new System.Windows.Forms.Button();
            this.picbx_TitleBar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Freq)).BeginInit();
            this.pnl_Timer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerOn_Weekly)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerOn_Daily)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerSRate_dot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerFreq_dot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerOn_Once)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Band)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_FMFreqUnit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Freq_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_AMFreqUnit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Freq_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_OFFTime_M1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Freq_100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_OFFTime_M10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Freq_1000)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_OFFTime_H1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_OFFTime_H10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_1000)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_10000)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_Y1000)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_ONTime_M1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_ONTime_M10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_Y100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_ONTime_H1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_Y10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_ONTime_H10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_Y1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_D1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_M10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_D10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_M1)).BeginInit();
            this.pnl_RadioMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Band_FM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FM_scale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AM_scale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Stereo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Tuned)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Freq_dot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Bandwidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_ScanProcess)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Band_AM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreqUnit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreqUnit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Mute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_rssi_scale_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_snr_scale_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_rssi_scale_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_snr_scale_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Vol_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Vol_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreq_P1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreq_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreq_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreq_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreq_100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreq_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreq_100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreq_1000)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_ScanWave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Volume)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TitleBar)).BeginInit();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // connect_status_lbl
            // 
            this.connect_status_lbl.AutoSize = true;
            this.connect_status_lbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.connect_status_lbl.Enabled = false;
            this.connect_status_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(27)))), ((int)(((byte)(26)))));
            this.connect_status_lbl.Location = new System.Drawing.Point(874, 630);
            this.connect_status_lbl.Name = "connect_status_lbl";
            this.connect_status_lbl.Size = new System.Drawing.Size(41, 12);
            this.connect_status_lbl.TabIndex = 26;
            this.connect_status_lbl.Text = "���ڑ�";
            // 
            // debug01_lbl
            // 
            this.debug01_lbl.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug01_lbl.Location = new System.Drawing.Point(18, 34);
            this.debug01_lbl.Name = "debug01_lbl";
            this.debug01_lbl.Size = new System.Drawing.Size(700, 18);
            this.debug01_lbl.TabIndex = 27;
            this.debug01_lbl.Text = "label1";
            // 
            // debug02_lbl
            // 
            this.debug02_lbl.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug02_lbl.Location = new System.Drawing.Point(18, 52);
            this.debug02_lbl.Name = "debug02_lbl";
            this.debug02_lbl.Size = new System.Drawing.Size(700, 18);
            this.debug02_lbl.TabIndex = 28;
            this.debug02_lbl.Text = "label1";
            // 
            // debug03_lbl
            // 
            this.debug03_lbl.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug03_lbl.Location = new System.Drawing.Point(18, 70);
            this.debug03_lbl.Name = "debug03_lbl";
            this.debug03_lbl.Size = new System.Drawing.Size(700, 18);
            this.debug03_lbl.TabIndex = 29;
            this.debug03_lbl.Text = "label1";
            // 
            // colum_lbl
            // 
            this.colum_lbl.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.colum_lbl.Location = new System.Drawing.Point(18, 16);
            this.colum_lbl.Name = "colum_lbl";
            this.colum_lbl.Size = new System.Drawing.Size(700, 18);
            this.colum_lbl.TabIndex = 31;
            this.colum_lbl.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(10, 544);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 19);
            this.label1.TabIndex = 65;
            this.label1.Text = "AM";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown1.Increment = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(62, 538);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1629,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            522,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(85, 26);
            this.numericUpDown1.TabIndex = 66;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown1.Value = new decimal(new int[] {
            522,
            0,
            0,
            0});
            // 
            // AMSet_btn
            // 
            this.AMSet_btn.Location = new System.Drawing.Point(159, 540);
            this.AMSet_btn.Name = "AMSet_btn";
            this.AMSet_btn.Size = new System.Drawing.Size(102, 23);
            this.AMSet_btn.TabIndex = 67;
            this.AMSet_btn.Text = "AM SET";
            this.AMSet_btn.UseVisualStyleBackColor = true;
            this.AMSet_btn.Click += new System.EventHandler(this.AMSet_btn_Click);
            // 
            // FMSet_btn
            // 
            this.FMSet_btn.Location = new System.Drawing.Point(159, 570);
            this.FMSet_btn.Name = "FMSet_btn";
            this.FMSet_btn.Size = new System.Drawing.Size(102, 23);
            this.FMSet_btn.TabIndex = 70;
            this.FMSet_btn.Text = "FM SET";
            this.FMSet_btn.UseVisualStyleBackColor = true;
            this.FMSet_btn.Click += new System.EventHandler(this.FMSet_btn_Click);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DecimalPlaces = 1;
            this.numericUpDown2.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown2.Location = new System.Drawing.Point(62, 570);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            108,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            76,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(85, 26);
            this.numericUpDown2.TabIndex = 69;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown2.Value = new decimal(new int[] {
            76,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(10, 574);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 19);
            this.label2.TabIndex = 68;
            this.label2.Text = "FM";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown3.Location = new System.Drawing.Point(62, 601);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            63,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(85, 26);
            this.numericUpDown3.TabIndex = 72;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Enabled = false;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(10, 605);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 19);
            this.label3.TabIndex = 71;
            this.label3.Text = "����";
            // 
            // Freq_lbl
            // 
            this.Freq_lbl.AutoSize = true;
            this.Freq_lbl.Enabled = false;
            this.Freq_lbl.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Freq_lbl.Location = new System.Drawing.Point(281, 592);
            this.Freq_lbl.Name = "Freq_lbl";
            this.Freq_lbl.Size = new System.Drawing.Size(66, 19);
            this.Freq_lbl.TabIndex = 76;
            this.Freq_lbl.Text = "���g��";
            // 
            // Level_lbl
            // 
            this.Level_lbl.AutoSize = true;
            this.Level_lbl.Enabled = false;
            this.Level_lbl.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Level_lbl.Location = new System.Drawing.Point(281, 619);
            this.Level_lbl.Name = "Level_lbl";
            this.Level_lbl.Size = new System.Drawing.Size(38, 19);
            this.Level_lbl.TabIndex = 77;
            this.Level_lbl.Text = "rssi";
            // 
            // Vol_lbl
            // 
            this.Vol_lbl.AutoSize = true;
            this.Vol_lbl.Enabled = false;
            this.Vol_lbl.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Vol_lbl.Location = new System.Drawing.Point(382, 592);
            this.Vol_lbl.Name = "Vol_lbl";
            this.Vol_lbl.Size = new System.Drawing.Size(69, 19);
            this.Vol_lbl.TabIndex = 79;
            this.Vol_lbl.Text = "Volume";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.debug01_lbl);
            this.groupBox1.Controls.Add(this.debug02_lbl);
            this.groupBox1.Controls.Add(this.debug03_lbl);
            this.groupBox1.Controls.Add(this.colum_lbl);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(275, 489);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(737, 90);
            this.groupBox1.TabIndex = 92;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // trkbar_Freq
            // 
            this.trkbar_Freq.Enabled = false;
            this.trkbar_Freq.LargeChange = 10;
            this.trkbar_Freq.Location = new System.Drawing.Point(613, 581);
            this.trkbar_Freq.Maximum = 1080;
            this.trkbar_Freq.Minimum = 640;
            this.trkbar_Freq.Name = "trkbar_Freq";
            this.trkbar_Freq.Size = new System.Drawing.Size(368, 45);
            this.trkbar_Freq.TabIndex = 90;
            this.trkbar_Freq.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trkbar_Freq.Value = 640;
            // 
            // VolumeSet_btn
            // 
            this.VolumeSet_btn.Location = new System.Drawing.Point(159, 601);
            this.VolumeSet_btn.Name = "VolumeSet_btn";
            this.VolumeSet_btn.Size = new System.Drawing.Size(102, 23);
            this.VolumeSet_btn.TabIndex = 73;
            this.VolumeSet_btn.Text = "VOLUME SET";
            this.VolumeSet_btn.UseVisualStyleBackColor = true;
            this.VolumeSet_btn.Click += new System.EventHandler(this.VolumeSet_btn_Click);
            // 
            // SNR_lbl
            // 
            this.SNR_lbl.AutoSize = true;
            this.SNR_lbl.Enabled = false;
            this.SNR_lbl.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.SNR_lbl.Location = new System.Drawing.Point(382, 619);
            this.SNR_lbl.Name = "SNR_lbl";
            this.SNR_lbl.Size = new System.Drawing.Size(35, 19);
            this.SNR_lbl.TabIndex = 95;
            this.SNR_lbl.Text = "snr";
            // 
            // WaveScanTimer
            // 
            this.WaveScanTimer.Tick += new System.EventHandler(this.WaveScanTimer_Tick);
            // 
            // lbl_debug
            // 
            this.lbl_debug.AutoSize = true;
            this.lbl_debug.Enabled = false;
            this.lbl_debug.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_debug.Location = new System.Drawing.Point(529, 582);
            this.lbl_debug.Name = "lbl_debug";
            this.lbl_debug.Size = new System.Drawing.Size(46, 16);
            this.lbl_debug.TabIndex = 96;
            this.lbl_debug.Text = "label4";
            // 
            // FreqChangeTimer
            // 
            this.FreqChangeTimer.Tick += new System.EventHandler(this.FreqChangeTimer_Tick);
            // 
            // imglist_Number_M
            // 
            this.imglist_Number_M.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_Number_M.ImageStream")));
            this.imglist_Number_M.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_Number_M.Images.SetKeyName(0, "MID-0.png");
            this.imglist_Number_M.Images.SetKeyName(1, "MID-1.png");
            this.imglist_Number_M.Images.SetKeyName(2, "MID-2.png");
            this.imglist_Number_M.Images.SetKeyName(3, "MID-3.png");
            this.imglist_Number_M.Images.SetKeyName(4, "MID-4.png");
            this.imglist_Number_M.Images.SetKeyName(5, "MID-5.png");
            this.imglist_Number_M.Images.SetKeyName(6, "MID-6.png");
            this.imglist_Number_M.Images.SetKeyName(7, "MID-7.png");
            this.imglist_Number_M.Images.SetKeyName(8, "MID-8.png");
            this.imglist_Number_M.Images.SetKeyName(9, "MID-9.png");
            this.imglist_Number_M.Images.SetKeyName(10, "MID-�n�C�t��.png");
            // 
            // lbl_TimerOn
            // 
            this.lbl_TimerOn.AutoSize = true;
            this.lbl_TimerOn.Enabled = false;
            this.lbl_TimerOn.Location = new System.Drawing.Point(527, 611);
            this.lbl_TimerOn.Name = "lbl_TimerOn";
            this.lbl_TimerOn.Size = new System.Drawing.Size(35, 12);
            this.lbl_TimerOn.TabIndex = 97;
            this.lbl_TimerOn.Text = "label4";
            // 
            // lbl_TimerOff
            // 
            this.lbl_TimerOff.AutoSize = true;
            this.lbl_TimerOff.Enabled = false;
            this.lbl_TimerOff.Location = new System.Drawing.Point(528, 628);
            this.lbl_TimerOff.Name = "lbl_TimerOff";
            this.lbl_TimerOff.Size = new System.Drawing.Size(35, 12);
            this.lbl_TimerOff.TabIndex = 98;
            this.lbl_TimerOff.Text = "label5";
            // 
            // RecordingTimer
            // 
            this.RecordingTimer.Interval = 500;
            this.RecordingTimer.Tick += new System.EventHandler(this.RecordingTimer_Tick);
            // 
            // bgw_CaptureBufferWrite
            // 
            this.bgw_CaptureBufferWrite.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgw_CaptureBufferWrite_DoWork);
            // 
            // imglist_Number_S
            // 
            this.imglist_Number_S.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_Number_S.ImageStream")));
            this.imglist_Number_S.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_Number_S.Images.SetKeyName(0, "SML-0.png");
            this.imglist_Number_S.Images.SetKeyName(1, "SML-1.png");
            this.imglist_Number_S.Images.SetKeyName(2, "SML-2.png");
            this.imglist_Number_S.Images.SetKeyName(3, "SML-3.png");
            this.imglist_Number_S.Images.SetKeyName(4, "SML-4.png");
            this.imglist_Number_S.Images.SetKeyName(5, "SML-5.png");
            this.imglist_Number_S.Images.SetKeyName(6, "SML-6.png");
            this.imglist_Number_S.Images.SetKeyName(7, "SML-7.png");
            this.imglist_Number_S.Images.SetKeyName(8, "SML-8.png");
            this.imglist_Number_S.Images.SetKeyName(9, "SML-9.png");
            this.imglist_Number_S.Images.SetKeyName(10, "SML-�n�C�t��.png");
            // 
            // imglist_RSSI_scale
            // 
            this.imglist_RSSI_scale.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_RSSI_scale.ImageStream")));
            this.imglist_RSSI_scale.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_RSSI_scale.Images.SetKeyName(0, "000.png");
            this.imglist_RSSI_scale.Images.SetKeyName(1, "005.png");
            this.imglist_RSSI_scale.Images.SetKeyName(2, "010.png");
            this.imglist_RSSI_scale.Images.SetKeyName(3, "015.png");
            this.imglist_RSSI_scale.Images.SetKeyName(4, "020.png");
            this.imglist_RSSI_scale.Images.SetKeyName(5, "025.png");
            this.imglist_RSSI_scale.Images.SetKeyName(6, "030.png");
            this.imglist_RSSI_scale.Images.SetKeyName(7, "035.png");
            this.imglist_RSSI_scale.Images.SetKeyName(8, "040.png");
            this.imglist_RSSI_scale.Images.SetKeyName(9, "045.png");
            this.imglist_RSSI_scale.Images.SetKeyName(10, "050.png");
            this.imglist_RSSI_scale.Images.SetKeyName(11, "055.png");
            this.imglist_RSSI_scale.Images.SetKeyName(12, "060.png");
            this.imglist_RSSI_scale.Images.SetKeyName(13, "065.png");
            this.imglist_RSSI_scale.Images.SetKeyName(14, "070.png");
            this.imglist_RSSI_scale.Images.SetKeyName(15, "075.png");
            this.imglist_RSSI_scale.Images.SetKeyName(16, "080.png");
            this.imglist_RSSI_scale.Images.SetKeyName(17, "085.png");
            this.imglist_RSSI_scale.Images.SetKeyName(18, "090.png");
            this.imglist_RSSI_scale.Images.SetKeyName(19, "095.png");
            this.imglist_RSSI_scale.Images.SetKeyName(20, "100.png");
            this.imglist_RSSI_scale.Images.SetKeyName(21, "105.png");
            this.imglist_RSSI_scale.Images.SetKeyName(22, "110.png");
            this.imglist_RSSI_scale.Images.SetKeyName(23, "115.png");
            this.imglist_RSSI_scale.Images.SetKeyName(24, "120.png");
            this.imglist_RSSI_scale.Images.SetKeyName(25, "125.png");
            this.imglist_RSSI_scale.Images.SetKeyName(26, "130.png");
            // 
            // imglist_Band_Wide
            // 
            this.imglist_Band_Wide.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_Band_Wide.ImageStream")));
            this.imglist_Band_Wide.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_Band_Wide.Images.SetKeyName(0, "2-BAND_world.png");
            this.imglist_Band_Wide.Images.SetKeyName(1, "2-BAND_japan.png");
            // 
            // btn_Maximize
            // 
            this.btn_Maximize.BackColor = System.Drawing.Color.Transparent;
            this.btn_Maximize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Maximize.Enabled = false;
            this.btn_Maximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Maximize.ImageList = this.imglist_Controlbox;
            this.btn_Maximize.Location = new System.Drawing.Point(983, 3);
            this.btn_Maximize.Name = "btn_Maximize";
            this.btn_Maximize.Size = new System.Drawing.Size(17, 17);
            this.btn_Maximize.TabIndex = 1;
            this.btn_Maximize.UseVisualStyleBackColor = false;
            // 
            // imglist_Controlbox
            // 
            this.imglist_Controlbox.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_Controlbox.ImageStream")));
            this.imglist_Controlbox.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_Controlbox.Images.SetKeyName(0, "1-close_normal.png");
            this.imglist_Controlbox.Images.SetKeyName(1, "1-close_on.png");
            this.imglist_Controlbox.Images.SetKeyName(2, "1-max_normal.png");
            this.imglist_Controlbox.Images.SetKeyName(3, "1-max_on.png");
            this.imglist_Controlbox.Images.SetKeyName(4, "1-min_normal.png");
            this.imglist_Controlbox.Images.SetKeyName(5, "1-min_on.png");
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.Transparent;
            this.btn_Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Close.Location = new System.Drawing.Point(1002, 3);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(17, 17);
            this.btn_Close.TabIndex = 2;
            this.btn_Close.UseVisualStyleBackColor = false;
            this.btn_Close.MouseLeave += new System.EventHandler(this.btn_Controlbox_MouseLeave);
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            this.btn_Close.MouseEnter += new System.EventHandler(this.btn_Controlbox_MouseEnter);
            // 
            // btn_Minimize
            // 
            this.btn_Minimize.BackColor = System.Drawing.Color.Transparent;
            this.btn_Minimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Minimize.ImageList = this.imglist_Controlbox;
            this.btn_Minimize.Location = new System.Drawing.Point(964, 3);
            this.btn_Minimize.Name = "btn_Minimize";
            this.btn_Minimize.Size = new System.Drawing.Size(17, 17);
            this.btn_Minimize.TabIndex = 0;
            this.btn_Minimize.UseVisualStyleBackColor = false;
            this.btn_Minimize.MouseLeave += new System.EventHandler(this.btn_Controlbox_MouseLeave);
            this.btn_Minimize.Click += new System.EventHandler(this.btn_Minimize_Click);
            this.btn_Minimize.MouseEnter += new System.EventHandler(this.btn_Controlbox_MouseEnter);
            // 
            // imglist_ScanProcess
            // 
            this.imglist_ScanProcess.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_ScanProcess.ImageStream")));
            this.imglist_ScanProcess.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_ScanProcess.Images.SetKeyName(0, "2-SCANNING_0.png");
            this.imglist_ScanProcess.Images.SetKeyName(1, "2-SCANNING_1.png");
            this.imglist_ScanProcess.Images.SetKeyName(2, "2-SCANNING_2.png");
            this.imglist_ScanProcess.Images.SetKeyName(3, "2-SCANNING_3.png");
            // 
            // imglist_ScanBtn
            // 
            this.imglist_ScanBtn.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_ScanBtn.ImageStream")));
            this.imglist_ScanBtn.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_ScanBtn.Images.SetKeyName(0, "2-SCAN_scan.png");
            this.imglist_ScanBtn.Images.SetKeyName(1, "2-SCAN_scan_mouseon.png");
            this.imglist_ScanBtn.Images.SetKeyName(2, "2-SCAN_cancel.png");
            this.imglist_ScanBtn.Images.SetKeyName(3, "2-SCAN_cancel_mouse_on.png");
            // 
            // imglist_Number_L
            // 
            this.imglist_Number_L.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_Number_L.ImageStream")));
            this.imglist_Number_L.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_Number_L.Images.SetKeyName(0, "BIG-0.png");
            this.imglist_Number_L.Images.SetKeyName(1, "BIG-1.png");
            this.imglist_Number_L.Images.SetKeyName(2, "BIG-2.png");
            this.imglist_Number_L.Images.SetKeyName(3, "BIG-3.png");
            this.imglist_Number_L.Images.SetKeyName(4, "BIG-4.png");
            this.imglist_Number_L.Images.SetKeyName(5, "BIG-5.png");
            this.imglist_Number_L.Images.SetKeyName(6, "BIG-6.png");
            this.imglist_Number_L.Images.SetKeyName(7, "BIG-7.png");
            this.imglist_Number_L.Images.SetKeyName(8, "BIG-8.png");
            this.imglist_Number_L.Images.SetKeyName(9, "BIG-9.png");
            this.imglist_Number_L.Images.SetKeyName(10, "BIG-�n�C�t��.png");
            // 
            // imglist_BandBtn
            // 
            this.imglist_BandBtn.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_BandBtn.ImageStream")));
            this.imglist_BandBtn.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_BandBtn.Images.SetKeyName(0, "3-BAND_normal.png");
            this.imglist_BandBtn.Images.SetKeyName(1, "3-BAND_on.png");
            // 
            // imglist_FreqChangeBtn
            // 
            this.imglist_FreqChangeBtn.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_FreqChangeBtn.ImageStream")));
            this.imglist_FreqChangeBtn.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_FreqChangeBtn.Images.SetKeyName(0, "3-SEEK_down_normal.png");
            this.imglist_FreqChangeBtn.Images.SetKeyName(1, "3-SEEK_down_on.png");
            this.imglist_FreqChangeBtn.Images.SetKeyName(2, "3-SEEK_up_normal.png");
            this.imglist_FreqChangeBtn.Images.SetKeyName(3, "3-SEEK_up_on.png");
            this.imglist_FreqChangeBtn.Images.SetKeyName(4, "3-Freq_down_normal.png");
            this.imglist_FreqChangeBtn.Images.SetKeyName(5, "3-Freq_down_on.png");
            this.imglist_FreqChangeBtn.Images.SetKeyName(6, "3-Freq_up_normal.png");
            this.imglist_FreqChangeBtn.Images.SetKeyName(7, "3-Freq_up_on.png");
            // 
            // imglist_MuteBtn
            // 
            this.imglist_MuteBtn.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_MuteBtn.ImageStream")));
            this.imglist_MuteBtn.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_MuteBtn.Images.SetKeyName(0, "4-MUTE_normal.png");
            this.imglist_MuteBtn.Images.SetKeyName(1, "4-MUTE_on.png");
            // 
            // btn_TimerDaily
            // 
            this.btn_TimerDaily.Enabled = false;
            this.btn_TimerDaily.Location = new System.Drawing.Point(114, 511);
            this.btn_TimerDaily.Name = "btn_TimerDaily";
            this.btn_TimerDaily.Size = new System.Drawing.Size(75, 23);
            this.btn_TimerDaily.TabIndex = 87;
            this.btn_TimerDaily.Text = "every day";
            this.btn_TimerDaily.UseVisualStyleBackColor = true;
            this.btn_TimerDaily.Click += new System.EventHandler(this.my_TimerSetClick);
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(194, 511);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 88;
            this.button4.Text = "day of week";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.my_TimerSetClick);
            // 
            // imglist_TimerBand
            // 
            this.imglist_TimerBand.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_TimerBand.ImageStream")));
            this.imglist_TimerBand.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_TimerBand.Images.SetKeyName(0, "SML_AM.png");
            this.imglist_TimerBand.Images.SetKeyName(1, "SML_FM.png");
            // 
            // imglist_TimerSet_btn
            // 
            this.imglist_TimerSet_btn.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_TimerSet_btn.ImageStream")));
            this.imglist_TimerSet_btn.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_TimerSet_btn.Images.SetKeyName(0, "5-TimerSetting_normal.png");
            this.imglist_TimerSet_btn.Images.SetKeyName(1, "5-TimerSetting_on.png");
            // 
            // imglist_SNR_scale
            // 
            this.imglist_SNR_scale.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_SNR_scale.ImageStream")));
            this.imglist_SNR_scale.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_SNR_scale.Images.SetKeyName(0, "000.png");
            this.imglist_SNR_scale.Images.SetKeyName(1, "005.png");
            this.imglist_SNR_scale.Images.SetKeyName(2, "010.png");
            this.imglist_SNR_scale.Images.SetKeyName(3, "015.png");
            this.imglist_SNR_scale.Images.SetKeyName(4, "020.png");
            this.imglist_SNR_scale.Images.SetKeyName(5, "025.png");
            this.imglist_SNR_scale.Images.SetKeyName(6, "030.png");
            this.imglist_SNR_scale.Images.SetKeyName(7, "035.png");
            this.imglist_SNR_scale.Images.SetKeyName(8, "040.png");
            this.imglist_SNR_scale.Images.SetKeyName(9, "045.png");
            this.imglist_SNR_scale.Images.SetKeyName(10, "050.png");
            this.imglist_SNR_scale.Images.SetKeyName(11, "055.png");
            this.imglist_SNR_scale.Images.SetKeyName(12, "060.png");
            this.imglist_SNR_scale.Images.SetKeyName(13, "065.png");
            this.imglist_SNR_scale.Images.SetKeyName(14, "070.png");
            this.imglist_SNR_scale.Images.SetKeyName(15, "075.png");
            this.imglist_SNR_scale.Images.SetKeyName(16, "080.png");
            this.imglist_SNR_scale.Images.SetKeyName(17, "085.png");
            this.imglist_SNR_scale.Images.SetKeyName(18, "090.png");
            this.imglist_SNR_scale.Images.SetKeyName(19, "095.png");
            this.imglist_SNR_scale.Images.SetKeyName(20, "100.png");
            this.imglist_SNR_scale.Images.SetKeyName(21, "105.png");
            this.imglist_SNR_scale.Images.SetKeyName(22, "110.png");
            this.imglist_SNR_scale.Images.SetKeyName(23, "115.png");
            this.imglist_SNR_scale.Images.SetKeyName(24, "120.png");
            this.imglist_SNR_scale.Images.SetKeyName(25, "125.png");
            this.imglist_SNR_scale.Images.SetKeyName(26, "130.png");
            // 
            // pnl_Timer
            // 
            this.pnl_Timer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl_Timer.BackgroundImage")));
            this.pnl_Timer.Controls.Add(this.picbx_TimerOn_Weekly);
            this.pnl_Timer.Controls.Add(this.picbx_TimerOn_Daily);
            this.pnl_Timer.Controls.Add(this.picbx_TimerSRate_dot);
            this.pnl_Timer.Controls.Add(this.picbx_TimerFreq_dot);
            this.pnl_Timer.Controls.Add(this.picbx_TimerOn_Once);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Band);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_FMFreqUnit);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Freq_1);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_AMFreqUnit);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Freq_10);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_OFFTime_M1);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Freq_100);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_OFFTime_M10);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Freq_1000);
            this.pnl_Timer.Controls.Add(this.btn_TimerSet);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_OFFTime_H1);
            this.pnl_Timer.Controls.Add(this.picbx_SRate_1);
            this.pnl_Timer.Controls.Add(this.picbx_SRate_10);
            this.pnl_Timer.Controls.Add(this.picbx_SRate_100);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_OFFTime_H10);
            this.pnl_Timer.Controls.Add(this.picbx_SRate_1000);
            this.pnl_Timer.Controls.Add(this.picbx_SRate_10000);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Date_Y1000);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_ONTime_M1);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_ONTime_M10);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Date_Y100);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_ONTime_H1);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Date_Y10);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_ONTime_H10);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Date_Y1);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Date_D1);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Date_M10);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Date_D10);
            this.pnl_Timer.Controls.Add(this.picbx_Timer_Date_M1);
            this.pnl_Timer.Location = new System.Drawing.Point(0, 431);
            this.pnl_Timer.Name = "pnl_Timer";
            this.pnl_Timer.Size = new System.Drawing.Size(1024, 52);
            this.pnl_Timer.TabIndex = 93;
            // 
            // picbx_TimerOn_Weekly
            // 
            this.picbx_TimerOn_Weekly.BackColor = System.Drawing.Color.Transparent;
            this.picbx_TimerOn_Weekly.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.Timer_weekly;
            this.picbx_TimerOn_Weekly.Location = new System.Drawing.Point(25, 16);
            this.picbx_TimerOn_Weekly.Name = "picbx_TimerOn_Weekly";
            this.picbx_TimerOn_Weekly.Size = new System.Drawing.Size(81, 14);
            this.picbx_TimerOn_Weekly.TabIndex = 102;
            this.picbx_TimerOn_Weekly.TabStop = false;
            this.picbx_TimerOn_Weekly.Visible = false;
            // 
            // picbx_TimerOn_Daily
            // 
            this.picbx_TimerOn_Daily.BackColor = System.Drawing.Color.Transparent;
            this.picbx_TimerOn_Daily.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.Timer_Daily;
            this.picbx_TimerOn_Daily.Location = new System.Drawing.Point(25, 16);
            this.picbx_TimerOn_Daily.Name = "picbx_TimerOn_Daily";
            this.picbx_TimerOn_Daily.Size = new System.Drawing.Size(81, 14);
            this.picbx_TimerOn_Daily.TabIndex = 101;
            this.picbx_TimerOn_Daily.TabStop = false;
            this.picbx_TimerOn_Daily.Visible = false;
            // 
            // picbx_TimerSRate_dot
            // 
            this.picbx_TimerSRate_dot.BackColor = System.Drawing.Color.Transparent;
            this.picbx_TimerSRate_dot.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.SML_dot;
            this.picbx_TimerSRate_dot.Location = new System.Drawing.Point(747, 16);
            this.picbx_TimerSRate_dot.Name = "picbx_TimerSRate_dot";
            this.picbx_TimerSRate_dot.Size = new System.Drawing.Size(6, 15);
            this.picbx_TimerSRate_dot.TabIndex = 101;
            this.picbx_TimerSRate_dot.TabStop = false;
            // 
            // picbx_TimerFreq_dot
            // 
            this.picbx_TimerFreq_dot.BackColor = System.Drawing.Color.Transparent;
            this.picbx_TimerFreq_dot.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.SML_dot;
            this.picbx_TimerFreq_dot.Location = new System.Drawing.Point(634, 16);
            this.picbx_TimerFreq_dot.Name = "picbx_TimerFreq_dot";
            this.picbx_TimerFreq_dot.Size = new System.Drawing.Size(6, 15);
            this.picbx_TimerFreq_dot.TabIndex = 100;
            this.picbx_TimerFreq_dot.TabStop = false;
            this.picbx_TimerFreq_dot.Visible = false;
            // 
            // picbx_TimerOn_Once
            // 
            this.picbx_TimerOn_Once.BackColor = System.Drawing.Color.Transparent;
            this.picbx_TimerOn_Once.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.Timer_once;
            this.picbx_TimerOn_Once.Location = new System.Drawing.Point(25, 16);
            this.picbx_TimerOn_Once.Name = "picbx_TimerOn_Once";
            this.picbx_TimerOn_Once.Size = new System.Drawing.Size(81, 14);
            this.picbx_TimerOn_Once.TabIndex = 100;
            this.picbx_TimerOn_Once.TabStop = false;
            this.picbx_TimerOn_Once.Visible = false;
            // 
            // picbx_Timer_Band
            // 
            this.picbx_Timer_Band.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Band.Location = new System.Drawing.Point(568, 16);
            this.picbx_Timer_Band.Name = "picbx_Timer_Band";
            this.picbx_Timer_Band.Size = new System.Drawing.Size(23, 15);
            this.picbx_Timer_Band.TabIndex = 102;
            this.picbx_Timer_Band.TabStop = false;
            // 
            // picbx_Timer_FMFreqUnit
            // 
            this.picbx_Timer_FMFreqUnit.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_FMFreqUnit.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.Timer_MHZ;
            this.picbx_Timer_FMFreqUnit.Location = new System.Drawing.Point(658, 22);
            this.picbx_Timer_FMFreqUnit.Name = "picbx_Timer_FMFreqUnit";
            this.picbx_Timer_FMFreqUnit.Size = new System.Drawing.Size(22, 9);
            this.picbx_Timer_FMFreqUnit.TabIndex = 102;
            this.picbx_Timer_FMFreqUnit.TabStop = false;
            this.picbx_Timer_FMFreqUnit.Visible = false;
            // 
            // picbx_Timer_Freq_1
            // 
            this.picbx_Timer_Freq_1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Freq_1.Location = new System.Drawing.Point(645, 16);
            this.picbx_Timer_Freq_1.Name = "picbx_Timer_Freq_1";
            this.picbx_Timer_Freq_1.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Freq_1.TabIndex = 123;
            this.picbx_Timer_Freq_1.TabStop = false;
            // 
            // picbx_Timer_AMFreqUnit
            // 
            this.picbx_Timer_AMFreqUnit.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_AMFreqUnit.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.Timer_KHZ;
            this.picbx_Timer_AMFreqUnit.Location = new System.Drawing.Point(658, 22);
            this.picbx_Timer_AMFreqUnit.Name = "picbx_Timer_AMFreqUnit";
            this.picbx_Timer_AMFreqUnit.Size = new System.Drawing.Size(22, 9);
            this.picbx_Timer_AMFreqUnit.TabIndex = 101;
            this.picbx_Timer_AMFreqUnit.TabStop = false;
            this.picbx_Timer_AMFreqUnit.Visible = false;
            // 
            // picbx_Timer_Freq_10
            // 
            this.picbx_Timer_Freq_10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Freq_10.Location = new System.Drawing.Point(627, 16);
            this.picbx_Timer_Freq_10.Name = "picbx_Timer_Freq_10";
            this.picbx_Timer_Freq_10.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Freq_10.TabIndex = 122;
            this.picbx_Timer_Freq_10.TabStop = false;
            // 
            // picbx_Timer_OFFTime_M1
            // 
            this.picbx_Timer_OFFTime_M1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_OFFTime_M1.Location = new System.Drawing.Point(519, 16);
            this.picbx_Timer_OFFTime_M1.Name = "picbx_Timer_OFFTime_M1";
            this.picbx_Timer_OFFTime_M1.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_OFFTime_M1.TabIndex = 114;
            this.picbx_Timer_OFFTime_M1.TabStop = false;
            // 
            // picbx_Timer_Freq_100
            // 
            this.picbx_Timer_Freq_100.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Freq_100.Location = new System.Drawing.Point(609, 16);
            this.picbx_Timer_Freq_100.Name = "picbx_Timer_Freq_100";
            this.picbx_Timer_Freq_100.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Freq_100.TabIndex = 121;
            this.picbx_Timer_Freq_100.TabStop = false;
            // 
            // picbx_Timer_OFFTime_M10
            // 
            this.picbx_Timer_OFFTime_M10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_OFFTime_M10.Location = new System.Drawing.Point(506, 16);
            this.picbx_Timer_OFFTime_M10.Name = "picbx_Timer_OFFTime_M10";
            this.picbx_Timer_OFFTime_M10.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_OFFTime_M10.TabIndex = 113;
            this.picbx_Timer_OFFTime_M10.TabStop = false;
            // 
            // picbx_Timer_Freq_1000
            // 
            this.picbx_Timer_Freq_1000.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Freq_1000.Location = new System.Drawing.Point(591, 16);
            this.picbx_Timer_Freq_1000.Name = "picbx_Timer_Freq_1000";
            this.picbx_Timer_Freq_1000.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Freq_1000.TabIndex = 120;
            this.picbx_Timer_Freq_1000.TabStop = false;
            // 
            // btn_TimerSet
            // 
            this.btn_TimerSet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_TimerSet.Location = new System.Drawing.Point(840, 16);
            this.btn_TimerSet.Name = "btn_TimerSet";
            this.btn_TimerSet.Size = new System.Drawing.Size(94, 14);
            this.btn_TimerSet.TabIndex = 0;
            this.btn_TimerSet.UseVisualStyleBackColor = true;
            this.btn_TimerSet.MouseLeave += new System.EventHandler(this.btn_TimerSet_MouseLeave);
            this.btn_TimerSet.Click += new System.EventHandler(this.my_TimerSetClick);
            this.btn_TimerSet.MouseEnter += new System.EventHandler(this.btn_TimerSet_MouseEnter);
            // 
            // picbx_Timer_OFFTime_H1
            // 
            this.picbx_Timer_OFFTime_H1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_OFFTime_H1.Location = new System.Drawing.Point(486, 16);
            this.picbx_Timer_OFFTime_H1.Name = "picbx_Timer_OFFTime_H1";
            this.picbx_Timer_OFFTime_H1.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_OFFTime_H1.TabIndex = 112;
            this.picbx_Timer_OFFTime_H1.TabStop = false;
            // 
            // picbx_SRate_1
            // 
            this.picbx_SRate_1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_SRate_1.Location = new System.Drawing.Point(779, 16);
            this.picbx_SRate_1.Name = "picbx_SRate_1";
            this.picbx_SRate_1.Size = new System.Drawing.Size(12, 15);
            this.picbx_SRate_1.TabIndex = 119;
            this.picbx_SRate_1.TabStop = false;
            // 
            // picbx_SRate_10
            // 
            this.picbx_SRate_10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_SRate_10.Location = new System.Drawing.Point(766, 16);
            this.picbx_SRate_10.Name = "picbx_SRate_10";
            this.picbx_SRate_10.Size = new System.Drawing.Size(12, 15);
            this.picbx_SRate_10.TabIndex = 118;
            this.picbx_SRate_10.TabStop = false;
            // 
            // picbx_SRate_100
            // 
            this.picbx_SRate_100.BackColor = System.Drawing.Color.Transparent;
            this.picbx_SRate_100.Location = new System.Drawing.Point(753, 16);
            this.picbx_SRate_100.Name = "picbx_SRate_100";
            this.picbx_SRate_100.Size = new System.Drawing.Size(12, 15);
            this.picbx_SRate_100.TabIndex = 117;
            this.picbx_SRate_100.TabStop = false;
            // 
            // picbx_Timer_OFFTime_H10
            // 
            this.picbx_Timer_OFFTime_H10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_OFFTime_H10.Location = new System.Drawing.Point(473, 16);
            this.picbx_Timer_OFFTime_H10.Name = "picbx_Timer_OFFTime_H10";
            this.picbx_Timer_OFFTime_H10.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_OFFTime_H10.TabIndex = 111;
            this.picbx_Timer_OFFTime_H10.TabStop = false;
            // 
            // picbx_SRate_1000
            // 
            this.picbx_SRate_1000.BackColor = System.Drawing.Color.Transparent;
            this.picbx_SRate_1000.Location = new System.Drawing.Point(735, 16);
            this.picbx_SRate_1000.Name = "picbx_SRate_1000";
            this.picbx_SRate_1000.Size = new System.Drawing.Size(12, 15);
            this.picbx_SRate_1000.TabIndex = 116;
            this.picbx_SRate_1000.TabStop = false;
            // 
            // picbx_SRate_10000
            // 
            this.picbx_SRate_10000.BackColor = System.Drawing.Color.Transparent;
            this.picbx_SRate_10000.Location = new System.Drawing.Point(723, 16);
            this.picbx_SRate_10000.Name = "picbx_SRate_10000";
            this.picbx_SRate_10000.Size = new System.Drawing.Size(12, 15);
            this.picbx_SRate_10000.TabIndex = 115;
            this.picbx_SRate_10000.TabStop = false;
            // 
            // picbx_Timer_Date_Y1000
            // 
            this.picbx_Timer_Date_Y1000.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Date_Y1000.Location = new System.Drawing.Point(185, 16);
            this.picbx_Timer_Date_Y1000.Name = "picbx_Timer_Date_Y1000";
            this.picbx_Timer_Date_Y1000.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Date_Y1000.TabIndex = 99;
            this.picbx_Timer_Date_Y1000.TabStop = false;
            // 
            // picbx_Timer_ONTime_M1
            // 
            this.picbx_Timer_ONTime_M1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_ONTime_M1.Location = new System.Drawing.Point(407, 16);
            this.picbx_Timer_ONTime_M1.Name = "picbx_Timer_ONTime_M1";
            this.picbx_Timer_ONTime_M1.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_ONTime_M1.TabIndex = 110;
            this.picbx_Timer_ONTime_M1.TabStop = false;
            // 
            // picbx_Timer_ONTime_M10
            // 
            this.picbx_Timer_ONTime_M10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_ONTime_M10.Location = new System.Drawing.Point(394, 16);
            this.picbx_Timer_ONTime_M10.Name = "picbx_Timer_ONTime_M10";
            this.picbx_Timer_ONTime_M10.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_ONTime_M10.TabIndex = 109;
            this.picbx_Timer_ONTime_M10.TabStop = false;
            // 
            // picbx_Timer_Date_Y100
            // 
            this.picbx_Timer_Date_Y100.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Date_Y100.Location = new System.Drawing.Point(198, 16);
            this.picbx_Timer_Date_Y100.Name = "picbx_Timer_Date_Y100";
            this.picbx_Timer_Date_Y100.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Date_Y100.TabIndex = 100;
            this.picbx_Timer_Date_Y100.TabStop = false;
            // 
            // picbx_Timer_ONTime_H1
            // 
            this.picbx_Timer_ONTime_H1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_ONTime_H1.Location = new System.Drawing.Point(374, 16);
            this.picbx_Timer_ONTime_H1.Name = "picbx_Timer_ONTime_H1";
            this.picbx_Timer_ONTime_H1.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_ONTime_H1.TabIndex = 108;
            this.picbx_Timer_ONTime_H1.TabStop = false;
            // 
            // picbx_Timer_Date_Y10
            // 
            this.picbx_Timer_Date_Y10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Date_Y10.Location = new System.Drawing.Point(211, 16);
            this.picbx_Timer_Date_Y10.Name = "picbx_Timer_Date_Y10";
            this.picbx_Timer_Date_Y10.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Date_Y10.TabIndex = 101;
            this.picbx_Timer_Date_Y10.TabStop = false;
            // 
            // picbx_Timer_ONTime_H10
            // 
            this.picbx_Timer_ONTime_H10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_ONTime_H10.Location = new System.Drawing.Point(361, 16);
            this.picbx_Timer_ONTime_H10.Name = "picbx_Timer_ONTime_H10";
            this.picbx_Timer_ONTime_H10.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_ONTime_H10.TabIndex = 107;
            this.picbx_Timer_ONTime_H10.TabStop = false;
            // 
            // picbx_Timer_Date_Y1
            // 
            this.picbx_Timer_Date_Y1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Date_Y1.Location = new System.Drawing.Point(224, 16);
            this.picbx_Timer_Date_Y1.Name = "picbx_Timer_Date_Y1";
            this.picbx_Timer_Date_Y1.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Date_Y1.TabIndex = 102;
            this.picbx_Timer_Date_Y1.TabStop = false;
            // 
            // picbx_Timer_Date_D1
            // 
            this.picbx_Timer_Date_D1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Date_D1.Location = new System.Drawing.Point(302, 16);
            this.picbx_Timer_Date_D1.Name = "picbx_Timer_Date_D1";
            this.picbx_Timer_Date_D1.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Date_D1.TabIndex = 106;
            this.picbx_Timer_Date_D1.TabStop = false;
            // 
            // picbx_Timer_Date_M10
            // 
            this.picbx_Timer_Date_M10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Date_M10.Location = new System.Drawing.Point(250, 16);
            this.picbx_Timer_Date_M10.Name = "picbx_Timer_Date_M10";
            this.picbx_Timer_Date_M10.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Date_M10.TabIndex = 103;
            this.picbx_Timer_Date_M10.TabStop = false;
            // 
            // picbx_Timer_Date_D10
            // 
            this.picbx_Timer_Date_D10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Date_D10.Location = new System.Drawing.Point(289, 16);
            this.picbx_Timer_Date_D10.Name = "picbx_Timer_Date_D10";
            this.picbx_Timer_Date_D10.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Date_D10.TabIndex = 105;
            this.picbx_Timer_Date_D10.TabStop = false;
            // 
            // picbx_Timer_Date_M1
            // 
            this.picbx_Timer_Date_M1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Timer_Date_M1.Location = new System.Drawing.Point(263, 16);
            this.picbx_Timer_Date_M1.Name = "picbx_Timer_Date_M1";
            this.picbx_Timer_Date_M1.Size = new System.Drawing.Size(12, 15);
            this.picbx_Timer_Date_M1.TabIndex = 104;
            this.picbx_Timer_Date_M1.TabStop = false;
            // 
            // pnl_RadioMain
            // 
            this.pnl_RadioMain.BackColor = System.Drawing.SystemColors.Control;
            this.pnl_RadioMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl_RadioMain.BackgroundImage")));
            this.pnl_RadioMain.Controls.Add(this.picbx_Band_FM);
            this.pnl_RadioMain.Controls.Add(this.picbx_FM_scale);
            this.pnl_RadioMain.Controls.Add(this.picbx_VolumeLevel6);
            this.pnl_RadioMain.Controls.Add(this.picbx_AM_scale);
            this.pnl_RadioMain.Controls.Add(this.picbx_VolumeLevel5);
            this.pnl_RadioMain.Controls.Add(this.picbx_Stereo);
            this.pnl_RadioMain.Controls.Add(this.picbx_VolumeLevel4);
            this.pnl_RadioMain.Controls.Add(this.picbx_Tuned);
            this.pnl_RadioMain.Controls.Add(this.picbx_VolumeLevel3);
            this.pnl_RadioMain.Controls.Add(this.picbx_Freq_dot);
            this.pnl_RadioMain.Controls.Add(this.picbx_VolumeLevel2);
            this.pnl_RadioMain.Controls.Add(this.picbx_Bandwidth);
            this.pnl_RadioMain.Controls.Add(this.picbx_ScanProcess);
            this.pnl_RadioMain.Controls.Add(this.picbx_Band_AM);
            this.pnl_RadioMain.Controls.Add(this.picbx_VolumeLevel1);
            this.pnl_RadioMain.Controls.Add(this.picbx_FMFreqUnit);
            this.pnl_RadioMain.Controls.Add(this.btn_ScanCancel);
            this.pnl_RadioMain.Controls.Add(this.picbx_AMFreqUnit);
            this.pnl_RadioMain.Controls.Add(this.picbx_Mute);
            this.pnl_RadioMain.Controls.Add(this.picbx_rssi_scale_1);
            this.pnl_RadioMain.Controls.Add(this.picbx_snr_scale_2);
            this.pnl_RadioMain.Controls.Add(this.picbx_rssi_scale_2);
            this.pnl_RadioMain.Controls.Add(this.picbx_snr_scale_1);
            this.pnl_RadioMain.Controls.Add(this.picbx_Vol_1);
            this.pnl_RadioMain.Controls.Add(this.picbx_Vol_10);
            this.pnl_RadioMain.Controls.Add(this.picbx_FMFreq_P1);
            this.pnl_RadioMain.Controls.Add(this.picbx_FMFreq_1);
            this.pnl_RadioMain.Controls.Add(this.picbx_AMFreq_1);
            this.pnl_RadioMain.Controls.Add(this.picbx_FMFreq_10);
            this.pnl_RadioMain.Controls.Add(this.chkbx_Mute);
            this.pnl_RadioMain.Controls.Add(this.picbx_FMFreq_100);
            this.pnl_RadioMain.Controls.Add(this.picbx_AMFreq_10);
            this.pnl_RadioMain.Controls.Add(this.btn_FreqUp);
            this.pnl_RadioMain.Controls.Add(this.picbx_AMFreq_100);
            this.pnl_RadioMain.Controls.Add(this.picbx_AMFreq_1000);
            this.pnl_RadioMain.Controls.Add(this.btn_FreqDown);
            this.pnl_RadioMain.Controls.Add(this.btn_Bandwidth_Up);
            this.pnl_RadioMain.Controls.Add(this.picbx_ScanWave);
            this.pnl_RadioMain.Controls.Add(this.btn_Bandwidth_Down);
            this.pnl_RadioMain.Controls.Add(this.trkbar_Volume);
            this.pnl_RadioMain.Controls.Add(this.btn_Band);
            this.pnl_RadioMain.Controls.Add(this.btn_Scan);
            this.pnl_RadioMain.Controls.Add(this.SeekDown_btn);
            this.pnl_RadioMain.Controls.Add(this.SeekUp_btn);
            this.pnl_RadioMain.Location = new System.Drawing.Point(0, 24);
            this.pnl_RadioMain.Name = "pnl_RadioMain";
            this.pnl_RadioMain.Size = new System.Drawing.Size(1024, 407);
            this.pnl_RadioMain.TabIndex = 8;
            // 
            // picbx_Band_FM
            // 
            this.picbx_Band_FM.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Band_FM.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.Band_FM;
            this.picbx_Band_FM.Location = new System.Drawing.Point(25, 340);
            this.picbx_Band_FM.Name = "picbx_Band_FM";
            this.picbx_Band_FM.Size = new System.Drawing.Size(154, 10);
            this.picbx_Band_FM.TabIndex = 105;
            this.picbx_Band_FM.TabStop = false;
            this.picbx_Band_FM.Visible = false;
            // 
            // picbx_FM_scale
            // 
            this.picbx_FM_scale.BackColor = System.Drawing.Color.Transparent;
            this.picbx_FM_scale.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.FM_Scale;
            this.picbx_FM_scale.Location = new System.Drawing.Point(26, 16);
            this.picbx_FM_scale.Name = "picbx_FM_scale";
            this.picbx_FM_scale.Size = new System.Drawing.Size(974, 5);
            this.picbx_FM_scale.TabIndex = 101;
            this.picbx_FM_scale.TabStop = false;
            this.picbx_FM_scale.Visible = false;
            // 
            // picbx_VolumeLevel6
            // 
            this.picbx_VolumeLevel6.BackColor = System.Drawing.Color.Transparent;
            this.picbx_VolumeLevel6.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.VOL6;
            this.picbx_VolumeLevel6.Location = new System.Drawing.Point(955, 357);
            this.picbx_VolumeLevel6.Name = "picbx_VolumeLevel6";
            this.picbx_VolumeLevel6.Size = new System.Drawing.Size(16, 12);
            this.picbx_VolumeLevel6.TabIndex = 104;
            this.picbx_VolumeLevel6.TabStop = false;
            this.picbx_VolumeLevel6.Visible = false;
            // 
            // picbx_AM_scale
            // 
            this.picbx_AM_scale.BackColor = System.Drawing.Color.Transparent;
            this.picbx_AM_scale.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbx_AM_scale.BackgroundImage")));
            this.picbx_AM_scale.Location = new System.Drawing.Point(22, 16);
            this.picbx_AM_scale.Name = "picbx_AM_scale";
            this.picbx_AM_scale.Size = new System.Drawing.Size(983, 5);
            this.picbx_AM_scale.TabIndex = 100;
            this.picbx_AM_scale.TabStop = false;
            this.picbx_AM_scale.Visible = false;
            // 
            // picbx_VolumeLevel5
            // 
            this.picbx_VolumeLevel5.BackColor = System.Drawing.Color.Transparent;
            this.picbx_VolumeLevel5.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.VOL5;
            this.picbx_VolumeLevel5.Location = new System.Drawing.Point(937, 357);
            this.picbx_VolumeLevel5.Name = "picbx_VolumeLevel5";
            this.picbx_VolumeLevel5.Size = new System.Drawing.Size(16, 12);
            this.picbx_VolumeLevel5.TabIndex = 103;
            this.picbx_VolumeLevel5.TabStop = false;
            this.picbx_VolumeLevel5.Visible = false;
            // 
            // picbx_Stereo
            // 
            this.picbx_Stereo.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Stereo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbx_Stereo.BackgroundImage")));
            this.picbx_Stereo.Location = new System.Drawing.Point(490, 337);
            this.picbx_Stereo.Name = "picbx_Stereo";
            this.picbx_Stereo.Size = new System.Drawing.Size(106, 18);
            this.picbx_Stereo.TabIndex = 32;
            this.picbx_Stereo.TabStop = false;
            this.picbx_Stereo.Visible = false;
            // 
            // picbx_VolumeLevel4
            // 
            this.picbx_VolumeLevel4.BackColor = System.Drawing.Color.Transparent;
            this.picbx_VolumeLevel4.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.VOL4;
            this.picbx_VolumeLevel4.Location = new System.Drawing.Point(919, 357);
            this.picbx_VolumeLevel4.Name = "picbx_VolumeLevel4";
            this.picbx_VolumeLevel4.Size = new System.Drawing.Size(16, 12);
            this.picbx_VolumeLevel4.TabIndex = 102;
            this.picbx_VolumeLevel4.TabStop = false;
            this.picbx_VolumeLevel4.Visible = false;
            // 
            // picbx_Tuned
            // 
            this.picbx_Tuned.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Tuned.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbx_Tuned.BackgroundImage")));
            this.picbx_Tuned.Location = new System.Drawing.Point(379, 337);
            this.picbx_Tuned.Name = "picbx_Tuned";
            this.picbx_Tuned.Size = new System.Drawing.Size(106, 18);
            this.picbx_Tuned.TabIndex = 100;
            this.picbx_Tuned.TabStop = false;
            this.picbx_Tuned.Visible = false;
            // 
            // picbx_VolumeLevel3
            // 
            this.picbx_VolumeLevel3.BackColor = System.Drawing.Color.Transparent;
            this.picbx_VolumeLevel3.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.VOL3;
            this.picbx_VolumeLevel3.Location = new System.Drawing.Point(901, 357);
            this.picbx_VolumeLevel3.Name = "picbx_VolumeLevel3";
            this.picbx_VolumeLevel3.Size = new System.Drawing.Size(16, 12);
            this.picbx_VolumeLevel3.TabIndex = 101;
            this.picbx_VolumeLevel3.TabStop = false;
            this.picbx_VolumeLevel3.Visible = false;
            // 
            // picbx_Freq_dot
            // 
            this.picbx_Freq_dot.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Freq_dot.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.BIG_dot;
            this.picbx_Freq_dot.Location = new System.Drawing.Point(285, 337);
            this.picbx_Freq_dot.Name = "picbx_Freq_dot";
            this.picbx_Freq_dot.Size = new System.Drawing.Size(11, 33);
            this.picbx_Freq_dot.TabIndex = 101;
            this.picbx_Freq_dot.TabStop = false;
            this.picbx_Freq_dot.Visible = false;
            // 
            // picbx_VolumeLevel2
            // 
            this.picbx_VolumeLevel2.BackColor = System.Drawing.Color.Transparent;
            this.picbx_VolumeLevel2.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.VOL2;
            this.picbx_VolumeLevel2.Location = new System.Drawing.Point(883, 357);
            this.picbx_VolumeLevel2.Name = "picbx_VolumeLevel2";
            this.picbx_VolumeLevel2.Size = new System.Drawing.Size(16, 12);
            this.picbx_VolumeLevel2.TabIndex = 100;
            this.picbx_VolumeLevel2.TabStop = false;
            this.picbx_VolumeLevel2.Visible = false;
            // 
            // picbx_Bandwidth
            // 
            this.picbx_Bandwidth.BackColor = System.Drawing.SystemColors.Control;
            this.picbx_Bandwidth.Location = new System.Drawing.Point(61, 286);
            this.picbx_Bandwidth.Name = "picbx_Bandwidth";
            this.picbx_Bandwidth.Size = new System.Drawing.Size(106, 18);
            this.picbx_Bandwidth.TabIndex = 99;
            this.picbx_Bandwidth.TabStop = false;
            // 
            // picbx_ScanProcess
            // 
            this.picbx_ScanProcess.BackColor = System.Drawing.Color.Transparent;
            this.picbx_ScanProcess.Location = new System.Drawing.Point(272, 289);
            this.picbx_ScanProcess.Name = "picbx_ScanProcess";
            this.picbx_ScanProcess.Size = new System.Drawing.Size(64, 12);
            this.picbx_ScanProcess.TabIndex = 103;
            this.picbx_ScanProcess.TabStop = false;
            this.picbx_ScanProcess.Visible = false;
            // 
            // picbx_Band_AM
            // 
            this.picbx_Band_AM.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Band_AM.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.Band_AM;
            this.picbx_Band_AM.Location = new System.Drawing.Point(25, 340);
            this.picbx_Band_AM.Name = "picbx_Band_AM";
            this.picbx_Band_AM.Size = new System.Drawing.Size(154, 10);
            this.picbx_Band_AM.TabIndex = 101;
            this.picbx_Band_AM.TabStop = false;
            this.picbx_Band_AM.Visible = false;
            // 
            // picbx_VolumeLevel1
            // 
            this.picbx_VolumeLevel1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_VolumeLevel1.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.VOL1;
            this.picbx_VolumeLevel1.Location = new System.Drawing.Point(865, 357);
            this.picbx_VolumeLevel1.Name = "picbx_VolumeLevel1";
            this.picbx_VolumeLevel1.Size = new System.Drawing.Size(16, 12);
            this.picbx_VolumeLevel1.TabIndex = 99;
            this.picbx_VolumeLevel1.TabStop = false;
            this.picbx_VolumeLevel1.Visible = false;
            // 
            // picbx_FMFreqUnit
            // 
            this.picbx_FMFreqUnit.BackColor = System.Drawing.Color.Transparent;
            this.picbx_FMFreqUnit.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.MHZ;
            this.picbx_FMFreqUnit.Location = new System.Drawing.Point(332, 352);
            this.picbx_FMFreqUnit.Name = "picbx_FMFreqUnit";
            this.picbx_FMFreqUnit.Size = new System.Drawing.Size(42, 18);
            this.picbx_FMFreqUnit.TabIndex = 100;
            this.picbx_FMFreqUnit.TabStop = false;
            this.picbx_FMFreqUnit.Visible = false;
            // 
            // btn_ScanCancel
            // 
            this.btn_ScanCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ScanCancel.Location = new System.Drawing.Point(207, 288);
            this.btn_ScanCancel.Name = "btn_ScanCancel";
            this.btn_ScanCancel.Size = new System.Drawing.Size(51, 14);
            this.btn_ScanCancel.TabIndex = 2;
            this.btn_ScanCancel.UseVisualStyleBackColor = true;
            this.btn_ScanCancel.Visible = false;
            this.btn_ScanCancel.MouseLeave += new System.EventHandler(this.btn_Scan_MouseLeave);
            this.btn_ScanCancel.Click += new System.EventHandler(this.btn_ScanCancel_Click);
            this.btn_ScanCancel.MouseEnter += new System.EventHandler(this.btn_Scan_MouseEnter);
            // 
            // picbx_AMFreqUnit
            // 
            this.picbx_AMFreqUnit.BackColor = System.Drawing.Color.Transparent;
            this.picbx_AMFreqUnit.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.KHZ;
            this.picbx_AMFreqUnit.Location = new System.Drawing.Point(332, 352);
            this.picbx_AMFreqUnit.Name = "picbx_AMFreqUnit";
            this.picbx_AMFreqUnit.Size = new System.Drawing.Size(42, 18);
            this.picbx_AMFreqUnit.TabIndex = 99;
            this.picbx_AMFreqUnit.TabStop = false;
            this.picbx_AMFreqUnit.Visible = false;
            // 
            // picbx_Mute
            // 
            this.picbx_Mute.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Mute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbx_Mute.BackgroundImage")));
            this.picbx_Mute.Location = new System.Drawing.Point(865, 335);
            this.picbx_Mute.Name = "picbx_Mute";
            this.picbx_Mute.Size = new System.Drawing.Size(106, 18);
            this.picbx_Mute.TabIndex = 32;
            this.picbx_Mute.TabStop = false;
            this.picbx_Mute.Visible = false;
            // 
            // picbx_rssi_scale_1
            // 
            this.picbx_rssi_scale_1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_rssi_scale_1.Location = new System.Drawing.Point(8, 146);
            this.picbx_rssi_scale_1.Name = "picbx_rssi_scale_1";
            this.picbx_rssi_scale_1.Size = new System.Drawing.Size(21, 7);
            this.picbx_rssi_scale_1.TabIndex = 100;
            this.picbx_rssi_scale_1.TabStop = false;
            // 
            // picbx_snr_scale_2
            // 
            this.picbx_snr_scale_2.BackColor = System.Drawing.Color.Transparent;
            this.picbx_snr_scale_2.Location = new System.Drawing.Point(995, 22);
            this.picbx_snr_scale_2.Name = "picbx_snr_scale_2";
            this.picbx_snr_scale_2.Size = new System.Drawing.Size(21, 7);
            this.picbx_snr_scale_2.TabIndex = 101;
            this.picbx_snr_scale_2.TabStop = false;
            // 
            // picbx_rssi_scale_2
            // 
            this.picbx_rssi_scale_2.BackColor = System.Drawing.Color.Transparent;
            this.picbx_rssi_scale_2.Location = new System.Drawing.Point(8, 22);
            this.picbx_rssi_scale_2.Name = "picbx_rssi_scale_2";
            this.picbx_rssi_scale_2.Size = new System.Drawing.Size(21, 7);
            this.picbx_rssi_scale_2.TabIndex = 99;
            this.picbx_rssi_scale_2.TabStop = false;
            // 
            // picbx_snr_scale_1
            // 
            this.picbx_snr_scale_1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_snr_scale_1.Location = new System.Drawing.Point(995, 146);
            this.picbx_snr_scale_1.Name = "picbx_snr_scale_1";
            this.picbx_snr_scale_1.Size = new System.Drawing.Size(21, 7);
            this.picbx_snr_scale_1.TabIndex = 102;
            this.picbx_snr_scale_1.TabStop = false;
            // 
            // picbx_Vol_1
            // 
            this.picbx_Vol_1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Vol_1.Location = new System.Drawing.Point(752, 344);
            this.picbx_Vol_1.Name = "picbx_Vol_1";
            this.picbx_Vol_1.Size = new System.Drawing.Size(20, 25);
            this.picbx_Vol_1.TabIndex = 99;
            this.picbx_Vol_1.TabStop = false;
            // 
            // picbx_Vol_10
            // 
            this.picbx_Vol_10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_Vol_10.Location = new System.Drawing.Point(728, 344);
            this.picbx_Vol_10.Name = "picbx_Vol_10";
            this.picbx_Vol_10.Size = new System.Drawing.Size(20, 25);
            this.picbx_Vol_10.TabIndex = 98;
            this.picbx_Vol_10.TabStop = false;
            // 
            // picbx_FMFreq_P1
            // 
            this.picbx_FMFreq_P1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_FMFreq_P1.Location = new System.Drawing.Point(296, 337);
            this.picbx_FMFreq_P1.Name = "picbx_FMFreq_P1";
            this.picbx_FMFreq_P1.Size = new System.Drawing.Size(25, 33);
            this.picbx_FMFreq_P1.TabIndex = 101;
            this.picbx_FMFreq_P1.TabStop = false;
            // 
            // picbx_FMFreq_1
            // 
            this.picbx_FMFreq_1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_FMFreq_1.Location = new System.Drawing.Point(260, 337);
            this.picbx_FMFreq_1.Name = "picbx_FMFreq_1";
            this.picbx_FMFreq_1.Size = new System.Drawing.Size(25, 33);
            this.picbx_FMFreq_1.TabIndex = 100;
            this.picbx_FMFreq_1.TabStop = false;
            // 
            // picbx_AMFreq_1
            // 
            this.picbx_AMFreq_1.BackColor = System.Drawing.Color.Transparent;
            this.picbx_AMFreq_1.Location = new System.Drawing.Point(296, 337);
            this.picbx_AMFreq_1.Name = "picbx_AMFreq_1";
            this.picbx_AMFreq_1.Size = new System.Drawing.Size(25, 33);
            this.picbx_AMFreq_1.TabIndex = 100;
            this.picbx_AMFreq_1.TabStop = false;
            // 
            // picbx_FMFreq_10
            // 
            this.picbx_FMFreq_10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_FMFreq_10.Location = new System.Drawing.Point(224, 337);
            this.picbx_FMFreq_10.Name = "picbx_FMFreq_10";
            this.picbx_FMFreq_10.Size = new System.Drawing.Size(25, 33);
            this.picbx_FMFreq_10.TabIndex = 99;
            this.picbx_FMFreq_10.TabStop = false;
            // 
            // chkbx_Mute
            // 
            this.chkbx_Mute.Appearance = System.Windows.Forms.Appearance.Button;
            this.chkbx_Mute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkbx_Mute.Location = new System.Drawing.Point(658, 379);
            this.chkbx_Mute.Name = "chkbx_Mute";
            this.chkbx_Mute.Size = new System.Drawing.Size(51, 14);
            this.chkbx_Mute.TabIndex = 8;
            this.chkbx_Mute.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkbx_Mute.UseVisualStyleBackColor = true;
            this.chkbx_Mute.MouseLeave += new System.EventHandler(this.chkbx_Mute_MouseLeave);
            this.chkbx_Mute.MouseEnter += new System.EventHandler(this.chkbx_Mute_MouseEnter);
            this.chkbx_Mute.CheckedChanged += new System.EventHandler(this.chkbx_Mute_CheckedChanged);
            // 
            // picbx_FMFreq_100
            // 
            this.picbx_FMFreq_100.BackColor = System.Drawing.Color.Transparent;
            this.picbx_FMFreq_100.Location = new System.Drawing.Point(188, 337);
            this.picbx_FMFreq_100.Name = "picbx_FMFreq_100";
            this.picbx_FMFreq_100.Size = new System.Drawing.Size(25, 33);
            this.picbx_FMFreq_100.TabIndex = 98;
            this.picbx_FMFreq_100.TabStop = false;
            // 
            // picbx_AMFreq_10
            // 
            this.picbx_AMFreq_10.BackColor = System.Drawing.Color.Transparent;
            this.picbx_AMFreq_10.Location = new System.Drawing.Point(260, 337);
            this.picbx_AMFreq_10.Name = "picbx_AMFreq_10";
            this.picbx_AMFreq_10.Size = new System.Drawing.Size(25, 33);
            this.picbx_AMFreq_10.TabIndex = 99;
            this.picbx_AMFreq_10.TabStop = false;
            // 
            // btn_FreqUp
            // 
            this.btn_FreqUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_FreqUp.Location = new System.Drawing.Point(262, 379);
            this.btn_FreqUp.Name = "btn_FreqUp";
            this.btn_FreqUp.Size = new System.Drawing.Size(51, 14);
            this.btn_FreqUp.TabIndex = 6;
            this.btn_FreqUp.Tag = "2";
            this.btn_FreqUp.UseVisualStyleBackColor = true;
            this.btn_FreqUp.MouseLeave += new System.EventHandler(this.btn_FreqChange_MouseLeave);
            this.btn_FreqUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btn_FreqChange_MouseDown);
            this.btn_FreqUp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_FreqChange_MouseUp);
            this.btn_FreqUp.MouseEnter += new System.EventHandler(this.btn_FreqChange_MouseEnter);
            // 
            // picbx_AMFreq_100
            // 
            this.picbx_AMFreq_100.BackColor = System.Drawing.Color.Transparent;
            this.picbx_AMFreq_100.Location = new System.Drawing.Point(224, 337);
            this.picbx_AMFreq_100.Name = "picbx_AMFreq_100";
            this.picbx_AMFreq_100.Size = new System.Drawing.Size(25, 33);
            this.picbx_AMFreq_100.TabIndex = 98;
            this.picbx_AMFreq_100.TabStop = false;
            // 
            // picbx_AMFreq_1000
            // 
            this.picbx_AMFreq_1000.BackColor = System.Drawing.Color.Transparent;
            this.picbx_AMFreq_1000.Location = new System.Drawing.Point(188, 337);
            this.picbx_AMFreq_1000.Name = "picbx_AMFreq_1000";
            this.picbx_AMFreq_1000.Size = new System.Drawing.Size(25, 33);
            this.picbx_AMFreq_1000.TabIndex = 97;
            this.picbx_AMFreq_1000.TabStop = false;
            // 
            // btn_FreqDown
            // 
            this.btn_FreqDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_FreqDown.Location = new System.Drawing.Point(199, 379);
            this.btn_FreqDown.Name = "btn_FreqDown";
            this.btn_FreqDown.Size = new System.Drawing.Size(51, 14);
            this.btn_FreqDown.TabIndex = 5;
            this.btn_FreqDown.Tag = "1";
            this.btn_FreqDown.UseVisualStyleBackColor = true;
            this.btn_FreqDown.MouseLeave += new System.EventHandler(this.btn_FreqChange_MouseLeave);
            this.btn_FreqDown.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btn_FreqChange_MouseDown);
            this.btn_FreqDown.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_FreqChange_MouseUp);
            this.btn_FreqDown.MouseEnter += new System.EventHandler(this.btn_FreqChange_MouseEnter);
            // 
            // btn_Bandwidth_Up
            // 
            this.btn_Bandwidth_Up.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.BAND_Right;
            this.btn_Bandwidth_Up.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Bandwidth_Up.Location = new System.Drawing.Point(169, 285);
            this.btn_Bandwidth_Up.Name = "btn_Bandwidth_Up";
            this.btn_Bandwidth_Up.Size = new System.Drawing.Size(19, 20);
            this.btn_Bandwidth_Up.TabIndex = 1;
            this.btn_Bandwidth_Up.UseVisualStyleBackColor = true;
            this.btn_Bandwidth_Up.Click += new System.EventHandler(this.btn_Bandwidth_Up_Click);
            // 
            // picbx_ScanWave
            // 
            this.picbx_ScanWave.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.picbx_ScanWave.BackColor = System.Drawing.Color.Transparent;
            this.picbx_ScanWave.Image = global::RadioWaveMonitor.Properties.Resources.BG_Wave;
            this.picbx_ScanWave.Location = new System.Drawing.Point(30, 22);
            this.picbx_ScanWave.Name = "picbx_ScanWave";
            this.picbx_ScanWave.Size = new System.Drawing.Size(964, 256);
            this.picbx_ScanWave.TabIndex = 78;
            this.picbx_ScanWave.TabStop = false;
            this.picbx_ScanWave.Paint += new System.Windows.Forms.PaintEventHandler(this.my_DrawGrid);
            // 
            // btn_Bandwidth_Down
            // 
            this.btn_Bandwidth_Down.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.BAND_Left;
            this.btn_Bandwidth_Down.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Bandwidth_Down.Location = new System.Drawing.Point(40, 285);
            this.btn_Bandwidth_Down.Name = "btn_Bandwidth_Down";
            this.btn_Bandwidth_Down.Size = new System.Drawing.Size(19, 20);
            this.btn_Bandwidth_Down.TabIndex = 0;
            this.btn_Bandwidth_Down.UseVisualStyleBackColor = true;
            this.btn_Bandwidth_Down.Click += new System.EventHandler(this.btn_Bandwidth_Down_Click);
            // 
            // trkbar_Volume
            // 
            this.trkbar_Volume.AutoSize = false;
            this.trkbar_Volume.BackColor = System.Drawing.SystemColors.Control;
            this.trkbar_Volume.Location = new System.Drawing.Point(738, 379);
            this.trkbar_Volume.Maximum = 63;
            this.trkbar_Volume.Name = "trkbar_Volume";
            this.trkbar_Volume.Size = new System.Drawing.Size(166, 18);
            this.trkbar_Volume.TabIndex = 9;
            this.trkbar_Volume.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trkbar_Volume.ValueChanged += new System.EventHandler(this.trkbar_Volume_ValueChanged);
            // 
            // btn_Band
            // 
            this.btn_Band.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Band.Location = new System.Drawing.Point(22, 379);
            this.btn_Band.Name = "btn_Band";
            this.btn_Band.Size = new System.Drawing.Size(94, 14);
            this.btn_Band.TabIndex = 3;
            this.btn_Band.UseVisualStyleBackColor = true;
            this.btn_Band.MouseLeave += new System.EventHandler(this.btn_Band_MouseLeave);
            this.btn_Band.Click += new System.EventHandler(this.btn_Band_Click);
            this.btn_Band.MouseEnter += new System.EventHandler(this.btn_Band_MouseEnter);
            // 
            // btn_Scan
            // 
            this.btn_Scan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Scan.Location = new System.Drawing.Point(207, 288);
            this.btn_Scan.Name = "btn_Scan";
            this.btn_Scan.Size = new System.Drawing.Size(51, 14);
            this.btn_Scan.TabIndex = 1;
            this.btn_Scan.UseVisualStyleBackColor = true;
            this.btn_Scan.MouseLeave += new System.EventHandler(this.btn_Scan_MouseLeave);
            this.btn_Scan.Click += new System.EventHandler(this.btn_Scan_Click);
            this.btn_Scan.EnabledChanged += new System.EventHandler(this.btn_Scan_EnabledChanged);
            this.btn_Scan.MouseEnter += new System.EventHandler(this.btn_Scan_MouseEnter);
            // 
            // SeekDown_btn
            // 
            this.SeekDown_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SeekDown_btn.Location = new System.Drawing.Point(136, 379);
            this.SeekDown_btn.Name = "SeekDown_btn";
            this.SeekDown_btn.Size = new System.Drawing.Size(51, 14);
            this.SeekDown_btn.TabIndex = 4;
            this.SeekDown_btn.UseVisualStyleBackColor = true;
            this.SeekDown_btn.MouseLeave += new System.EventHandler(this.btn_FreqChange_MouseLeave);
            this.SeekDown_btn.Click += new System.EventHandler(this.SeekDown_btn_Click);
            this.SeekDown_btn.MouseEnter += new System.EventHandler(this.btn_FreqChange_MouseEnter);
            // 
            // SeekUp_btn
            // 
            this.SeekUp_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SeekUp_btn.Location = new System.Drawing.Point(325, 379);
            this.SeekUp_btn.Name = "SeekUp_btn";
            this.SeekUp_btn.Size = new System.Drawing.Size(51, 14);
            this.SeekUp_btn.TabIndex = 7;
            this.SeekUp_btn.UseVisualStyleBackColor = true;
            this.SeekUp_btn.MouseLeave += new System.EventHandler(this.btn_FreqChange_MouseLeave);
            this.SeekUp_btn.Click += new System.EventHandler(this.SeekUp_btn_Click);
            this.SeekUp_btn.MouseEnter += new System.EventHandler(this.btn_FreqChange_MouseEnter);
            // 
            // picbx_TitleBar
            // 
            this.picbx_TitleBar.BackgroundImage = global::RadioWaveMonitor.Properties.Resources.BG1;
            this.picbx_TitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.picbx_TitleBar.Location = new System.Drawing.Point(0, 0);
            this.picbx_TitleBar.Name = "picbx_TitleBar";
            this.picbx_TitleBar.Size = new System.Drawing.Size(1024, 24);
            this.picbx_TitleBar.TabIndex = 80;
            this.picbx_TitleBar.TabStop = false;
            this.picbx_TitleBar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picbx_TitleBar_MouseMove);
            this.picbx_TitleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picbx_TitleBar_MouseDown);
            this.picbx_TitleBar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picbx_TitleBar_MouseUp);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1024, 483);
            this.Controls.Add(this.btn_Maximize);
            this.Controls.Add(this.lbl_TimerOff);
            this.Controls.Add(this.lbl_TimerOn);
            this.Controls.Add(this.lbl_debug);
            this.Controls.Add(this.SNR_lbl);
            this.Controls.Add(this.pnl_Timer);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pnl_RadioMain);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_Minimize);
            this.Controls.Add(this.picbx_TitleBar);
            this.Controls.Add(this.trkbar_Freq);
            this.Controls.Add(this.btn_TimerDaily);
            this.Controls.Add(this.Vol_lbl);
            this.Controls.Add(this.Level_lbl);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.VolumeSet_btn);
            this.Controls.Add(this.Freq_lbl);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.FMSet_btn);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AMSet_btn);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.connect_status_lbl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "RWAVE MONITOR Ver0.01 PID=F022";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Freq)).EndInit();
            this.pnl_Timer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerOn_Weekly)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerOn_Daily)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerSRate_dot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerFreq_dot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TimerOn_Once)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Band)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_FMFreqUnit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Freq_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_AMFreqUnit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Freq_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_OFFTime_M1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Freq_100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_OFFTime_M10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Freq_1000)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_OFFTime_H1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_OFFTime_H10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_1000)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_SRate_10000)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_Y1000)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_ONTime_M1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_ONTime_M10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_Y100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_ONTime_H1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_Y10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_ONTime_H10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_Y1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_D1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_M10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_D10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Timer_Date_M1)).EndInit();
            this.pnl_RadioMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Band_FM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FM_scale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AM_scale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Stereo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Tuned)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Freq_dot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Bandwidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_ScanProcess)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Band_AM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_VolumeLevel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreqUnit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreqUnit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Mute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_rssi_scale_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_snr_scale_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_rssi_scale_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_snr_scale_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Vol_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_Vol_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreq_P1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreq_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreq_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreq_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_FMFreq_100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreq_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreq_100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_AMFreq_1000)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_ScanWave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Volume)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_TitleBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.Label connect_status_lbl;
        private System.Windows.Forms.Label debug01_lbl;
        private System.Windows.Forms.Label debug02_lbl;
        private System.Windows.Forms.Label debug03_lbl;
        private System.Windows.Forms.Label colum_lbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button AMSet_btn;
        private System.Windows.Forms.Button FMSet_btn;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button VolumeSet_btn;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SeekUp_btn;
        private System.Windows.Forms.Button SeekDown_btn;
        private System.Windows.Forms.Label Freq_lbl;
        private System.Windows.Forms.Label Level_lbl;
        private System.Windows.Forms.PictureBox picbx_ScanWave;
        private System.Windows.Forms.Label Vol_lbl;
        private System.Windows.Forms.PictureBox picbx_TitleBar;
        private System.Windows.Forms.Button btn_Minimize;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.Button btn_Scan;
        private System.Windows.Forms.Button btn_Band;
        private System.Windows.Forms.Button btn_TimerSet;
        private System.Windows.Forms.Button btn_TimerDaily;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TrackBar trkbar_Volume;
        private System.Windows.Forms.TrackBar trkbar_Freq;
        private System.Windows.Forms.Panel pnl_RadioMain;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel pnl_Timer;
        private System.Windows.Forms.Button btn_Bandwidth_Up;
        private System.Windows.Forms.Button btn_Bandwidth_Down;
        private System.Windows.Forms.Label SNR_lbl;
        private System.Windows.Forms.Timer WaveScanTimer;
        private System.Windows.Forms.Label lbl_debug;
        private System.Windows.Forms.Button btn_FreqUp;
        private System.Windows.Forms.Button btn_FreqDown;
        private System.Windows.Forms.Timer FreqChangeTimer;
        private System.Windows.Forms.CheckBox chkbx_Mute;
        private System.Windows.Forms.PictureBox picbx_AMFreq_1;
        private System.Windows.Forms.PictureBox picbx_AMFreq_10;
        private System.Windows.Forms.PictureBox picbx_AMFreq_100;
        private System.Windows.Forms.PictureBox picbx_AMFreq_1000;
        private System.Windows.Forms.PictureBox picbx_FMFreq_100;
        private System.Windows.Forms.PictureBox picbx_FMFreq_10;
        private System.Windows.Forms.PictureBox picbx_FMFreq_1;
        private System.Windows.Forms.PictureBox picbx_FMFreq_P1;
        private System.Windows.Forms.PictureBox picbx_Vol_1;
        private System.Windows.Forms.PictureBox picbx_Vol_10;
        private System.Windows.Forms.PictureBox picbx_Timer_Date_Y1000;
        private System.Windows.Forms.PictureBox picbx_Timer_Date_Y100;
        private System.Windows.Forms.PictureBox picbx_Timer_Date_Y10;
        private System.Windows.Forms.PictureBox picbx_Timer_Date_Y1;
        private System.Windows.Forms.PictureBox picbx_Timer_Date_M10;
        private System.Windows.Forms.PictureBox picbx_Timer_Date_M1;
        private System.Windows.Forms.PictureBox picbx_Timer_Date_D10;
        private System.Windows.Forms.PictureBox picbx_Timer_Date_D1;
        private System.Windows.Forms.PictureBox picbx_Timer_ONTime_H10;
        private System.Windows.Forms.PictureBox picbx_Timer_ONTime_H1;
        private System.Windows.Forms.PictureBox picbx_Timer_ONTime_M10;
        private System.Windows.Forms.PictureBox picbx_Timer_ONTime_M1;
        private System.Windows.Forms.PictureBox picbx_Timer_OFFTime_H10;
        private System.Windows.Forms.PictureBox picbx_Timer_OFFTime_H1;
        private System.Windows.Forms.PictureBox picbx_Timer_OFFTime_M10;
        private System.Windows.Forms.PictureBox picbx_Timer_OFFTime_M1;
        private System.Windows.Forms.PictureBox picbx_SRate_10000;
        private System.Windows.Forms.PictureBox picbx_SRate_1000;
        private System.Windows.Forms.PictureBox picbx_SRate_100;
        private System.Windows.Forms.PictureBox picbx_SRate_10;
        private System.Windows.Forms.PictureBox picbx_SRate_1;
        private System.Windows.Forms.PictureBox picbx_Timer_Freq_1000;
        private System.Windows.Forms.PictureBox picbx_Timer_Freq_100;
        private System.Windows.Forms.PictureBox picbx_Timer_Freq_10;
        private System.Windows.Forms.PictureBox picbx_Timer_Freq_1;
        private System.Windows.Forms.ImageList imglist_Number_M;
        private System.Windows.Forms.Label lbl_TimerOn;
        private System.Windows.Forms.Label lbl_TimerOff;
        private System.Windows.Forms.Timer RecordingTimer;
        private System.Windows.Forms.PictureBox picbx_rssi_scale_1;
        private System.Windows.Forms.PictureBox picbx_snr_scale_2;
        private System.Windows.Forms.PictureBox picbx_rssi_scale_2;
        private System.Windows.Forms.PictureBox picbx_snr_scale_1;
        private System.ComponentModel.BackgroundWorker bgw_CaptureBufferWrite;
        private System.Windows.Forms.Button btn_ScanCancel;
        private System.Windows.Forms.ImageList imglist_Number_S;
        private System.Windows.Forms.ImageList imglist_RSSI_scale;
        private System.Windows.Forms.PictureBox picbx_VolumeLevel1;
        private System.Windows.Forms.PictureBox picbx_AMFreqUnit;
        private System.Windows.Forms.PictureBox picbx_Mute;
        private System.Windows.Forms.PictureBox picbx_Stereo;
        private System.Windows.Forms.PictureBox picbx_FMFreqUnit;
        private System.Windows.Forms.PictureBox picbx_Band_AM;
        private System.Windows.Forms.PictureBox picbx_Timer_Band;
        private System.Windows.Forms.PictureBox picbx_Timer_FMFreqUnit;
        private System.Windows.Forms.PictureBox picbx_Timer_AMFreqUnit;
        private System.Windows.Forms.PictureBox picbx_Bandwidth;
        private System.Windows.Forms.PictureBox picbx_ScanProcess;
        private System.Windows.Forms.ImageList imglist_Band_Wide;
        private System.Windows.Forms.Button btn_Maximize;
        private System.Windows.Forms.ImageList imglist_Controlbox;
        private System.Windows.Forms.ImageList imglist_ScanProcess;
        private System.Windows.Forms.ImageList imglist_ScanBtn;
        private System.Windows.Forms.ImageList imglist_Number_L;
        private System.Windows.Forms.ImageList imglist_BandBtn;
        private System.Windows.Forms.PictureBox picbx_Tuned;
        private System.Windows.Forms.PictureBox picbx_Freq_dot;
        private System.Windows.Forms.ImageList imglist_FreqChangeBtn;
        private System.Windows.Forms.ImageList imglist_MuteBtn;
        private System.Windows.Forms.PictureBox picbx_VolumeLevel2;
        private System.Windows.Forms.PictureBox picbx_VolumeLevel3;
        private System.Windows.Forms.PictureBox picbx_VolumeLevel4;
        private System.Windows.Forms.PictureBox picbx_VolumeLevel5;
        private System.Windows.Forms.PictureBox picbx_VolumeLevel6;
        private System.Windows.Forms.PictureBox picbx_TimerOn_Once;
        private System.Windows.Forms.ImageList imglist_TimerBand;
        private System.Windows.Forms.PictureBox picbx_TimerFreq_dot;
        private System.Windows.Forms.PictureBox picbx_TimerSRate_dot;
        private System.Windows.Forms.ImageList imglist_TimerSet_btn;
        private System.Windows.Forms.ImageList imglist_SNR_scale;
        private System.Windows.Forms.PictureBox picbx_AM_scale;
        private System.Windows.Forms.PictureBox picbx_FM_scale;
        private System.Windows.Forms.PictureBox picbx_TimerOn_Daily;
        private System.Windows.Forms.PictureBox picbx_TimerOn_Weekly;
        private System.Windows.Forms.PictureBox picbx_Band_FM;
    }
}

