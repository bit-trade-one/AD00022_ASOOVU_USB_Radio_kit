﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RadioWaveMonitor
{
    public partial class FormTimerSet : Form
    {
        // カスタムフォーマット {ONCE,EVERY DAY,DAY OF WEEK}
        readonly string[] TIMER_ONOFF_CUSTOM_FORMAT = new string[] { "HH:mm dddd MMMM dd, yyyy", "HH:mm", "HH:mm" };

        RadioWaveMonitor.TimerInfo t_info = new TimerInfo();
        //RadioCT.TimerInfo t_info;
        RadioWaveMonitor.TimerInfo t_info_org;
        CheckBox[] day_of_week;
        RadioButton[] band;
        NumericUpDown[] freq;
        RadioButton[] Repeat_Type;

        bool form_close_error_flag = false;

        struct st_SAMPLING_FREQ
        {
            internal string disp_str;
            internal int sampling_freq;

            public st_SAMPLING_FREQ(string disp, int freq)
            {
                this.disp_str = disp;
                this.sampling_freq = freq;
            }
        }
        st_SAMPLING_FREQ[] sampling_freq = new st_SAMPLING_FREQ[6] { 
            new st_SAMPLING_FREQ(" 8.000kHz", RadioWaveMonitor.Form1.SAMPLING_FREQ_8kHz), 
            new st_SAMPLING_FREQ("11.025kHz", RadioWaveMonitor.Form1.SAMPLING_FREQ_11kHz), 
            new st_SAMPLING_FREQ("16.000kHz", RadioWaveMonitor.Form1.SAMPLING_FREQ_16kHz), 
            new st_SAMPLING_FREQ("22.050kHz", RadioWaveMonitor.Form1.SAMPLING_FREQ_22kHz), 
            new st_SAMPLING_FREQ("32.000kHz", RadioWaveMonitor.Form1.SAMPLING_FREQ_32kHz), 
            new st_SAMPLING_FREQ("44.100kHz", RadioWaveMonitor.Form1.SAMPLING_FREQ_44kHz) };

        //public FormTimerSet()
        //{
        //    InitializeComponent();
        //}
        public FormTimerSet( RadioWaveMonitor.TimerInfo ti )
        {
            InitializeComponent();

            t_info.Copy(ti);
            t_info_org = ti;

            day_of_week = new CheckBox[] { chkbx_Sunday, chkbx_Monday, chkbx_Tuesday, chkbx_Wednesday, chkbx_Thursday, chkbx_Friday, chkbx_Saturday };
            band = new RadioButton[] { rbtn_AM, rbtn_FM };
            freq = new NumericUpDown[] { nud_AMFreq, nud_FMFreq };
            Repeat_Type = new RadioButton[] { rbtn_Once, rbtn_Daily, rbtn_DayOfWeek };
        }

        private void FormTimerSet_Load(object sender, EventArgs e)
        {
            try
            {
                // Timer ON Time / OFF Time Set
                dtp_TimerOn.Value = t_info.set_timer_on_date;
                dtp_TimerOff.Value = t_info.set_timer_off_date;
                // Timer ON / OFF Set
                if (t_info.timer_set_flag == true)
                {
                    chkbx_TimerOn.Checked = true;
                    chkbx_TimerOff.Checked = false;
                }
                else
                {
                    chkbx_TimerOn.Checked = false;
                    chkbx_TimerOff.Checked = true;
                }
                // Repeat Type Set
                rbtn_Once.Tag = RadioWaveMonitor.Form1.REPEAT_TYPE_ONCE;
                rbtn_Daily.Tag = RadioWaveMonitor.Form1.REPEAT_TYPE_EVERY_DAY;
                rbtn_DayOfWeek.Tag = RadioWaveMonitor.Form1.REPEAT_TYPE_DAY_OF_WEEK;
                if ( t_info.repeat_type < 0 || Repeat_Type.Length <= t_info.repeat_type )
                {
                    t_info.repeat_type = RadioWaveMonitor.Form1.REPEAT_TYPE_ONCE;
                }
                Repeat_Type[t_info.repeat_type].Checked = true;
                dtp_TimerOn.CustomFormat = TIMER_ONOFF_CUSTOM_FORMAT[t_info.repeat_type];
                dtp_TimerOff.CustomFormat = TIMER_ONOFF_CUSTOM_FORMAT[t_info.repeat_type];
                // Day of Week Set
                for (int fi = 0; fi < day_of_week.Length; fi++)
                {
                    day_of_week[fi].Checked = t_info.day_of_week[fi];
                }
                // Band
                rbtn_AM.Tag = RadioWaveMonitor.Form1.BAND_AM;
                rbtn_FM.Tag = RadioWaveMonitor.Form1.BAND_FM;
                for (int fi = 0; fi < band.Length; fi++)
                {
                    band[fi].Tag = fi;
                }
                if (t_info.band < 0 || band.Length <= t_info.band)
                {
                    t_info.band = RadioWaveMonitor.Form1.BAND_FM;
                    t_info.frequency_am = RadioWaveMonitor.Form1.AM_FRQ_MIN_JP;
                    t_info.frequency_fm = RadioWaveMonitor.Form1.FM_FRQ_MIN_JP;
                }
                band[t_info.band].Checked = true;
                freq[t_info.band].Enabled = true;
                // Freq
                // AM
                nud_AMFreq.Minimum = RadioWaveMonitor.Form1.AM_FRQ_MIN;
                nud_AMFreq.Maximum = RadioWaveMonitor.Form1.AM_FRQ_MAX;
                if (t_info.frequency_am < RadioWaveMonitor.Form1.AM_FRQ_MIN)
                {
                    t_info.frequency_am = RadioWaveMonitor.Form1.AM_FRQ_MIN;
                }
                else if (RadioWaveMonitor.Form1.AM_FRQ_MAX < t_info.frequency_am)
                {
                    t_info.frequency_am = RadioWaveMonitor.Form1.AM_FRQ_MAX;
                }
                nud_AMFreq.Value = t_info.frequency_am;
                // FM
                nud_FMFreq.Minimum = RadioWaveMonitor.Form1.FM_FRQ_MIN / 100;
                nud_FMFreq.Maximum = RadioWaveMonitor.Form1.FM_FRQ_MAX / 100;
                if (t_info.frequency_fm < RadioWaveMonitor.Form1.FM_FRQ_MIN)
                {
                    t_info.frequency_fm = RadioWaveMonitor.Form1.FM_FRQ_MIN;
                }
                else if (RadioWaveMonitor.Form1.FM_FRQ_MAX < t_info.frequency_fm)
                {
                    t_info.frequency_fm = RadioWaveMonitor.Form1.FM_FRQ_MAX;
                }
                nud_FMFreq.Value = (decimal)t_info.frequency_fm / 100;
                // Sampling Freq
                int sel_idx = -1;
                for (int fi = 0; fi < sampling_freq.Length; fi++)
                {
                    //sampling_freq[fi]..;
                    cmbbx_SampleRate.Items.Add(sampling_freq[fi].disp_str);
                    if (sampling_freq[fi].sampling_freq == t_info.sampling_freq)
                    {
                        sel_idx = fi;
                    }
                }
                if (sel_idx == -1)
                {
                    sel_idx = 0;
                    t_info.sampling_freq = sampling_freq[0].sampling_freq;
                }
                cmbbx_SampleRate.SelectedIndex = sel_idx;
            }
            catch
            {
            }
        }

        private void rbtn_RepeatType_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                for (int fi = 0; fi < Repeat_Type.Length; fi++ )
                {
                    if (Repeat_Type[fi].Checked == true)
                    {
                        dtp_TimerOn.CustomFormat = TIMER_ONOFF_CUSTOM_FORMAT[fi];
                        dtp_TimerOff.CustomFormat = TIMER_ONOFF_CUSTOM_FORMAT[fi];
                    }
                }
                gbx_DayOfWeek.Enabled = rbtn_DayOfWeek.Checked;
            }
            catch
            {
            }
        }
        private void rbtn_Band_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (((RadioButton)sender).Checked == true)
                {
                    int idx = (int)(((RadioButton)sender).Tag);
                    for (int fi = 0; fi < band.Length; fi++)
                    {
                        if (fi == idx)
                        {
                            freq[fi].Enabled = true;
                        }
                        else
                        {
                            freq[fi].Enabled = false;
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_Set_Click(object sender, EventArgs e)
        {
            bool check_flag = false;
            try
            {
                form_close_error_flag = false;

                // check
                // Onceで設定時間がTimer ON > Timer OFFの場合
                if (rbtn_Once.Checked == true)
                {
                    TimeSpan ts = dtp_TimerOff.Value - dtp_TimerOn.Value;
                    if ( ts.TotalMinutes < 1)
                    {
                        form_close_error_flag = true;
                        MessageBox.Show("TIMER OFF日時がTIMER ON日時より前です", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (System.DateTime.Now.AddSeconds(30) > dtp_TimerOn.Value)
                    {
                        form_close_error_flag = true;
                        MessageBox.Show("予約設定可能時間を過ぎています", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                // Day of Weekで曜日の選択があるかチェック
                if (rbtn_DayOfWeek.Checked == true)
                {
                    check_flag = false;
                    for (int fi = 0; fi < day_of_week.Length; fi++)
                    {
                        if (day_of_week[fi].Checked == true)
                        {
                            check_flag = true;
                            break;
                        }
                    }
                    if (check_flag == false)
                    {
                        form_close_error_flag = true;
                        MessageBox.Show("曜日を選択してください", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                if (form_close_error_flag == false)
                {   // エラー無し

                    // Timer ON/OFF Set
                    if (chkbx_TimerOn.Checked == true)
                    {   // Timer ON
                        t_info.timer_set_flag = true;
                    }
                    else
                    {   // Timer OFF
                        t_info.timer_set_flag = false;
                    }
                    //Timer ON Time / OFF Timme Set
                    t_info.set_timer_on_date = dtp_TimerOn.Value;
                    t_info.set_timer_off_date = dtp_TimerOff.Value;

                    // Band / Freq Set
                    // Band
                    for (int fi = 0; fi < band.Length; fi++)
                    {
                        if (band[fi].Checked == true )
                        {
                            t_info.band = (int)band[fi].Tag;
                            t_info.frequency_am = (int)nud_AMFreq.Value;
                            t_info.frequency_fm = (int)(nud_FMFreq.Value * 100);
                        }
                    }
                    // Repeat Type
                    for (int fi = 0; fi < Repeat_Type.Length; fi++)
                    {
                        if (Repeat_Type[fi].Checked == true)
                        {
                            t_info.repeat_type = (int)Repeat_Type[fi].Tag;
                        }
                    }
                    for (int fi = 0; fi < t_info.day_of_week.Length; fi++ )
                    {
                        t_info.day_of_week[fi] = day_of_week[fi].Checked;
                    }
                    // Sampling rate
                    int sel_idx = cmbbx_SampleRate.SelectedIndex;
                    if (sel_idx < 0 || sampling_freq.Length <= sel_idx)
                    {
                        sel_idx = 0;
                    }
                    t_info.sampling_freq = sampling_freq[sel_idx].sampling_freq;

                    t_info_org.Copy(t_info);

                    this.DialogResult = DialogResult.OK;
                }
                else
                {   // エラー有り
                    
                }
            }
            catch
            {
            }
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            try
            {
            }
            catch
            {
            }
        }

        private void FormTimerSet_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
            }
            catch
            {
            }
        }

        private void chkbx_TimerOn_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (((CheckBox)sender).Checked == true)
                {
                    chkbx_TimerOff.Checked = !((CheckBox)sender).Checked;
                }
            }
            catch
            {
            }
        }

        private void chkbx_TimerOff_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (((CheckBox)sender).Checked == true)
                {
                    chkbx_TimerOn.Checked = !((CheckBox)sender).Checked;
                }
            }
            catch
            {
            }
        }

    }
}
