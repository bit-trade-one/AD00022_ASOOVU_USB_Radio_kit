﻿namespace RadioWaveMonitor
{
    partial class FormTimerSet
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTimerSet));
            this.rbtn_Once = new System.Windows.Forms.RadioButton();
            this.rbtn_Daily = new System.Windows.Forms.RadioButton();
            this.rbtn_DayOfWeek = new System.Windows.Forms.RadioButton();
            this.chkbx_Sunday = new System.Windows.Forms.CheckBox();
            this.chkbx_Monday = new System.Windows.Forms.CheckBox();
            this.chkbx_Tuesday = new System.Windows.Forms.CheckBox();
            this.chkbx_Wednesday = new System.Windows.Forms.CheckBox();
            this.chkbx_Thursday = new System.Windows.Forms.CheckBox();
            this.chkbx_Friday = new System.Windows.Forms.CheckBox();
            this.chkbx_Saturday = new System.Windows.Forms.CheckBox();
            this.gbx_DayOfWeek = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtp_TimerOff = new System.Windows.Forms.DateTimePicker();
            this.dtp_TimerOn = new System.Windows.Forms.DateTimePicker();
            this.gbx_Repeat = new System.Windows.Forms.GroupBox();
            this.rbtn_FM = new System.Windows.Forms.RadioButton();
            this.rbtn_AM = new System.Windows.Forms.RadioButton();
            this.nud_FMFreq = new System.Windows.Forms.NumericUpDown();
            this.nud_AMFreq = new System.Windows.Forms.NumericUpDown();
            this.cmbbx_SampleRate = new System.Windows.Forms.ComboBox();
            this.gbx_band = new System.Windows.Forms.GroupBox();
            this.lbl_SamplingFreq = new System.Windows.Forms.Label();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Set = new System.Windows.Forms.Button();
            this.chkbx_TimerOn = new System.Windows.Forms.CheckBox();
            this.chkbx_TimerOff = new System.Windows.Forms.CheckBox();
            this.gbx_Time = new System.Windows.Forms.GroupBox();
            this.gbx_DayOfWeek.SuspendLayout();
            this.gbx_Repeat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FMFreq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AMFreq)).BeginInit();
            this.gbx_band.SuspendLayout();
            this.gbx_Time.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbtn_Once
            // 
            this.rbtn_Once.AutoSize = true;
            this.rbtn_Once.Checked = true;
            this.rbtn_Once.Location = new System.Drawing.Point(15, 18);
            this.rbtn_Once.Name = "rbtn_Once";
            this.rbtn_Once.Size = new System.Drawing.Size(49, 16);
            this.rbtn_Once.TabIndex = 0;
            this.rbtn_Once.TabStop = true;
            this.rbtn_Once.Text = "Once";
            this.rbtn_Once.UseVisualStyleBackColor = true;
            this.rbtn_Once.CheckedChanged += new System.EventHandler(this.rbtn_RepeatType_CheckedChanged);
            // 
            // rbtn_Daily
            // 
            this.rbtn_Daily.AutoSize = true;
            this.rbtn_Daily.Location = new System.Drawing.Point(130, 18);
            this.rbtn_Daily.Name = "rbtn_Daily";
            this.rbtn_Daily.Size = new System.Drawing.Size(49, 16);
            this.rbtn_Daily.TabIndex = 1;
            this.rbtn_Daily.Text = "Daily";
            this.rbtn_Daily.UseVisualStyleBackColor = true;
            this.rbtn_Daily.CheckedChanged += new System.EventHandler(this.rbtn_RepeatType_CheckedChanged);
            // 
            // rbtn_DayOfWeek
            // 
            this.rbtn_DayOfWeek.AutoSize = true;
            this.rbtn_DayOfWeek.Location = new System.Drawing.Point(266, 18);
            this.rbtn_DayOfWeek.Name = "rbtn_DayOfWeek";
            this.rbtn_DayOfWeek.Size = new System.Drawing.Size(88, 16);
            this.rbtn_DayOfWeek.TabIndex = 2;
            this.rbtn_DayOfWeek.Text = "Day of Week";
            this.rbtn_DayOfWeek.UseVisualStyleBackColor = true;
            this.rbtn_DayOfWeek.CheckedChanged += new System.EventHandler(this.rbtn_RepeatType_CheckedChanged);
            // 
            // chkbx_Sunday
            // 
            this.chkbx_Sunday.AutoSize = true;
            this.chkbx_Sunday.Location = new System.Drawing.Point(13, 22);
            this.chkbx_Sunday.Name = "chkbx_Sunday";
            this.chkbx_Sunday.Size = new System.Drawing.Size(61, 16);
            this.chkbx_Sunday.TabIndex = 0;
            this.chkbx_Sunday.Text = "Sunday";
            this.chkbx_Sunday.UseVisualStyleBackColor = true;
            // 
            // chkbx_Monday
            // 
            this.chkbx_Monday.AutoSize = true;
            this.chkbx_Monday.Location = new System.Drawing.Point(94, 22);
            this.chkbx_Monday.Name = "chkbx_Monday";
            this.chkbx_Monday.Size = new System.Drawing.Size(63, 16);
            this.chkbx_Monday.TabIndex = 1;
            this.chkbx_Monday.Text = "Monday";
            this.chkbx_Monday.UseVisualStyleBackColor = true;
            // 
            // chkbx_Tuesday
            // 
            this.chkbx_Tuesday.AutoSize = true;
            this.chkbx_Tuesday.Location = new System.Drawing.Point(177, 22);
            this.chkbx_Tuesday.Name = "chkbx_Tuesday";
            this.chkbx_Tuesday.Size = new System.Drawing.Size(67, 16);
            this.chkbx_Tuesday.TabIndex = 2;
            this.chkbx_Tuesday.Text = "Tuesday";
            this.chkbx_Tuesday.UseVisualStyleBackColor = true;
            // 
            // chkbx_Wednesday
            // 
            this.chkbx_Wednesday.AutoSize = true;
            this.chkbx_Wednesday.Location = new System.Drawing.Point(264, 22);
            this.chkbx_Wednesday.Name = "chkbx_Wednesday";
            this.chkbx_Wednesday.Size = new System.Drawing.Size(81, 16);
            this.chkbx_Wednesday.TabIndex = 3;
            this.chkbx_Wednesday.Text = "Wednesday";
            this.chkbx_Wednesday.UseVisualStyleBackColor = true;
            // 
            // chkbx_Thursday
            // 
            this.chkbx_Thursday.AutoSize = true;
            this.chkbx_Thursday.Location = new System.Drawing.Point(13, 44);
            this.chkbx_Thursday.Name = "chkbx_Thursday";
            this.chkbx_Thursday.Size = new System.Drawing.Size(71, 16);
            this.chkbx_Thursday.TabIndex = 4;
            this.chkbx_Thursday.Text = "Thursday";
            this.chkbx_Thursday.UseVisualStyleBackColor = true;
            // 
            // chkbx_Friday
            // 
            this.chkbx_Friday.AutoSize = true;
            this.chkbx_Friday.Location = new System.Drawing.Point(94, 44);
            this.chkbx_Friday.Name = "chkbx_Friday";
            this.chkbx_Friday.Size = new System.Drawing.Size(56, 16);
            this.chkbx_Friday.TabIndex = 5;
            this.chkbx_Friday.Text = "Friday";
            this.chkbx_Friday.UseVisualStyleBackColor = true;
            // 
            // chkbx_Saturday
            // 
            this.chkbx_Saturday.AutoSize = true;
            this.chkbx_Saturday.Location = new System.Drawing.Point(177, 44);
            this.chkbx_Saturday.Name = "chkbx_Saturday";
            this.chkbx_Saturday.Size = new System.Drawing.Size(69, 16);
            this.chkbx_Saturday.TabIndex = 6;
            this.chkbx_Saturday.Text = "Saturday";
            this.chkbx_Saturday.UseVisualStyleBackColor = true;
            // 
            // gbx_DayOfWeek
            // 
            this.gbx_DayOfWeek.Controls.Add(this.chkbx_Sunday);
            this.gbx_DayOfWeek.Controls.Add(this.chkbx_Monday);
            this.gbx_DayOfWeek.Controls.Add(this.chkbx_Tuesday);
            this.gbx_DayOfWeek.Controls.Add(this.chkbx_Saturday);
            this.gbx_DayOfWeek.Controls.Add(this.chkbx_Wednesday);
            this.gbx_DayOfWeek.Controls.Add(this.chkbx_Friday);
            this.gbx_DayOfWeek.Controls.Add(this.chkbx_Thursday);
            this.gbx_DayOfWeek.Enabled = false;
            this.gbx_DayOfWeek.Location = new System.Drawing.Point(10, 45);
            this.gbx_DayOfWeek.Name = "gbx_DayOfWeek";
            this.gbx_DayOfWeek.Size = new System.Drawing.Size(360, 71);
            this.gbx_DayOfWeek.TabIndex = 3;
            this.gbx_DayOfWeek.TabStop = false;
            this.gbx_DayOfWeek.Text = "Day of Week";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "ON TIME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "OFF TIME";
            // 
            // dtp_TimerOff
            // 
            this.dtp_TimerOff.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_TimerOff.Location = new System.Drawing.Point(93, 52);
            this.dtp_TimerOff.Name = "dtp_TimerOff";
            this.dtp_TimerOff.Size = new System.Drawing.Size(224, 19);
            this.dtp_TimerOff.TabIndex = 3;
            // 
            // dtp_TimerOn
            // 
            this.dtp_TimerOn.CustomFormat = "HH:mm:ss dddd MMMM dd, yyyy";
            this.dtp_TimerOn.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_TimerOn.Location = new System.Drawing.Point(93, 22);
            this.dtp_TimerOn.Name = "dtp_TimerOn";
            this.dtp_TimerOn.Size = new System.Drawing.Size(224, 19);
            this.dtp_TimerOn.TabIndex = 1;
            // 
            // gbx_Repeat
            // 
            this.gbx_Repeat.Controls.Add(this.rbtn_Once);
            this.gbx_Repeat.Controls.Add(this.rbtn_Daily);
            this.gbx_Repeat.Controls.Add(this.rbtn_DayOfWeek);
            this.gbx_Repeat.Controls.Add(this.gbx_DayOfWeek);
            this.gbx_Repeat.Location = new System.Drawing.Point(15, 206);
            this.gbx_Repeat.Name = "gbx_Repeat";
            this.gbx_Repeat.Size = new System.Drawing.Size(380, 123);
            this.gbx_Repeat.TabIndex = 4;
            this.gbx_Repeat.TabStop = false;
            this.gbx_Repeat.Text = "Repeat";
            // 
            // rbtn_FM
            // 
            this.rbtn_FM.AutoSize = true;
            this.rbtn_FM.Checked = true;
            this.rbtn_FM.Location = new System.Drawing.Point(15, 18);
            this.rbtn_FM.Name = "rbtn_FM";
            this.rbtn_FM.Size = new System.Drawing.Size(73, 16);
            this.rbtn_FM.TabIndex = 0;
            this.rbtn_FM.TabStop = true;
            this.rbtn_FM.Text = "FM [MHz]";
            this.rbtn_FM.UseVisualStyleBackColor = true;
            this.rbtn_FM.CheckedChanged += new System.EventHandler(this.rbtn_Band_CheckedChanged);
            // 
            // rbtn_AM
            // 
            this.rbtn_AM.AutoSize = true;
            this.rbtn_AM.Location = new System.Drawing.Point(205, 18);
            this.rbtn_AM.Name = "rbtn_AM";
            this.rbtn_AM.Size = new System.Drawing.Size(71, 16);
            this.rbtn_AM.TabIndex = 2;
            this.rbtn_AM.Text = "AM [kHz]";
            this.rbtn_AM.UseVisualStyleBackColor = true;
            this.rbtn_AM.CheckedChanged += new System.EventHandler(this.rbtn_Band_CheckedChanged);
            // 
            // nud_FMFreq
            // 
            this.nud_FMFreq.DecimalPlaces = 1;
            this.nud_FMFreq.Enabled = false;
            this.nud_FMFreq.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_FMFreq.Location = new System.Drawing.Point(100, 17);
            this.nud_FMFreq.Maximum = new decimal(new int[] {
            108,
            0,
            0,
            0});
            this.nud_FMFreq.Minimum = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.nud_FMFreq.Name = "nud_FMFreq";
            this.nud_FMFreq.Size = new System.Drawing.Size(61, 19);
            this.nud_FMFreq.TabIndex = 1;
            this.nud_FMFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_FMFreq.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            // 
            // nud_AMFreq
            // 
            this.nud_AMFreq.Enabled = false;
            this.nud_AMFreq.Location = new System.Drawing.Point(290, 17);
            this.nud_AMFreq.Maximum = new decimal(new int[] {
            1710,
            0,
            0,
            0});
            this.nud_AMFreq.Minimum = new decimal(new int[] {
            520,
            0,
            0,
            0});
            this.nud_AMFreq.Name = "nud_AMFreq";
            this.nud_AMFreq.Size = new System.Drawing.Size(61, 19);
            this.nud_AMFreq.TabIndex = 3;
            this.nud_AMFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_AMFreq.Value = new decimal(new int[] {
            520,
            0,
            0,
            0});
            // 
            // cmbbx_SampleRate
            // 
            this.cmbbx_SampleRate.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbbx_SampleRate.FormattingEnabled = true;
            this.cmbbx_SampleRate.Location = new System.Drawing.Point(149, 337);
            this.cmbbx_SampleRate.Name = "cmbbx_SampleRate";
            this.cmbbx_SampleRate.Size = new System.Drawing.Size(91, 20);
            this.cmbbx_SampleRate.TabIndex = 6;
            // 
            // gbx_band
            // 
            this.gbx_band.Controls.Add(this.rbtn_FM);
            this.gbx_band.Controls.Add(this.rbtn_AM);
            this.gbx_band.Controls.Add(this.nud_AMFreq);
            this.gbx_band.Controls.Add(this.nud_FMFreq);
            this.gbx_band.Location = new System.Drawing.Point(15, 145);
            this.gbx_band.Name = "gbx_band";
            this.gbx_band.Size = new System.Drawing.Size(380, 48);
            this.gbx_band.TabIndex = 3;
            this.gbx_band.TabStop = false;
            this.gbx_band.Text = "Band";
            // 
            // lbl_SamplingFreq
            // 
            this.lbl_SamplingFreq.AutoSize = true;
            this.lbl_SamplingFreq.Location = new System.Drawing.Point(23, 340);
            this.lbl_SamplingFreq.Name = "lbl_SamplingFreq";
            this.lbl_SamplingFreq.Size = new System.Drawing.Size(79, 12);
            this.lbl_SamplingFreq.TabIndex = 5;
            this.lbl_SamplingFreq.Text = "Sampling Rate";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(297, 365);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(98, 32);
            this.btn_Cancel.TabIndex = 8;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Set
            // 
            this.btn_Set.Location = new System.Drawing.Point(194, 365);
            this.btn_Set.Name = "btn_Set";
            this.btn_Set.Size = new System.Drawing.Size(87, 31);
            this.btn_Set.TabIndex = 7;
            this.btn_Set.Text = "Set";
            this.btn_Set.UseVisualStyleBackColor = true;
            this.btn_Set.Click += new System.EventHandler(this.btn_Set_Click);
            // 
            // chkbx_TimerOn
            // 
            this.chkbx_TimerOn.Appearance = System.Windows.Forms.Appearance.Button;
            this.chkbx_TimerOn.Location = new System.Drawing.Point(215, 14);
            this.chkbx_TimerOn.Name = "chkbx_TimerOn";
            this.chkbx_TimerOn.Size = new System.Drawing.Size(180, 35);
            this.chkbx_TimerOn.TabIndex = 1;
            this.chkbx_TimerOn.Text = "TIMER ON";
            this.chkbx_TimerOn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkbx_TimerOn.UseVisualStyleBackColor = true;
            this.chkbx_TimerOn.CheckedChanged += new System.EventHandler(this.chkbx_TimerOn_CheckedChanged);
            // 
            // chkbx_TimerOff
            // 
            this.chkbx_TimerOff.Appearance = System.Windows.Forms.Appearance.Button;
            this.chkbx_TimerOff.Location = new System.Drawing.Point(15, 12);
            this.chkbx_TimerOff.Name = "chkbx_TimerOff";
            this.chkbx_TimerOff.Size = new System.Drawing.Size(180, 35);
            this.chkbx_TimerOff.TabIndex = 0;
            this.chkbx_TimerOff.Text = "TIMER OFF";
            this.chkbx_TimerOff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkbx_TimerOff.UseVisualStyleBackColor = true;
            this.chkbx_TimerOff.CheckedChanged += new System.EventHandler(this.chkbx_TimerOff_CheckedChanged);
            // 
            // gbx_Time
            // 
            this.gbx_Time.Controls.Add(this.dtp_TimerOff);
            this.gbx_Time.Controls.Add(this.label1);
            this.gbx_Time.Controls.Add(this.dtp_TimerOn);
            this.gbx_Time.Controls.Add(this.label2);
            this.gbx_Time.Location = new System.Drawing.Point(15, 55);
            this.gbx_Time.Name = "gbx_Time";
            this.gbx_Time.Size = new System.Drawing.Size(380, 79);
            this.gbx_Time.TabIndex = 2;
            this.gbx_Time.TabStop = false;
            this.gbx_Time.Text = "ON Time / OFF TIME";
            // 
            // FormTimerSet
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.btn_Cancel;
            this.ClientSize = new System.Drawing.Size(409, 407);
            this.Controls.Add(this.gbx_Time);
            this.Controls.Add(this.chkbx_TimerOff);
            this.Controls.Add(this.chkbx_TimerOn);
            this.Controls.Add(this.btn_Set);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.gbx_band);
            this.Controls.Add(this.lbl_SamplingFreq);
            this.Controls.Add(this.cmbbx_SampleRate);
            this.Controls.Add(this.gbx_Repeat);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormTimerSet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Timer Setting";
            this.Load += new System.EventHandler(this.FormTimerSet_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormTimerSet_FormClosing);
            this.gbx_DayOfWeek.ResumeLayout(false);
            this.gbx_DayOfWeek.PerformLayout();
            this.gbx_Repeat.ResumeLayout(false);
            this.gbx_Repeat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FMFreq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AMFreq)).EndInit();
            this.gbx_band.ResumeLayout(false);
            this.gbx_band.PerformLayout();
            this.gbx_Time.ResumeLayout(false);
            this.gbx_Time.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbtn_Once;
        private System.Windows.Forms.RadioButton rbtn_Daily;
        private System.Windows.Forms.RadioButton rbtn_DayOfWeek;
        private System.Windows.Forms.CheckBox chkbx_Sunday;
        private System.Windows.Forms.CheckBox chkbx_Monday;
        private System.Windows.Forms.CheckBox chkbx_Tuesday;
        private System.Windows.Forms.CheckBox chkbx_Wednesday;
        private System.Windows.Forms.CheckBox chkbx_Thursday;
        private System.Windows.Forms.CheckBox chkbx_Friday;
        private System.Windows.Forms.CheckBox chkbx_Saturday;
        private System.Windows.Forms.GroupBox gbx_DayOfWeek;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtp_TimerOff;
        private System.Windows.Forms.DateTimePicker dtp_TimerOn;
        private System.Windows.Forms.GroupBox gbx_Repeat;
        private System.Windows.Forms.RadioButton rbtn_FM;
        private System.Windows.Forms.RadioButton rbtn_AM;
        private System.Windows.Forms.NumericUpDown nud_FMFreq;
        private System.Windows.Forms.NumericUpDown nud_AMFreq;
        private System.Windows.Forms.ComboBox cmbbx_SampleRate;
        private System.Windows.Forms.GroupBox gbx_band;
        private System.Windows.Forms.Label lbl_SamplingFreq;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Set;
        private System.Windows.Forms.CheckBox chkbx_TimerOn;
        private System.Windows.Forms.CheckBox chkbx_TimerOff;
        private System.Windows.Forms.GroupBox gbx_Time;
    }
}